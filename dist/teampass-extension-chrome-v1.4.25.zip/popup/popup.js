/**
 * Extension Name: Teampass Manager Extension
 * Copyright (c) 2026, LogCarré. All Rights Reserved.
 *
 * This code is proprietary software. It is distributed on a non-public, 
 * limited-use basis under the terms of a Commercial License.
 *
 * Unauthorized copying, modification, redistribution, or reverse engineering 
 * of this code, or any part thereof, is strictly prohibited.
 */

// Declare variables (will be populated after DOM loads)
let screens = {}
let forms = {}
let buttons = {}
let messages = {}
let inputs = {}
let displays = {}
let sections = {}
let currentTabUrl = ''
let currentEditItem = null // Item being edited

// Initialize LicenceChecker for telemetry
const licenceChecker = new LicenceChecker()

// Icon sets - Font Awesome and Emojis
const iconSets = {
  fontawesome: {
    lock: '<i class="fas fa-lock"></i>',
    unlock: '<i class="fas fa-unlock"></i>',
    check: '<i class="fas fa-check-circle"></i>',
    times: '<i class="fas fa-times-circle"></i>',
    copy: '<i class="fas fa-copy"></i>',
    key: '<i class="fas fa-key"></i>',
    envelope: '<i class="fas fa-envelope"></i>',
    qrcode: '<i class="fas fa-qrcode"></i>',
    sparkles: '<i class="fas fa-paint-roller"></i>',
    save: '<i class="fas fa-save"></i>',
    spinner: '<i class="fas fa-spinner fa-spin"></i>',
    edit: '<i class="fas fa-edit"></i>',
    link: '<i class="fas fa-link"></i>',
    user: '<i class="fas fa-user"></i>',
    externallink: '<i class="fas fa-external-link"></i>',
    refresh: '<i class="fas fa-sync"></i>',
    moon: '<i class="fas fa-moon"></i>',
    iconset: '<i class="fas fa-icons"></i>',
    gear: '<i class="fas fa-cog"></i>',
    info: '<i class="fas fa-info-circle"></i>',
    logout: '<i class="fas fa-sign-out-alt"></i>'
  },
  emoji: {
    lock: '🔒',
    unlock: '🔓',
    check: '✅',
    times: '❌',
    copy: '📋',
    key: '🔑',
    envelope: '✉️',
    qrcode: '🔢',
    sparkles: '✨',
    save: '💾',
    spinner: '⏳',
    edit: '✏️',
    link: '🔗',
    user: '👤',
    externallink: '🌐',
    refresh: '🔄',
    moon: '🌙',
    iconset: '😀',
    gear: '⚙️',
    info: 'ℹ️',
    logout: '🚪'
  }
}

// Active icon set (will be loaded from settings)
let icons = iconSets.fontawesome

/**
 * Initialize DOM elements
 * Must be called after DOMContentLoaded
 *
 * @returns {void}
 */
function initializeElements() {
  screens = {
    loading: document.getElementById('loadingScreen'),
    config: document.getElementById('configScreen'),
    login: document.getElementById('loginScreen'),
    maintenance: document.getElementById('maintenanceScreen'),
    main: document.getElementById('mainScreen'),
    about: document.getElementById('aboutScreen'),
    account: document.getElementById('accountScreen'),
    edit: document.getElementById('editScreen'),
    view: document.getElementById('viewItemScreen'),
    addItem: document.getElementById('addItemScreen')
  }

  forms = {
    config: document.getElementById('configForm'),
    login: document.getElementById('loginForm'),
    edit: document.getElementById('editForm'),
    addItem: document.getElementById('addItemForm')
  }

  buttons = {
    testConnection: document.getElementById('testConnectionBtn'),
    changeServer: document.getElementById('changeServerBtn'),
    logout: document.getElementById('logoutBtn'),
    refresh: document.getElementById('refreshBtn'),
    passwordGenerator: document.getElementById('passwordGeneratorBtn'),
    addItem: document.getElementById('addItemBtn'),
    account: document.getElementById('accountBtn'),
    openTeampass: document.getElementById('openTeampassBtn'),
    menu: document.getElementById('menuBtn'),
    darkMode: document.getElementById('darkModeBtn'),
    iconStyle: document.getElementById('iconStyleBtn'),
    openOptions2: document.getElementById('openOptionsBtn2'),
    about: document.getElementById('aboutBtn'),
    backFromAbout: document.getElementById('backFromAboutBtn'),
    backFromAbout2: document.getElementById('backFromAboutBtn2'),
    backFromAccount: document.getElementById('backFromAccountBtn'),
    backFromEdit: document.getElementById('backFromEditBtn'),
    backFromView: document.getElementById('backFromViewBtn'),
    backFromAddItem: document.getElementById('backFromAddItemBtn'),
    deleteItem: document.getElementById('deleteItemBtn'),
    editUpdate: document.getElementById('editUpdateBtn'),
    editFromView: document.getElementById('editFromViewBtn'),
    viewPasswordToggle: document.getElementById('viewPasswordToggle'),
    reauth: document.getElementById('reauthBtn'),
    openOptions: document.getElementById('openOptionsBtn'),
    retryMaintenance: document.getElementById('retryMaintenanceBtn'),
    globalSearch: document.getElementById('globalSearchBtn'),
    clearSearch: document.getElementById('clearSearchBtn'),
    clearSearchInput: document.getElementById('clearSearchInput'),
    generatePassword: document.getElementById('generatePasswordBtn'),
    copyGeneratedPassword: document.getElementById('copyGeneratedPasswordBtn'),
    closePasswordGeneratorModal: document.getElementById('closePasswordGeneratorModal'),
    closePasswordGeneratorModalBtn: document.getElementById('closePasswordGeneratorModalBtn')
  }

  debugLog('INIT: addItemBtn element:', buttons.addItem)
  debugLog('INIT: addItemBtn exists:', !!buttons.addItem)

  messages = {
    config: document.getElementById('configMessage'),
    login: document.getElementById('loginMessage'),
    edit: document.getElementById('editMessage')
  }

  inputs = {
    serverUrl: document.getElementById('serverUrl'),
    username: document.getElementById('username'),
    password: document.getElementById('password'),
    apiKey: document.getElementById('apiKey'),
    editLabel: document.getElementById('editLabel'),
    editLogin: document.getElementById('editLogin'),
    editPassword: document.getElementById('editPassword'),
    editEmail: document.getElementById('editEmail'),
    editUrl: document.getElementById('editUrl'),
    editDescription: document.getElementById('editDescription'),
    editTags: document.getElementById('editTags'),
    editFolderId: document.getElementById('editFolderId'),
    editFolderSearch: document.getElementById('editFolderSearch'),
    editIcon: document.getElementById('editIcon'),
    editAnyoneCanModify: document.getElementById('editAnyoneCanModify'),
    editTotp: document.getElementById('editTotp'),
    globalSearch: document.getElementById('globalSearch')
  }

  displays = {
    accountLicenceBadge: document.getElementById('accountLicenceBadge'),
    permissions: document.getElementById('permissionsList'),
    currentPageUrl: document.getElementById('currentPageUrl'),
    itemsList: document.getElementById('itemsList'),
    darkModeIcon: document.getElementById('darkModeIcon'),
    darkModeToggle: document.getElementById('darkModeToggle'),
    iconStyleIcon: document.getElementById('iconStyleIcon'),
    iconStyleToggle: document.getElementById('iconStyleToggle'),
    // Account screen displays
    accountUsername: document.getElementById('accountUsername'),
    accountEmail: document.getElementById('accountEmail'),
    licenceStatusIcon: document.getElementById('licenceStatusIcon'),
    licenceStatusLabel: document.getElementById('licenceStatusLabel'),
    licenceExpiration: document.getElementById('licenceExpiration'),
    licenceMaxUsers: document.getElementById('licenceMaxUsers'),
    licenceJwtExpires: document.getElementById('licenceJwtExpires'),
    licenceLastVerification: document.getElementById('licenceLastVerification')
  }

  sections = {
    items: document.getElementById('itemsSection'),
    noItems: document.getElementById('noItemsSection'),
    loadingItems: document.getElementById('loadingItemsSection'),
    dropdownMenu: document.getElementById('dropdownMenu'),
    addItemModal: document.getElementById('addItemModal'),
    searchResultsHeader: document.getElementById('searchResultsHeader')
  }

  debugLog('INIT: addItemModal element:', sections.addItemModal)
  debugLog('INIT: addItemModal exists:', !!sections.addItemModal)
}

async function initialize() {
  // Load dark mode preference first
  await loadDarkModePreference()

  // Load icon style preference
  await loadIconStylePreference()

  // Load language preference
  await initializeLanguageSelector()

  // Initialize save modes handler (check if popup should open in save mode)
  let isInSaveMode = false
  if (typeof saveModesHandler !== 'undefined') {
    try {
      isInSaveMode = await saveModesHandler.initialize()
    } catch (saveModeError) {
      console.error('Failed to initialize save modes:', saveModeError)
      // Continue with normal initialization even if save mode fails
      isInSaveMode = false
    }
  }

  try {
    const storage = await chrome.storage.local.get([
      'teampass_configured',
      'teampass_url',
      'teampass_token',
      'token_expiry'
    ])

    if (!storage.teampass_configured || !storage.teampass_url) {
      showScreen('config')
    } else {
      inputs.serverUrl.value = storage.teampass_url

      if (storage.teampass_token) {
        // Show loading screen unless in save mode (which has already shown its screen)
        if (!isInSaveMode) {
          showScreen('loading')
        }

        try {
          // Check if token needs refresh - service worker uses adaptive threshold
          const isValid = await sendMessage('ensureValidToken')

          if (isValid) {
            debugLog('Token is valid or was refreshed successfully')
            if (!isInSaveMode) {
              updateLoadingMessage(i18n.t('popup.loading.title'))
            }
            await loadMainScreen(isInSaveMode)
          } else {
            // Auto-refresh failed - try loading main screen anyway
            // The service worker will catch TOKEN_EXPIRED errors and retry
            debugLog('Token validation returned false, attempting to load main screen...')
            if (!isInSaveMode) {
              updateLoadingMessage(i18n.t('popup.loading.title'))
            }

            try {
              await loadMainScreen(isInSaveMode)
            } catch (error) {
              // Only show login if loading main screen fails
              console.error('Failed to load main screen:', error)
              showScreen('login')
            }
          }
        } catch (error) {
          console.error('Token validation failed, attempting to load main screen:', error)
          if (!isInSaveMode) {
            updateLoadingMessage(i18n.t('popup.loading.title'))
          }

          // Try to load main screen - let service worker handle re-auth
          try {
            await loadMainScreen(isInSaveMode)
          } catch (loadError) {
            // Only show login if everything fails
            console.error('Failed to load main screen after validation failure:', loadError)
            showScreen('login')
          }
        }
      } else {
        // No token - must login
        showScreen('login')
      }
    }
  } catch (error) {
    console.error('Initialization error:', error)
    showMessage(messages.config, i18n.t('common.initializationFailed', { message: error.message }), 'error')
    showScreen('config')
  }
}

function showScreen(screenName) {
  Object.values(screens).forEach(screen => {
    screen.style.display = 'none'
  })

  if (screens[screenName]) {
    screens[screenName].style.display = 'block'

    // Reset scroll position to top when showing a screen
    // Target the .content element inside the screen (which is the scrollable element)
    const contentElement = screens[screenName].querySelector('.content')
    if (contentElement) {
      contentElement.scrollTop = 0
    }
  }
}

function showMessage(element, text, type = 'info') {
  element.textContent = text
  element.className = `message ${type}`
  element.style.display = 'block'

  if (type === 'success') {
    setTimeout(() => {
      element.style.display = 'none'
    }, 3000)
  }
}

/**
 * Update the loading screen message
 * @param {string} message - The message to display
 * @returns {void}
 */
function updateLoadingMessage(message) {
  if (screens.loading) {
    const messageElement = screens.loading.querySelector('p')
    if (messageElement) {
      messageElement.textContent = message
    }
  }
}

/**
 * Wake up service worker (Firefox compatibility)
 * Sends a dummy message to ensure the service worker is loaded
 */
async function wakeUpServiceWorker() {
  try {
    // Try to get auth state - this will wake up the service worker
    await chrome.runtime.sendMessage({ action: 'getAuthState' })
  } catch (error) {
    // Ignore errors, we just want to wake up the worker
  }
}

/**
 * Send message to service worker with retry logic and timeout
 * Includes timeout to prevent infinite waiting if service worker doesn't respond
 */
function sendMessage(action, data = {}, retryCount = 0) {
  return new Promise((resolve, reject) => {
    let timeoutTriggered = false

    // Set a timeout to reject the promise if no response is received
    const timeoutId = setTimeout(() => {
      timeoutTriggered = true
      console.error(`sendMessage: Timeout for ${action} after ${CONFIG.MESSAGE_TIMEOUT}ms`)

      // Retry on timeout (Chrome may have terminated service worker)
      if (retryCount < 3) {
        wakeUpServiceWorker().then(() => {
          setTimeout(() => {
            sendMessage(action, data, retryCount + 1)
              .then(resolve)
              .catch(reject)
          }, 100 * (retryCount + 1))
        })
      } else {
        reject(new Error(`Service worker timeout after ${retryCount + 1} attempts. Please try again.`))
      }
    }, CONFIG.MESSAGE_TIMEOUT)

    chrome.runtime.sendMessage(
      { action, data },
      response => {
        // Ignore response if timeout already triggered
        if (timeoutTriggered) {
          return
        }

        // Clear timeout since we got a response
        clearTimeout(timeoutId)

        if (chrome.runtime.lastError) {
          const errorMsg = chrome.runtime.lastError.message

          // Retry on connection errors (service worker not ready)
          if (errorMsg.includes('Receiving end does not exist') && retryCount < 3) {
            // Wake up service worker before retry
            wakeUpServiceWorker().then(() => {
              setTimeout(() => {
                sendMessage(action, data, retryCount + 1)
                  .then(resolve)
                  .catch(reject)
              }, 100 * (retryCount + 1)) // Exponential backoff: 100ms, 200ms, 300ms
            })
          } else {
            reject(new Error(errorMsg))
          }
        } else if (response.success) {
          resolve(response.data)
        } else {
          reject(new Error(response.error || 'Unknown error'))
        }
      }
    )
  })
}

async function handleTestConnection() {
  const serverUrl = inputs.serverUrl.value.trim()

  if (!serverUrl) {
    showMessage(messages.config, i18n.t('popup.config.serverUrlRequired'), 'error')
    return
  }

  buttons.testConnection.disabled = true
  buttons.testConnection.textContent = i18n.t('popup.config.configTestConnection')

  try {
    await sendMessage('testConnection', { serverUrl })
    showMessage(messages.config, i18n.t('popup.config.configConnectionSuccess'), 'success')
  } catch (error) {
    showMessage(messages.config, i18n.t('common.configurationFailed', { message: error.message }), 'error')
  } finally {
    buttons.testConnection.disabled = false
    buttons.testConnection.textContent = 'Test Connection'
  }
}

async function handleConfigSubmit(event) {
  event.preventDefault()

  const serverUrl = inputs.serverUrl.value.trim()

  if (!serverUrl) {
    showMessage(messages.config, i18n.t('popup.config.serverUrlRequired'), 'error')
    return
  }

  try {
    await sendMessage('testConnection', { serverUrl })

    await chrome.storage.local.set({
      teampass_configured: true,
      teampass_url: serverUrl
    })

    showMessage(messages.config, i18n.t('popup.config.configSaved'), 'success')

    setTimeout(() => {
      showScreen('login')
    }, 1000)

  } catch (error) {
    showMessage(messages.config, i18n.t('common.configurationFailed', { message: error.message }), 'error')
  }
}

async function handleLoginSubmit(event) {
  event.preventDefault()
  
  const username = inputs.username.value.trim()
  const password = inputs.password.value
  const apiKey = inputs.apiKey.value.trim()
  const storage = await chrome.storage.local.get('teampass_url')
  const serverUrl = storage.teampass_url
  
  if (!username || !password) {
    showMessage(messages.login, i18n.t('popup.login.usernamePasswordRequired'), 'error')
    return
  }

  if (!apiKey) {
    showMessage(messages.login, i18n.t('popup.login.apiKeyRequired'), 'error')
    return
  }
  
  const submitBtn = forms.login.querySelector('button[type="submit"]')
  submitBtn.disabled = true
  submitBtn.textContent = i18n.t('popup.login.authenticating')
  
  try {
    await sendMessage('authenticate', {
      serverUrl,
      username,
      password,
      apiKey
    })

    showMessage(messages.login, i18n.t('popup.login.loginSuccess'), 'success')

    inputs.password.value = ''
    inputs.apiKey.value = ''

    setTimeout(() => {
      loadMainScreen()
    }, CONFIG.LOGIN_SUCCESS_DELAY)

  } catch (error) {
    showMessage(messages.login, i18n.t('common.loginFailed', { message: error.message }), 'error')
  } finally {
    submitBtn.disabled = false
    submitBtn.textContent = 'Login'
  }
}

/**
 * Update licence status indicator on account button badge
 * @param {string} licenceDataString - JSON string of licence data
 */
function updateLicenceIndicator(licenceDataString) {
  if (!displays.accountLicenceBadge) return

  try {
    if (!licenceDataString) {
      displays.accountLicenceBadge.textContent = '🟠'
      displays.accountLicenceBadge.setAttribute('data-status', 'unknown')
      if (buttons.account) {
        buttons.account.title = 'Account & Licence - Not verified yet'
      }
      return
    }

    const licenceData = JSON.parse(licenceDataString)

    if (licenceData.status === 'VALID') {
      displays.accountLicenceBadge.textContent = '🟢'
      displays.accountLicenceBadge.setAttribute('data-status', 'valid')
      if (buttons.account) {
        buttons.account.title = 'Account & Licence - Valid'
      }
    } else if (licenceData.status === 'EXPIRED') {
      displays.accountLicenceBadge.textContent = '🔴'
      displays.accountLicenceBadge.setAttribute('data-status', 'expired')
      if (buttons.account) {
        buttons.account.title = 'Account & Licence - Expired'
      }
    } else if (licenceData.status === 'INVALID') {
      displays.accountLicenceBadge.textContent = '🔴'
      displays.accountLicenceBadge.setAttribute('data-status', 'invalid')
      if (buttons.account) {
        buttons.account.title = 'Account & Licence - Invalid'
      }
    } else if (licenceData.status === 'LIMIT_EXCEEDED') {
      displays.accountLicenceBadge.textContent = '🔴'
      displays.accountLicenceBadge.setAttribute('data-status', 'limit_exceeded')
      if (buttons.account) {
        buttons.account.title = 'Account & Licence - Limit exceeded'
      }
    } else {
      displays.accountLicenceBadge.textContent = '🟠'
      displays.accountLicenceBadge.setAttribute('data-status', 'unknown')
      if (buttons.account) {
        buttons.account.title = 'Account & Licence - Status unknown'
      }
    }
  } catch (error) {
    displays.accountLicenceBadge.textContent = '🟠'
    displays.accountLicenceBadge.setAttribute('data-status', 'error')
    if (buttons.account) {
      buttons.account.title = 'Account & Licence - Error'
    }
  }
}

/**
 * Extract email from JWT token
 * @param {string} token - JWT token string
 * @returns {string|null} Email from JWT payload or null
 */
function getEmailFromJWT(token) {
  try {
    // JWT format: header.payload.signature
    const parts = token.split('.')
    if (parts.length !== 3) {
      return null
    }

    // Decode base64url payload (second part)
    const payload = parts[1]
    // Replace base64url chars with base64 chars
    const base64 = payload.replace(/-/g, '+').replace(/_/g, '/')
    // Pad with '=' if needed
    const padded = base64.padEnd(base64.length + (4 - base64.length % 4) % 4, '=')

    // Decode and parse JSON
    const decoded = atob(padded)
    const data = JSON.parse(decoded)

    return data.email || null
  } catch (error) {
    console.error('Error extracting email from JWT:', error)
    return null
  }
}

/**
 * Load account screen with user info, permissions and licence details
 */
async function loadAccountScreen() {
  try {
    showScreen('account')

    const storage = await chrome.storage.local.get([
      'teampass_user',
      'teampass_token',
      'teampass_permissions',
      'teampass_ext_licence',
      'icon_style'
    ])

    // Load user information
    if (storage.teampass_user) {
      displays.accountUsername.textContent = storage.teampass_user.username || '-'
    }

    // Load email from JWT token
    if (storage.teampass_token) {
      const email = getEmailFromJWT(storage.teampass_token)
      if (email && displays.accountEmail) {
        displays.accountEmail.textContent = email
      } else if (displays.accountEmail) {
        displays.accountEmail.textContent = '-'
      }
    } else if (displays.accountEmail) {
      displays.accountEmail.textContent = '-'
    }

    // Determine icon style (fontawesome or emoji)
    const useEmoji = storage.icon_style === 'emoji'

    // Icon mappings
    const permissionIcons = {
      canCreate: useEmoji ? '➕' : '<i class="fas fa-plus"></i>',
      canRead: useEmoji ? '👁️' : '<i class="fas fa-eye"></i>',
      canUpdate: useEmoji ? '✏️' : '<i class="fas fa-edit"></i>',
      canDelete: useEmoji ? '🗑️' : '<i class="fas fa-trash"></i>'
    }

    // Load permissions
    const permissions = storage.teampass_permissions || {}
    const permissionKeys = ['canCreate', 'canRead', 'canUpdate', 'canDelete']

    debugLog('DEBUG Account Screen - Permissions from storage:', permissions)

    permissionKeys.forEach(key => {
      const itemElement = document.querySelector(`.permission-item[data-perm="${key}"]`)
      if (itemElement) {
        const isEnabled = permissions[key] === true
        const iconElement = itemElement.querySelector('.permission-icon')
        const badgeElement = itemElement.querySelector('.permission-badge')

        debugLog(`DEBUG Permission ${key}:`, isEnabled, 'from value:', permissions[key])

        if (iconElement) {
          setIconContent(iconElement, permissionIcons[key])
        }

        if (badgeElement) {
          badgeElement.textContent = isEnabled ? '✓' : '✗'
        }

        // Update item classes
        itemElement.classList.remove('enabled', 'disabled')
        itemElement.classList.add(isEnabled ? 'enabled' : 'disabled')
      }
    })

    // Load licence information
    if (storage.teampass_ext_licence) {
      try {
        const licenceData = JSON.parse(storage.teampass_ext_licence)

        // Status with icon
        let statusIcon = '🟠'
        let statusLabel = i18n.t('popup.account.licenceNotVerified')

        if (licenceData.status === 'VALID') {
          statusIcon = '🟢'
          statusLabel = i18n.t('popup.account.licenceValid')
        } else if (licenceData.status === 'EXPIRED') {
          statusIcon = '🔴'
          statusLabel = i18n.t('popup.account.licenceExpired')
        } else if (licenceData.status === 'INVALID') {
          statusIcon = '🔴'
          statusLabel = i18n.t('popup.account.licenceInvalid')
        } else if (licenceData.status === 'LIMIT_EXCEEDED') {
          statusIcon = '🔴'
          statusLabel = i18n.t('popup.account.licenceLimitExceeded')
        }

        displays.licenceStatusIcon.textContent = statusIcon
        displays.licenceStatusLabel.textContent = statusLabel

        // Expiration date (ISO format)
        if (licenceData.expirationDate) {
          displays.licenceExpiration.textContent = licenceData.expirationDate
        } else {
          displays.licenceExpiration.textContent = '-'
        }

        // Max users
        if (licenceData.maxUsers) {
          displays.licenceMaxUsers.textContent = licenceData.maxUsers.toString()
        } else {
          displays.licenceMaxUsers.textContent = '-'
        }

        // JWT expiration (ISO format YYYY-MM-DD HH:MM)
        // jwtExpires is in seconds, need to convert to milliseconds
        if (licenceData.jwtExpires) {
          const jwtDate = new Date(licenceData.jwtExpires * 1000)
          const isoString = jwtDate.toISOString()
          const formattedDate = isoString.substring(0, 16).replace('T', ' ')
          displays.licenceJwtExpires.textContent = formattedDate
        } else {
          displays.licenceJwtExpires.textContent = '-'
        }

        // Last verification (ISO format YYYY-MM-DD HH:MM)
        if (licenceData.lastSuccess) {
          const lastDate = new Date(licenceData.lastSuccess)
          const isoString = lastDate.toISOString()
          const formattedDate = isoString.substring(0, 16).replace('T', ' ')
          displays.licenceLastVerification.textContent = formattedDate
        } else {
          displays.licenceLastVerification.textContent = '-'
        }

      } catch (error) {
        console.error('Error parsing licence data:', error)
        displays.licenceStatusIcon.textContent = '🟠'
        displays.licenceStatusLabel.textContent = 'Error'
      }
    } else {
      displays.licenceStatusIcon.textContent = '🟠'
      displays.licenceStatusLabel.textContent = 'Not available'
    }

    // Update favorite folder display
    await updateFavoriteFolderDisplay()

    // Update language selector
    const languageSelect = document.getElementById('languageSelect')
    if (languageSelect) {
      languageSelect.value = i18n.getLocale()
    }

  } catch (error) {
    console.error('Failed to load account screen:', error)
    showToast(i18n.t('common.failedToLoadAccountInformation'), 'error')
  }
}

async function loadMainScreen(skipLoadingItems = false) {
  // Check for maintenance mode first
  try {
    const response = await chrome.runtime.sendMessage({ action: 'getJWTData' })
    if (response && response.success && response.data) {
      if (response.data.maintenanceMode === true) {
        debugLog('Server is in maintenance mode')
        showMaintenanceScreen()
        return
      }
    }
  } catch (error) {
    debugLog('Failed to check maintenance mode:', error)
  }

  // Only show loading screen if not in save mode
  // (save mode handler has already shown the appropriate screen)
  if (!skipLoadingItems) {
    showScreen('loading')
  }

  try {
    const storage = await chrome.storage.local.get([
      'teampass_user',
      'teampass_permissions',
      'teampass_ext_licence'
    ])

    if (!storage.teampass_user) {
      throw new Error('User data not found')
    }

    // Update licence status indicator
    updateLicenceIndicator(storage.teampass_ext_licence)

    // AUTO-CHECK LICENCE: If no cache or last status was not VALID, trigger revalidation
    let shouldCheckLicence = false
    if (!storage.teampass_ext_licence) {
      debugLog('[POPUP] No licence cache found, will trigger validation')
      shouldCheckLicence = true
    } else {
      try {
        const licenceData = JSON.parse(storage.teampass_ext_licence)
        if (licenceData.status !== 'VALID') {
          debugLog('[POPUP] Last licence status was not VALID (' + licenceData.status + '), will trigger validation')
          shouldCheckLicence = true
        }
      } catch (e) {
        debugLog('[POPUP] Failed to parse licence data, will trigger validation')
        shouldCheckLicence = true
      }
    }

    // Trigger licence check in background if needed
    if (shouldCheckLicence) {
      debugLog('[POPUP] Sending message to service worker to check licence...')
      chrome.runtime.sendMessage({ action: 'checkLicence' })
        .then(response => {
          debugLog('[POPUP] Licence check response received:', response)
          // Reload licence data from storage to update the indicator
          chrome.storage.local.get(['teampass_ext_licence']).then(storage => {
            if (storage.teampass_ext_licence) {
              updateLicenceIndicator(storage.teampass_ext_licence)
              debugLog('[POPUP] Licence indicator updated after check')
            }
          })
        })
        .catch(err => {
          debugLog('[POPUP] Failed to send checkLicence message:', err)
        })
    }

    const permissions = storage.teampass_permissions || {}
    const permissionsList = [
      { key: 'canRead', label: i18n.t('popup.account.permissionRead') },
      { key: 'canCreate', label: i18n.t('popup.account.permissionCreate') },
      { key: 'canUpdate', label: i18n.t('popup.account.permissionUpdate') },
      { key: 'canDelete', label: i18n.t('popup.account.permissionDelete') }
    ]

    // Clear existing permissions list
    displays.permissions.innerHTML = ''

    // Create permission list items using safe DOM manipulation
    permissionsList.forEach(perm => {
      const enabled = permissions[perm.key] === true
      const li = document.createElement('li')
      if (!enabled) {
        li.className = 'disabled'
      }
      li.textContent = perm.label
      displays.permissions.appendChild(li)
    })

    // Note: Temporarily disabled permission check to allow testing
    // buttons.addItem.disabled = !permissions.canCreate
    buttons.addItem.disabled = false

    // Only show main screen if not in save mode
    // (save mode handler has already shown the appropriate screen)
    if (!skipLoadingItems) {
      showScreen('main')
      await loadItemsForCurrentPage()
    }

  } catch (error) {
    console.error('Failed to load main screen:', error)
    showScreen('login')
  }
}

async function loadItemsForCurrentPage() {
  try {
    // Get current tab URL
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })

    if (!tab || !tab.url) {
      console.error('Could not get current tab URL')
      return
    }

    currentTabUrl = tab.url
    const urlObj = new URL(currentTabUrl)

    // Display current URL (shortened)
    displays.currentPageUrl.textContent = `🌐 ${urlObj.hostname}${urlObj.pathname}`
    // Remove data-i18n attribute to prevent i18n system from overwriting the URL
    displays.currentPageUrl.removeAttribute('data-i18n')

    // Show loading
    sections.items.style.display = 'none'
    sections.noItems.style.display = 'none'
    sections.loadingItems.style.display = 'block'

    let items = []

    // Use centralized search strategy with scoring
    // This will search from most specific to most flexible and return results sorted by match quality
    debugLog('Searching items with centralized strategy for URL:', currentTabUrl)

    try {
      items = await sendMessage('searchItemsByUrl', { url: currentTabUrl })
    } catch (error) {
      debugLog('Search failed:', error)
    }

    // Hide loading
    sections.loadingItems.style.display = 'none'

    if (items && items.length > 0) {
      debugLog(`Found ${items.length} item(s), sorted by match quality`)
      displayItems(items)
      sections.items.style.display = 'block'
    } else {
      debugLog('No items found')
      sections.noItems.style.display = 'block'
    }

  } catch (error) {
    console.error('Failed to load items:', error)
    sections.loadingItems.style.display = 'none'
    sections.noItems.style.display = 'block'
  }
}

/**
 * Normalize URL for search to be more permissive
 * Removes trailing slashes, query params, and fragments
 * 
 * @param {string} url - URL to normalize
 * @returns {string} Normalized URL
 */
function normalizeUrl(url) {
  try {
    const urlObj = new URL(url)
    
    // Build base URL: protocol + hostname + pathname
    let normalized = `${urlObj.protocol}//${urlObj.hostname}${urlObj.pathname}`
    
    // Remove trailing slash (except for root)
    if (normalized.endsWith('/') && normalized.length > urlObj.origin.length + 1) {
      normalized = normalized.slice(0, -1)
    }
    
    // For root path, also try without trailing slash
    if (normalized === urlObj.origin + '/') {
      normalized = urlObj.origin
    }
    
    debugLog('URL normalization:', {
      original: url,
      normalized: normalized
    })
    
    return normalized
    
  } catch (error) {
    console.error('URL normalization error:', error)
    // Fallback: just remove trailing slash
    return url.endsWith('/') ? url.slice(0, -1) : url
  }
}

/**
 * Extract base domain from hostname
 * Examples:
 *   www.namecheap.com → namecheap.com
 *   ap.www.namecheap.com → namecheap.com
 *   login.github.com → github.com
 *
 * @param {string} hostname - Hostname to extract base domain from
 * @returns {string} Base domain
 */
function getBaseDomain(hostname) {
  if (!hostname) return hostname

  const parts = hostname.split('.')

  // If only 2 parts or less, return as is (e.g., "localhost", "github.com")
  if (parts.length <= 2) {
    return hostname
  }

  // Check for special TLDs (.co.uk, .com.au, etc.)
  const lastTwo = parts.slice(-2).join('.')
  const specialTlds = ['co.uk', 'com.au', 'co.nz', 'co.za', 'com.br', 'co.jp']

  if (specialTlds.includes(lastTwo)) {
    // Take last 3 parts (e.g., example.co.uk)
    return parts.slice(-3).join('.')
  }

  // Standard case: take last 2 parts (e.g., namecheap.com)
  return parts.slice(-2).join('.')
}

/**
 * Generate a visual match score badge
 * Returns a discrete badge indicating the quality of the URL match
 *
 * @param {number} score - Match score (0-100)
 * @returns {string} HTML for the badge
 */
function getMatchScoreBadge(score) {
  if (typeof score !== 'number' || score <= 0) {
    return null // No badge if no score
  }

  let badgeClass = ''
  let badgeSymbol = ''
  let badgeTitle = ''

  if (score >= 95) {
    badgeClass = 'match-perfect'
    badgeSymbol = '●'
    badgeTitle = 'Perfect match (score: ' + Math.round(score) + ')'
  } else if (score >= 70) {
    badgeClass = 'match-good'
    badgeSymbol = '●'
    badgeTitle = 'Good match (score: ' + Math.round(score) + ')'
  } else if (score >= 50) {
    badgeClass = 'match-medium'
    badgeSymbol = '●'
    badgeTitle = 'Medium match (score: ' + Math.round(score) + ')'
  } else {
    badgeClass = 'match-weak'
    badgeSymbol = '○'
    badgeTitle = 'Weak match (score: ' + Math.round(score) + ')'
  }

  const sup = document.createElement('sup')
  sup.className = `match-badge ${badgeClass}`
  sup.title = badgeTitle
  sup.textContent = badgeSymbol
  return sup
}

/**
 * Create an item card element safely without using innerHTML
 * @param {Object} item - Item data
 * @param {number} index - Item index for animation delay
 * @returns {HTMLElement} Item card element
 */
function createItemCard(item, index) {
  // Main card container
  const card = document.createElement('div')
  card.className = 'item-card'
  card.setAttribute('data-item-id', item.id)
  card.style.animationDelay = `${index * 0.05}s`

  // Favicon container
  const faviconContainer = document.createElement('div')
  faviconContainer.className = 'item-favicon'

  const faviconImg = document.createElement('img')
  faviconImg.className = 'favicon-img'
  // SVG globe par défaut
  const defaultGlobeSvg = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%23667eea"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/></svg>'

  if (item.favicon_url) {
    faviconImg.src = item.favicon_url
    faviconImg.onerror = function() {
      // Si le chargement échoue, utiliser le favicon par défaut
      this.src = defaultGlobeSvg
    }
  } else {
    // Favicon par défaut (globe)
    faviconImg.src = defaultGlobeSvg
  }
  faviconImg.alt = 'Site favicon'
  faviconContainer.appendChild(faviconImg)

  // Content container (holds both rows)
  const contentContainer = document.createElement('div')
  contentContainer.className = 'item-content'

  // Header row
  const headerRow = document.createElement('div')
  headerRow.className = 'item-row item-header-row'

  // Item label (clickable)
  const labelDiv = document.createElement('div')
  labelDiv.className = 'item-label clickable-label'
  labelDiv.setAttribute('data-action', 'view-item')
  labelDiv.setAttribute('data-item-id', item.id)
  labelDiv.title = 'Click to view item details'

  // Add label text (without icon)
  labelDiv.appendChild(document.createTextNode(item.label))

  // Add match score badge if present
  if (item._matchScore !== undefined) {
    const badgeElement = getMatchScoreBadge(item._matchScore)
    if (badgeElement) {
      labelDiv.appendChild(badgeElement)
    }
  }

  // Header actions container
  const headerActions = document.createElement('div')
  headerActions.className = 'item-header-actions'

  // Edit button
  const editBtn = document.createElement('button')
  editBtn.className = 'action-btn'
  editBtn.setAttribute('data-action', 'edit-item')
  editBtn.setAttribute('data-item-id', item.id)
  editBtn.title = 'Edit item'
  editBtn.appendChild(createIconElement(icons.edit))
  headerActions.appendChild(editBtn)

  /*
  // Open in Teampass button
  const teampassBtn = document.createElement('button')
  teampassBtn.className = 'action-btn'
  teampassBtn.setAttribute('data-action', 'open-in-teampass')
  teampassBtn.setAttribute('data-item-id', item.id)
  teampassBtn.title = 'Open in Teampass'
  teampassBtn.appendChild(createIconElement(icons.link))
  headerActions.appendChild(teampassBtn)
  */

  // Open URL button (if URL exists)
  if (item.url) {
    const urlBtn = document.createElement('button')
    urlBtn.className = 'action-btn'
    urlBtn.setAttribute('data-action', 'open-url')
    urlBtn.setAttribute('data-item-url', item.url)
    urlBtn.title = 'Open in new tab'
    urlBtn.appendChild(createIconElement(icons.externallink))
    headerActions.appendChild(urlBtn)
  } else {
    const spacer = document.createElement('div')
    spacer.className = 'item-spacer'
    headerActions.appendChild(spacer)
  }

  headerRow.appendChild(labelDiv)
  headerRow.appendChild(headerActions)
  contentContainer.appendChild(headerRow)

  // Second row (login and actions)
  const secondRow = document.createElement('div')
  secondRow.className = 'item-row'

  // Login display
  if (item.login) {
    const loginDiv = document.createElement('div')
    loginDiv.className = 'item-login'
    loginDiv.appendChild(document.createTextNode(item.login))
    secondRow.appendChild(loginDiv)
  } else {
    const spacer = document.createElement('div')
    spacer.className = 'item-spacer'
    secondRow.appendChild(spacer)
  }

  // Item actions container
  const itemActions = document.createElement('div')
  itemActions.className = 'item-actions'

  // Copy login button (if login exists)
  if (item.login) {
    const copyLoginBtn = document.createElement('button')
    copyLoginBtn.className = 'action-btn'
    copyLoginBtn.setAttribute('data-action', 'copy-login')
    copyLoginBtn.setAttribute('data-value', item.login)
    copyLoginBtn.title = i18n.t('action.copyLoginToClipboard')
    copyLoginBtn.appendChild(createIconElement(icons.copy))
    itemActions.appendChild(copyLoginBtn)
  }

  // Copy password button
  const copyPwdBtn = document.createElement('button')
  copyPwdBtn.className = 'action-btn'
  copyPwdBtn.setAttribute('data-action', 'copy-password')
  copyPwdBtn.setAttribute('data-item-id', item.id)
  copyPwdBtn.title = i18n.t('action.copyPasswordToClipboard')
  copyPwdBtn.appendChild(createIconElement(icons.key))
  itemActions.appendChild(copyPwdBtn)

  // OTP button (if has_otp is truthy)
  if (item.has_otp && item.has_otp !== 0 && item.has_otp !== '0' && item.has_otp !== false && item.has_otp !== 'false') {
    const otpBtn = document.createElement('button')
    otpBtn.className = 'action-btn'
    otpBtn.setAttribute('data-action', 'get-otp')
    otpBtn.setAttribute('data-item-id', item.id)
    otpBtn.title = i18n.t('content.autofill.getTotpCode')
    otpBtn.appendChild(createIconElement(icons.qrcode))
    itemActions.appendChild(otpBtn)
  }

  // Auto-fill button (if login exists)
  if (item.login) {
    const fillBtn = document.createElement('button')
    fillBtn.className = 'action-btn'
    fillBtn.setAttribute('data-action', 'fill-form')
    fillBtn.setAttribute('data-item-id', item.id)
    fillBtn.title = i18n.t('content.autofill.autoFillTotp')
    fillBtn.appendChild(createIconElement(icons.sparkles))
    itemActions.appendChild(fillBtn)
  }

  secondRow.appendChild(itemActions)
  contentContainer.appendChild(secondRow)

  // Assembler la carte avec favicon à gauche et contenu à droite
  card.appendChild(faviconContainer)
  card.appendChild(contentContainer)

  return card
}

function displayItems(items) {
  debugLog('=== DISPLAY ITEMS DEBUG ===')
  debugLog('Number of items:', items.length)

  // Log each item to see if has_otp is present
  items.forEach((item, index) => {
    debugLog(`Item ${index}:`, {
      id: item.id,
      label: item.label,
      _matchScore: item._matchScore,
      has_otp: item.has_otp,
      has_otp_type: typeof item.has_otp,
      has_otp_value: JSON.stringify(item.has_otp),
      otp_enabled: item.otp_enabled,
      // Log all keys to see what's available
      keys: Object.keys(item)
    })
  })

  // Clear items list and rebuild using safe DOM manipulation
  displays.itemsList.innerHTML = ''

  // Create and append each item card
  items.forEach((item, index) => {
    const card = createItemCard(item, index)
    displays.itemsList.appendChild(card)
  })

  debugLog('=== END DISPLAY ITEMS DEBUG ===')

  // Add event listeners to action buttons
  document.querySelectorAll('.action-btn').forEach(btn => {
    btn.addEventListener('click', handleItemAction)
  })

  // Add event listeners to clickable labels
  document.querySelectorAll('.clickable-label').forEach(label => {
    label.addEventListener('click', handleItemAction)
  })
}

async function handleItemAction(event) {
  const button = event.currentTarget
  const action = button.dataset.action
  const itemId = button.dataset.itemId
  const folderId = button.dataset.folderId
  const value = button.dataset.value
  const itemUrl = button.dataset.itemUrl
  
  try {
    switch (action) {
      case 'view-item':
        await handleViewItem(itemId)
        break

      case 'edit-item':
        await handleEditItem(itemId)
        break

      case 'open-in-teampass':
        await handleOpenItemInTeampass(itemId)
        break

      case 'copy-login':
        await copyToClipboard(value)
        showToast(i18n.t('popup.items.loginCopied'))
        break

      case 'copy-password':
        await copyPassword(itemId)
        break

      case 'get-otp':
        await getOtp(itemId)
        break

      case 'fill-form':
        await fillForm(itemId)
        break

      case 'open-url':
        await openExternalLink(itemUrl)
        break
    }
  } catch (error) {
    console.error('Action failed:', error)
    showToast(i18n.t('popup.items.actionFailed', { message: error.message }), 'error')
  }
}

/**
 * Handle viewing an item
 * @param {number} itemId - Item ID
 */
async function handleViewItem(itemId) {
  try {
    debugLog('Opening view screen for item:', itemId)

    // Show loading state
    showScreen('loading')

    // Get item details from service worker
    const item = await sendMessage('getItemDetails', { itemId: parseInt(itemId) })

    if (!item) {
      throw new Error('Item not found')
    }

    currentEditItem = item // Store for potential edit action
    debugLog('Loaded item for viewing:', item)

    // Populate view screen with item data
    await populateViewScreen(item)

    // Show view screen
    showScreen('view')

  } catch (error) {
    console.error('Failed to load item for viewing:', error)
    showToast('❌ ' + i18n.t('popup.items.failedToLoadItem', { message: error.message }), 'error')
    showScreen('main')
  }
}

/**
 * Populate view screen with item data
 * @param {object} item - Item data
 */
async function populateViewScreen(item) {
  debugLog('Populating view screen with item:', item)

  document.getElementById('viewLabel').textContent = item.label || '-'
  document.getElementById('viewLogin').textContent = item.login || '-'
  document.getElementById('viewEmail').textContent = item.email || '-'
  document.getElementById('viewUrl').textContent = item.url || '-'
  document.getElementById('viewDescription').textContent = item.description || '-'
  document.getElementById('viewTags').textContent = item.tags || '-'
  document.getElementById('viewIcon').textContent = item.icon || '-'
  document.getElementById('viewAnyoneCanModify').textContent = item.anyone_can_modify === "1" ? i18n.t('common.yes') : i18n.t('common.no')

  // Store password for toggle functionality
  const passwordElement = document.getElementById('viewPassword')
  passwordElement.textContent = '••••••••'
  passwordElement.dataset.password = item.pwd || ''
  passwordElement.dataset.visible = 'false'

  // Display folder name (API returns id_tree and folder_label)
  const folderElement = document.getElementById('viewFolder')
  const folderId = item.id_tree || item.folder_id

  if (folderId) {
    // Use folder_label if available (returned by API)
    if (item.folder_label) {
      folderElement.textContent = item.folder_label
    } else {
      // Otherwise fetch folders to get folder name
      try {
        const folders = await sendMessage('listFolders')
        const folder = folders.find(f => f.id === parseInt(folderId))

        if (folder) {
          folderElement.textContent = folder.label || folder.title || `Folder ID: ${folderId}`
        } else {
          folderElement.textContent = `Folder ID: ${folderId}`
        }
      } catch (error) {
        console.error('Failed to load folder name:', error)
        folderElement.textContent = `Folder ID: ${folderId}`
      }
    }
  } else {
    folderElement.textContent = '-'
  }

  debugLog('View screen populated successfully')
}

/**
 * Handle back from view screen
 */
function handleBackFromView() {
  showScreen('main')
  currentEditItem = null
}

/**
 * Handle edit from view screen
 */
async function handleEditFromView() {
  if (currentEditItem) {
    await handleEditItem(currentEditItem.id)
  }
}

/**
 * Toggle password visibility in view screen
 */
function handleViewPasswordToggle() {
  const passwordElement = document.getElementById('viewPassword')
  const isVisible = passwordElement.dataset.visible === 'true'

  if (isVisible) {
    passwordElement.textContent = '••••••••'
    passwordElement.dataset.visible = 'false'
  } else {
    passwordElement.textContent = passwordElement.dataset.password || '-'
    passwordElement.dataset.visible = 'true'
  }
}

/**
 * Handle delete item from view screen
 */
async function handleDeleteItem() {
  if (!currentEditItem) {
    showToast('❌ ' + i18n.t('popup.items.noItemSelected'), 'error')
    return
  }

  // Show confirmation dialog
  const confirmed = confirm(`Are you sure you want to delete "${currentEditItem.label}"?\n\nThis action cannot be undone.`)

  if (!confirmed) {
    return
  }

  try {
    // Show loading state
    showScreen('loading')

    // Send delete request
    await sendMessage('deleteItem', { itemId: parseInt(currentEditItem.id) })

    // Show success message
    showToast('✅ ' + i18n.t('popup.items.itemDeleted'))

    // Clear current edit item
    currentEditItem = null

    // Go back to main screen
    showScreen('main')

    // Reload items with proper error handling
    try {
      // If we were in search mode, re-run the search to update results
      // Otherwise, reload items for current page
      if (isSearchMode && inputs.globalSearch && inputs.globalSearch.value.trim()) {
        debugLog('Re-running search after deletion...')
        await handleGlobalSearch()
      } else {
        await loadItemsForCurrentPage()
      }
    } catch (reloadError) {
      // Log error but don't prevent showing the success message
      console.error('Failed to reload items after deletion:', reloadError)
      // Display items list even if empty to avoid blank screen
      displayItems([])
    }

    // Update badge count (non-blocking, ignore errors)
    try {
      await sendMessage('updateBadge')
    } catch (badgeError) {
      // Silently ignore badge update errors
      console.warn('Failed to update badge after deletion:', badgeError)
    }

  } catch (error) {
    console.error('Failed to delete item:', error)
    showToast('❌ ' + i18n.t('popup.items.failedToDeleteItem', { message: error.message }), 'error')
    // Return to view screen on error
    showScreen('view')
  }
}

async function handleEditItem(itemId) {
  try {
    debugLog('Opening edit screen for item:', itemId)

    // Show loading state
    showScreen('loading')

    // Get item details from service worker
    const item = await sendMessage('getItemDetails', { itemId: parseInt(itemId) })

    if (!item) {
      throw new Error('Item not found')
    }

    currentEditItem = item
    debugLog('Loaded item for editing:', item)

    // Load folders list
    await loadFoldersForEdit()

    // Update favorite folder button state
    await updateFavoriteFolderButtonsState()

    // Populate form with item data
    populateEditForm(item)

    // Show edit screen
    showScreen('edit')

  } catch (error) {
    console.error('Failed to load item for editing:', error)
    showToast('❌ ' + i18n.t('popup.items.failedToLoadItem', { message: error.message }), 'error')
    showScreen('main')
  }
}

/**
 * Load folders list for edit form with nested tree structure
 */
async function loadFoldersForEdit() {
  try {
    debugLog('Loading folders for edit form...')
    const select = inputs.editFolderId
    const searchInput = inputs.editFolderSearch

    if (!select) {
      console.error('Edit folder select element not found')
      return
    }

    // Show loading state
    select.innerHTML = ''
    select.appendChild(createLoadingOption(i18n.t('popup.addItem.folderSelect')))
    select.disabled = true
    if (searchInput) searchInput.disabled = true

    // Fetch writable folders (user can only move item to folders they can write to)
    const folders = await sendMessage('getWritableFolders')
    debugLog('Folders loaded:', folders)

    if (folders && folders.length > 0) {
      // Sort folders in tree order (parent followed by children)
      const sortedFolders = sortFoldersInTreeOrder(folders)

      // Store sorted folders globally for filtering
      allEditFolders = sortedFolders

      // Display all folders initially
      displayFilteredEditFolders(sortedFolders)

      select.disabled = false
      if (searchInput) searchInput.disabled = false
    } else {
      // No folders available
      select.innerHTML = '<option value="">No writable folders available</option>'
      select.disabled = true
      if (searchInput) searchInput.disabled = true
      console.warn('No writable folders available')
    }
  } catch (error) {
    console.error('Failed to load folders:', error)
    // Don't block edit if folders can't be loaded
    if (inputs.editFolderId) {
      inputs.editFolderId.innerHTML = '<option value="">Failed to load folders</option>'
      inputs.editFolderId.disabled = true
    }
    if (inputs.editFolderSearch) {
      inputs.editFolderSearch.disabled = true
    }
  }
}

/**
 * Open item in Teampass web interface
 *
 * @param {number} itemId - Item ID
 */
async function handleOpenItemInTeampass(itemId) {
  try {
    // Get Teampass URL from storage
    const storage = await chrome.storage.local.get(['teampass_url'])

    if (!storage.teampass_url) {
      showToast('❌ ' + i18n.t('popup.teampass.teampassUrlNotConfigured'), 'error')
      return
    }

    // Get item details to get folder_id (API returns id_tree)
    const item = await sendMessage('getItemDetails', { itemId: parseInt(itemId) })

    if (!item) {
      showToast('❌ ' + i18n.t('popup.items.itemNotFound'), 'error')
      return
    }

    // Construct URL to open item in Teampass
    // Format: https://teampass.example.com/index.php?page=items&group=FOLDER_ID&id=ITEM_ID
    const teampassUrl = new URL(storage.teampass_url)
    const folderId = item.id_tree || item.folder_id || 0
    const itemUrl = `${teampassUrl.origin}/index.php?page=items&group=${folderId}&id=${itemId}`

    debugLog('Opening item in Teampass:', itemUrl)

    // Open in new tab
    await chrome.tabs.create({
      url: itemUrl,
      active: true
    })

    showToast('✅ ' + i18n.t('popup.teampass.openingInTeampass'))

  } catch (error) {
    console.error('Failed to open item in Teampass:', error)
    showToast('❌ ' + i18n.t('popup.teampass.failedToOpenInTeampass'), 'error')
  }
}

/**
 * Open url in new tab
 *
 * @param {string} itemUrl- URL
 */
async function openExternalLink(itemUrl) {
  try {
    debugLog('Opening item in Teampass:', itemUrl)

    // Open in new tab
    await chrome.tabs.create({
      url: itemUrl,
      active: true
    })

    showToast('✅ ' + i18n.t('popup.teampass.openingInTeampass'))

  } catch (error) {
    console.error('Failed to open item in Teampass:', error)
    showToast('❌ ' + i18n.t('popup.teampass.failedToOpenInTeampass'), 'error')
  }
}

/**
 * Populate edit form with item data
 *
 * @param {object} item - Item details
 */
function populateEditForm(item) {
  debugLog('Populating edit form with item:', item)

  inputs.editLabel.value = item.label || ''
  inputs.editLogin.value = item.login || ''
  inputs.editPassword.value = item.pwd || ''
  inputs.editEmail.value = item.email || ''
  inputs.editUrl.value = item.url || ''
  inputs.editDescription.value = item.description || ''
  inputs.editTags.value = item.tags || ''
  inputs.editIcon.value = item.icon || ''
  inputs.editAnyoneCanModify.checked = item.anyone_can_modify === 1 || item.anyone_can_modify === true
  inputs.editTotp.value = item.totp || ''

  // Pre-select folder if item has one (API returns id_tree or folder_id)
  const itemFolderId = item.id_tree || item.folder_id

  if (itemFolderId) {
    const folderId = itemFolderId.toString()
    debugLog('Attempting to pre-select folder:', folderId, item.folder_label ? `(${item.folder_label})` : '')

    // Set the value
    inputs.editFolderId.value = folderId

    // Verify selection worked
    if (inputs.editFolderId.value === folderId) {
      debugLog('Folder successfully selected:', folderId)
    } else {
      console.warn('Failed to select folder:', folderId, 'Available options:',
        Array.from(inputs.editFolderId.options).map(o => o.value))
      // If folder not found in list, add it as a disabled option to show current value
      const currentOption = document.createElement('option')
      currentOption.value = folderId
      currentOption.textContent = item.folder_label ? `${item.folder_label} (Current folder)` : `Current folder (ID: ${folderId})`
      currentOption.selected = true
      currentOption.disabled = true
      inputs.editFolderId.insertBefore(currentOption, inputs.editFolderId.firstChild)
    }
  } else {
    // Explicitly select empty option
    inputs.editFolderId.value = ''
    debugLog('No folder assigned to item')
  }

  // Clear any previous messages
  messages.edit.style.display = 'none'

  // Reset button state (in case it was left disabled from previous submit)
  buttons.editUpdate.disabled = false
  buttons.editUpdate.textContent = 'Save Update'

  debugLog('Form populated successfully')
}

/**
 * Handle edit form submission
 *
 * @param {Event} event - Submit event
 */
async function handleEditSubmit(event) {
  debugLog('=== EDIT FORM SUBMIT TRIGGERED ===')
  debugLog('Event:', event)
  event.preventDefault()

  debugLog('Current edit item:', currentEditItem)

  if (!currentEditItem) {
    console.error('No item loaded for editing!')
    showMessage(messages.edit, i18n.t('popup.editItem.noItemLoaded'), 'error')
    return
  }

  debugLog('Disabling submit button...')
  // Disable submit button
  buttons.editUpdate.disabled = true
  buttons.editUpdate.textContent = i18n.t('common.saving')

  debugLog('Starting try block...')
  debugLog('inputs object:', inputs)

  try {
    debugLog('Inside try block - collecting form data...')
    // Collect form data (only include fields that were modified)
    const itemData = {}

    debugLog('Checking label field...')
    debugLog('inputs.editLabel:', inputs.editLabel)
    debugLog('inputs.editLabel.value:', inputs.editLabel?.value)
    debugLog('currentEditItem.label:', currentEditItem.label)

    // Always include label if changed
    if (inputs.editLabel.value !== currentEditItem.label) {
      itemData.label = inputs.editLabel.value.trim()
      debugLog('Label changed, added to itemData:', itemData.label)
    }

    // Include other fields only if they changed
    if (inputs.editLogin.value !== (currentEditItem.login || '')) {
      itemData.login = inputs.editLogin.value.trim()
    }

    if (inputs.editPassword.value !== (currentEditItem.pwd || '')) {
      itemData.password = inputs.editPassword.value
    }

    if (inputs.editEmail.value !== (currentEditItem.email || '')) {
      itemData.email = inputs.editEmail.value.trim()
    }

    if (inputs.editUrl.value !== (currentEditItem.url || '')) {
      itemData.url = inputs.editUrl.value.trim()
    }

    if (inputs.editDescription.value !== (currentEditItem.description || '')) {
      itemData.description = inputs.editDescription.value.trim()
    }

    if (inputs.editTags.value !== (currentEditItem.tags || '')) {
      itemData.tags = inputs.editTags.value.trim()
    }

    // Check folder change (API uses id_tree)
    const currentFolderId = currentEditItem.id_tree || currentEditItem.folder_id
    if (inputs.editFolderId.value && inputs.editFolderId.value !== (currentFolderId || '').toString()) {
      itemData.folder_id = parseInt(inputs.editFolderId.value)
    }

    if (inputs.editIcon.value !== (currentEditItem.icon || '')) {
      itemData.icon = inputs.editIcon.value.trim()
    }

    if (inputs.editTotp.value !== (currentEditItem.totp || '')) {
      itemData.totp = inputs.editTotp.value.trim()
    }

    const anyoneCanModify = inputs.editAnyoneCanModify.checked ? 1 : 0
    if (anyoneCanModify !== (currentEditItem.anyone_can_modify || 0)) {
      itemData.anyone_can_modify = anyoneCanModify
    }

    // Check if at least one field was modified
    if (Object.keys(itemData).length === 0) {
      showMessage(messages.edit, i18n.t('popup.editItem.noChangesDetected'), 'error')
      buttons.editUpdate.disabled = false
      buttons.editUpdate.textContent = 'Save Update'
      return
    }

    debugLog('Updating item with data:', itemData)

    // Send update request
    const response = await sendMessage('updateItem', {
      itemId: parseInt(currentEditItem.id),
      itemData: itemData
    })

    debugLog('Update response:', response)

    // Show success message
    showMessage(messages.edit, '✅ ' + i18n.t('popup.editItem.itemUpdated'), 'success')

    // Go back to main screen after 1 second
    setTimeout(() => {
      showScreen('main')
      // Reload items list
      loadItemsForCurrentPage()
    }, 1000)

  } catch (error) {
    console.error('Update failed:', error)
    showMessage(messages.edit, '❌ ' + i18n.t('popup.editItem.failedToUpdateItem', { message: error.message }), 'error')
    // Re-enable button and reset text only on error (so user can retry)
    buttons.editUpdate.disabled = false
    buttons.editUpdate.textContent = 'Save Update'
  }
  // Note: On success, button stays disabled until form closes and reopens (via populateEditForm)
}

/**
 * Handle back from edit button
 */
function handleBackFromEdit() {
  showScreen('main')
  currentEditItem = null
}

async function copyToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text)
  } catch (error) {
    // Fallback for older browsers
    const textarea = document.createElement('textarea')
    textarea.value = text
    textarea.style.position = 'fixed'
    textarea.style.opacity = '0'
    document.body.appendChild(textarea)
    textarea.select()
    document.execCommand('copy')
    document.body.removeChild(textarea)
  }
}

async function copyPassword(itemId) {
  try {
    // Request password from service worker (will decrypt it)
    const password = await sendMessage('getItemPassword', { itemId })

    if (password) {
      await copyToClipboard(password)
      showToast(i18n.t('popup.password.passwordCopied'))
      // Increment actions counter for telemetry
      await licenceChecker.incrementActionsCount()
    } else {
      showToast(i18n.t('popup.password.noPasswordToCopy'), 'error')
    }
  } catch (error) {
    console.error('Copy password error:', error)
    showToast(i18n.t('popup.password.failedToCopyPassword'), 'error')
  }
}

async function fillForm(itemId) {
  try {
    // Get item details
    const item = await sendMessage('getItemDetails', { itemId })

    if (!item || !item.login || !item.pwd) {
      showToast(i18n.t('popup.form.missingLoginOrPassword'), 'error')
      return
    }

    // Send message to content script to fill the form
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })

    const response = await chrome.tabs.sendMessage(tab.id, {
      action: 'fillForm',
      data: {
        username: item.login,
        password: item.pwd
      }
    })

    if (response && response.success) {
      showToast('✅ ' + i18n.t('popup.form.formFilledSuccessfully'))
      // Increment actions counter for telemetry
      await licenceChecker.incrementActionsCount()
    } else {
      showToast('❌ ' + i18n.t('popup.form.couldNotFindLoginForm'), 'error')
    }

  } catch (error) {
    console.error('Fill form error:', error)

    // Check if it's a connection error (content script not injected)
    if (error.message && error.message.includes('Receiving end does not exist')) {
      showToast('❌ ' + i18n.t('popup.form.pleaseReloadPageFirst'), 'error')
    } else {
      showToast('❌ ' + i18n.t('popup.form.failedToFillForm'), 'error')
    }
  }
}

/**
 * Get OTP/TOTP code for an item
 * 
 * @param {number} itemId - Item ID
 * @returns {Promise<void>}
 */
async function getOtp(itemId) {
  try {
    debugLog('Getting OTP for item:', itemId)

    // Call service worker to get OTP code
    const response = await sendMessage('getOtp', { itemId })

    debugLog('OTP response:', response)

    if (!response || !response.otp_code) {
      showToast('❌ ' + i18n.t('popup.otp.failedToCopyOtp'), 'error')
      return
    }

    // Show OTP modal with countdown
    showOtpModal(response.otp_code, response.expires_in || 30)

    // Copy to clipboard automatically
    await copyToClipboard(response.otp_code)

    // Increment actions counter for telemetry
    await licenceChecker.incrementActionsCount()

  } catch (error) {
    console.error('Get OTP error:', error)
    showToast('❌ ' + i18n.t('popup.otp.failedToCopyOtp'), 'error')
  }
}

/**
 * Open item in Teampass web interface
 *
 * @param {number} itemId - Item ID
 * @param {number} folderId - Folder ID
 * @returns {Promise<void>}
 */
async function openInTeampass(itemId, folderId) {
  try {
    // Get Teampass URL from storage
    const storage = await chrome.storage.local.get(['teampass_url'])

    if (!storage.teampass_url) {
      showToast('❌ ' + i18n.t('popup.teampass.teampassUrlNotConfigured'), 'error')
      return
    }

    // Build URL: http://localhost/TeamPass/index.php?page=items&group=639&id=2295
    const teampassUrl = `${storage.teampass_url}/index.php?page=items&group=${folderId}&id=${itemId}`

    // Open in new tab
    await chrome.tabs.create({
      url: teampassUrl,
      active: true
    })

    debugLog('Opened item in Teampass:', teampassUrl)

  } catch (error) {
    console.error('Open in Teampass error:', error)
    showToast('❌ ' + i18n.t('popup.teampass.failedToOpenInTeampass'), 'error')
  }
}

/**
 * Show OTP modal with countdown timer
 *
 * @param {string} otpCode - 6-digit OTP code
 * @param {number} expiresIn - Seconds until expiration
 * @returns {void}
 */
function showOtpModal(otpCode, expiresIn) {
  // Remove existing modal if any
  const existingModal = document.getElementById('otpModal')
  if (existingModal) {
    existingModal.remove()
  }
  
  // Create modal
  const modal = document.createElement('div')
  modal.id = 'otpModal'
  modal.className = 'otp-modal'

  // Create and append modal content safely
  const modalContent = createOTPModalContent(otpCode, expiresIn)
  modal.appendChild(modalContent)

  document.body.appendChild(modal)
  
  // Animate in
  setTimeout(() => modal.classList.add('show'), 10)
  
  // Close button
  document.getElementById('otpClose').addEventListener('click', () => {
    modal.classList.remove('show')
    setTimeout(() => modal.remove(), 300)
  })
  
  // Click outside to close
  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      modal.classList.remove('show')
      setTimeout(() => modal.remove(), 300)
    }
  })
  
  // Countdown timer
  let timeLeft = expiresIn
  const countdownEl = document.getElementById('otpCountdown')
  const timerBar = document.getElementById('otpTimerBar')
  
  const interval = setInterval(() => {
    timeLeft--
    countdownEl.textContent = timeLeft
    
    // Update progress bar
    const progress = (timeLeft / expiresIn) * 100
    timerBar.style.width = progress + '%'
    
    // Change color when time is running out
    if (timeLeft <= 5) {
      timerBar.style.background = 'linear-gradient(90deg, #f56565 0%, #e53e3e 100%)'
    }
    
    // Close modal when expired
    if (timeLeft <= 0) {
      clearInterval(interval)
      showToast('⏱️ ' + i18n.t('popup.otp.otpCodeExpired'), 'error')
      modal.classList.remove('show')
      setTimeout(() => modal.remove(), 300)
    }
  }, 1000)
  
  // Clean up interval on manual close
  modal.addEventListener('remove', () => clearInterval(interval))
}

function showToast(message, type = 'success') {
  const toast = document.getElementById('toast')
  
  if (!toast) {
    // Fallback: create toast element if not found
    const newToast = document.createElement('div')
    newToast.id = 'toast'
    newToast.className = 'toast'
    document.body.appendChild(newToast)
  }
  
  const toastElement = document.getElementById('toast')
  toastElement.textContent = message
  toastElement.className = `toast ${type} show`
  
  setTimeout(() => {
    toastElement.className = 'toast'
  }, 3000)
}

function escapeHtml(text) {
  const div = document.createElement('div')
  div.textContent = text
  return div.innerHTML
}

/**
 * DOM Helper Functions to replace unsafe innerHTML usage
 * These functions provide safe alternatives to innerHTML by using createElement and textContent
 */

/**
 * Create a folder option element for a select dropdown
 * @param {Object} folder - Folder object with id, label, and level
 * @param {string|null} selectedId - ID of the selected folder
 * @returns {HTMLOptionElement} Option element
 */
function createFolderOption(folder, selectedId = null) {
  const option = document.createElement('option')
  option.value = folder.id

  // Create indentation based on level using non-breaking spaces
  const indent = folder.level > 0 ? '\u00A0\u00A0'.repeat(folder.level * 2) : ''
  const prefix = folder.level > 0 ? '└─ ' : ''
  const label = folder.label || `Folder ${folder.id}`

  option.textContent = indent + prefix + label

  if (folder.id === selectedId) {
    option.selected = true
  }

  return option
}

/**
 * Populate a select element with folder options
 * @param {HTMLSelectElement} select - Select element to populate
 * @param {Array} folders - Array of folder objects
 * @param {string} defaultText - Text for the default empty option
 * @param {string|null} selectedId - ID of the selected folder
 */
function populateFolderSelect(select, folders, defaultText, selectedId = null) {
  // Clear existing options
  select.innerHTML = ''

  // Add default option
  const defaultOption = document.createElement('option')
  defaultOption.value = ''
  defaultOption.textContent = defaultText
  select.appendChild(defaultOption)

  // Add folder options
  folders.forEach(folder => {
    select.appendChild(createFolderOption(folder, selectedId))
  })
}

/**
 * Create an icon element from Font Awesome class
 * @param {string} iconHtml - HTML string containing icon (e.g., '<i class="fas fa-lock"></i>')
 * @returns {HTMLElement} Icon element
 */
function createIconElement(iconHtml) {
  // Check if it's an emoji (no HTML tags)
  if (!iconHtml.includes('<')) {
    // It's an emoji - return a text node wrapped in a span
    const span = document.createElement('span')
    span.textContent = iconHtml
    span.className = 'icon-emoji'
    return span
  }

  // Parse the icon HTML to extract the class (FontAwesome)
  const match = iconHtml.match(/class="([^"]+)"/)
  if (match) {
    const i = document.createElement('i')
    i.className = match[1]
    return i
  }
  // Fallback: return empty span if parsing fails
  return document.createElement('span')
}

/**
 * Get password maximum length from JWT
 * @returns {Promise<number>} Maximum password length (default: 64)
 */
async function getPasswordMaxLength() {
  try {
    const storage = await chrome.storage.local.get(['teampass_token'])
    if (!storage.teampass_token) {
      return 64 // Default if no token
    }

    // Decode JWT to extract pwd_maximum_length
    const parts = storage.teampass_token.split('.')
    if (parts.length !== 3) {
      return 64 // Invalid JWT format
    }

    // Decode base64url payload
    const payload = parts[1]
    const base64 = payload.replace(/-/g, '+').replace(/_/g, '/')
    const padded = base64.padEnd(base64.length + (4 - base64.length % 4) % 4, '=')
    const decoded = atob(padded)
    const jwtPayload = JSON.parse(decoded)

    // Return pwd_maximum_length or default to 64
    return jwtPayload.pwd_maximum_length ? parseInt(jwtPayload.pwd_maximum_length, 10) : 64
  } catch (error) {
    console.error('Error getting password max length from JWT:', error)
    return 64 // Fallback to default
  }
}

/**
 * Set button icon safely
 * @param {HTMLElement} button - Button element
 * @param {string} iconHtml - Icon HTML string
 */
function setButtonIcon(button, iconHtml) {
  // Clear existing content
  button.innerHTML = ''
  // Add icon element
  button.appendChild(createIconElement(iconHtml))
}

/**
 * Create a loading option for select elements
 * @param {string} loadingText - Loading text to display
 * @returns {HTMLOptionElement} Loading option element
 */
function createLoadingOption(loadingText) {
  const option = document.createElement('option')
  option.value = ''
  option.textContent = loadingText
  return option
}

/**
 * Set select to show a single message option (for errors/no results)
 * @param {HTMLSelectElement} select - Select element
 * @param {string} message - Message to display
 */
function setSelectMessage(select, message) {
  select.innerHTML = ''
  const option = document.createElement('option')
  option.value = ''
  option.textContent = message
  select.appendChild(option)
}

/**
 * Set icon content safely (handles both emoji and HTML icons)
 * @param {HTMLElement} element - Element to set icon in
 * @param {string} iconContent - Icon content (emoji or HTML string)
 */
function setIconContent(element, iconContent) {
  // Clear existing content
  element.innerHTML = ''

  // Check if it's HTML (contains '<') or just text/emoji
  if (iconContent.includes('<')) {
    // It's HTML, create icon element
    element.appendChild(createIconElement(iconContent))
  } else {
    // It's plain text/emoji
    element.textContent = iconContent
  }
}

/**
 * Create OTP modal content safely
 * @param {string} otpCode - OTP code to display
 * @param {number} expiresIn - Seconds until expiration
 * @returns {HTMLElement} Modal content element
 */
function createOTPModalContent(otpCode, expiresIn) {
  const content = document.createElement('div')
  content.className = 'otp-modal-content'

  // Header
  const header = document.createElement('div')
  header.className = 'otp-header'

  const iconSpan = document.createElement('span')
  iconSpan.className = 'otp-icon'
  setIconContent(iconSpan, icons.qrcode)

  const titleSpan = document.createElement('span')
  titleSpan.className = 'otp-title'
  titleSpan.textContent = 'TOTP Code'

  const closeBtn = document.createElement('button')
  closeBtn.className = 'otp-close'
  closeBtn.id = 'otpClose'
  closeBtn.textContent = '✕'

  header.appendChild(iconSpan)
  header.appendChild(titleSpan)
  header.appendChild(closeBtn)

  // OTP Code display
  const codeDiv = document.createElement('div')
  codeDiv.className = 'otp-code'
  codeDiv.id = 'otpCode'
  codeDiv.textContent = otpCode

  // Footer
  const footer = document.createElement('div')
  footer.className = 'otp-footer'

  const timer = document.createElement('div')
  timer.className = 'otp-timer'

  const timerBar = document.createElement('div')
  timerBar.className = 'otp-timer-bar'
  timerBar.id = 'otpTimerBar'
  timer.appendChild(timerBar)

  const expiresDiv = document.createElement('div')
  expiresDiv.className = 'otp-expires'
  expiresDiv.textContent = 'Expires in '

  const countdownSpan = document.createElement('span')
  countdownSpan.id = 'otpCountdown'
  countdownSpan.textContent = expiresIn.toString()

  expiresDiv.appendChild(countdownSpan)
  expiresDiv.appendChild(document.createTextNode('s'))

  footer.appendChild(timer)
  footer.appendChild(expiresDiv)

  // Copied message
  const copiedMsg = document.createElement('div')
  copiedMsg.className = 'otp-copied-message'
  copiedMsg.textContent = '✅ Copied to clipboard!'

  // Assemble content
  content.appendChild(header)
  content.appendChild(codeDiv)
  content.appendChild(footer)
  content.appendChild(copiedMsg)

  return content
}

/**
 * Create password generator modal content safely
 * @param {number} savedLength - Saved password length
 * @param {number} maxLength - Maximum password length from JWT (default: 64)
 * @returns {HTMLElement} Modal content element
 */
function createPasswordGeneratorModalContent(savedLength, maxLength = 64) {
  const content = document.createElement('div')
  content.className = 'password-gen-modal-content'

  // Header
  const header = document.createElement('div')
  header.className = 'password-gen-header'

  const titleWrapper = document.createElement('div')
  titleWrapper.className = 'password-gen-title-wrapper'

  const iconSpan = document.createElement('span')
  iconSpan.className = 'password-gen-icon'
  setIconContent(iconSpan, icons.key)

  const titleSpan = document.createElement('span')
  titleSpan.className = 'password-gen-title'
  titleSpan.textContent = i18n.t('popup.passwordGenerator.title')

  titleWrapper.appendChild(iconSpan)
  titleWrapper.appendChild(titleSpan)

  const closeBtn = document.createElement('button')
  closeBtn.className = 'password-gen-close'
  closeBtn.id = 'passwordGenClose'
  closeBtn.textContent = '✕'

  header.appendChild(titleWrapper)
  header.appendChild(closeBtn)

  // Body
  const body = document.createElement('div')
  body.className = 'password-gen-body'

  // Length selector
  const lengthGroup = document.createElement('div')
  lengthGroup.className = 'gen-option-group'

  const lengthLabel = document.createElement('label')
  lengthLabel.className = 'gen-option-label'
  lengthLabel.textContent = i18n.t('popup.passwordGenerator.lengthLabel')

  const lengthControl = document.createElement('div')
  lengthControl.className = 'gen-length-control'

  const lengthSlider = document.createElement('input')
  lengthSlider.type = 'range'
  lengthSlider.id = 'genLengthSlider'
  lengthSlider.className = 'gen-length-slider'
  lengthSlider.min = '8'
  lengthSlider.max = maxLength.toString()
  lengthSlider.value = Math.min(savedLength, maxLength).toString()
  lengthSlider.step = '1'

  const lengthValue = document.createElement('div')
  lengthValue.className = 'gen-length-value'
  lengthValue.id = 'genLengthValue'
  lengthValue.textContent = savedLength.toString()

  lengthControl.appendChild(lengthSlider)
  lengthControl.appendChild(lengthValue)

  lengthGroup.appendChild(lengthLabel)
  lengthGroup.appendChild(lengthControl)

  // Character options
  const charGroup = document.createElement('div')
  charGroup.className = 'gen-option-group'

  const charLabel = document.createElement('label')
  charLabel.className = 'gen-option-label'
  charLabel.textContent = i18n.t('popup.passwordGenerator.characterTypesLabel')

  const charOptions = document.createElement('div')
  charOptions.className = 'gen-char-options'

  // Helper function to create checkbox wrapper
  const createCheckbox = (id, labelText, checked = true) => {
    const wrapper = document.createElement('div')
    wrapper.className = 'gen-checkbox-wrapper'

    const checkbox = document.createElement('input')
    checkbox.type = 'checkbox'
    checkbox.id = id
    if (checked) checkbox.checked = true

    const label = document.createElement('label')
    label.setAttribute('for', id)
    label.textContent = labelText

    wrapper.appendChild(checkbox)
    wrapper.appendChild(label)

    return wrapper
  }

  charOptions.appendChild(createCheckbox('genLowercase', i18n.t('popup.passwordGenerator.lowercaseOption')))
  charOptions.appendChild(createCheckbox('genUppercase', i18n.t('popup.passwordGenerator.uppercaseOption')))
  charOptions.appendChild(createCheckbox('genNumbers', i18n.t('popup.passwordGenerator.numbersOption')))
  charOptions.appendChild(createCheckbox('genSymbols', i18n.t('popup.passwordGenerator.symbolsOption')))

  charGroup.appendChild(charLabel)
  charGroup.appendChild(charOptions)

  // Generated password display
  const display = document.createElement('div')
  display.className = 'gen-display empty'
  display.id = 'genDisplay'
  display.textContent = i18n.t('popup.passwordGenerator.outputPlaceholder')

  body.appendChild(lengthGroup)
  body.appendChild(charGroup)
  body.appendChild(display)

  // Footer
  const footer = document.createElement('div')
  footer.className = 'password-gen-footer'

  const generateBtn = document.createElement('button')
  generateBtn.className = 'gen-btn gen-btn-generate'
  generateBtn.id = 'genGenerateBtn'
  generateBtn.title = 'Generate password'
  setIconContent(generateBtn, icons.refresh)

  const copyBtn = document.createElement('button')
  copyBtn.className = 'gen-btn gen-btn-copy'
  copyBtn.id = 'genCopyBtn'
  copyBtn.disabled = true
  copyBtn.title = 'Copy to clipboard'
  setIconContent(copyBtn, icons.copy)

  const useBtn = document.createElement('button')
  useBtn.className = 'gen-btn gen-btn-use'
  useBtn.id = 'genUseBtn'
  useBtn.disabled = true
  useBtn.title = 'Use this password'
  setIconContent(useBtn, icons.check)

  footer.appendChild(generateBtn)
  footer.appendChild(copyBtn)
  footer.appendChild(useBtn)

  // Assemble content
  content.appendChild(header)
  content.appendChild(body)
  content.appendChild(footer)

  return content
}

async function handleLogout() {
  closeMenu() // Close menu before logout
  
  try {
    await sendMessage('logout')
    
    inputs.username.value = ''
    inputs.password.value = ''
    inputs.apiKey.value = ''
    
    showScreen('login')
    
  } catch (error) {
    console.error('Logout failed:', error)
  }
}

function handleChangeServer() {
  showScreen('config')
}

async function handleRefresh() {
  closeMenu() // Close menu before refresh
  await loadItemsForCurrentPage()
}

/**
 * Handle re-authentication button click from login screen
 */
async function handleReauth() {
  const loader = document.getElementById('loginLoader')
  const messageEl = document.getElementById('loginMessage')

  try {
    // Disable button and show loader
    if (buttons.reauth) buttons.reauth.disabled = true
    if (loader) loader.style.display = 'block'
    if (messageEl) {
      messageEl.className = 'login-message'
      messageEl.style.display = 'none'
    }

    // Try to get stored credentials and re-authenticate
    const result = await sendMessage('ensureValidToken')

    if (result) {
      // Success - reload the main screen
      if (messageEl) {
        messageEl.className = 'login-message success'
        messageEl.textContent = '✅ Authentication successful!'
        messageEl.style.display = 'block'
      }

      // Wait a bit to show success message, then load main screen
      setTimeout(async () => {
        await loadMainScreen()
      }, 1000)
    } else {
      // Failed - show error
      if (messageEl) {
        messageEl.className = 'login-message error'
        messageEl.textContent = '❌ Auto-authentication failed. Please configure credentials in Options.'
        messageEl.style.display = 'block'
      }
    }
  } catch (error) {
    console.error('Re-authentication error:', error)
    if (messageEl) {
      messageEl.className = 'login-message error'
      messageEl.textContent = '❌ ' + error.message
      messageEl.style.display = 'block'
    }
  } finally {
    // Hide loader and re-enable button
    if (loader) loader.style.display = 'none'
    if (buttons.reauth) buttons.reauth.disabled = false
  }
}

/**
 * Handle open options button click from login screen
 */
function handleOpenOptions() {
  chrome.runtime.openOptionsPage()
}

// Maintenance mode timer
let maintenanceRetryTimer = null
let maintenanceCountdown = null

/**
 * Show maintenance screen with automatic retry
 */
function showMaintenanceScreen() {
  debugLog('Showing maintenance screen')
  showScreen('maintenance')

  // Clear any existing timers
  if (maintenanceRetryTimer) clearTimeout(maintenanceRetryTimer)
  if (maintenanceCountdown) clearInterval(maintenanceCountdown)

  // Start countdown timer (30 seconds)
  let secondsRemaining = 30
  const timerElement = document.getElementById('maintenanceTimer')
  const timerTextElement = document.getElementById('maintenanceTimerText')

  if (timerElement && timerTextElement) {
    timerElement.style.display = 'flex'

    // Update countdown every second
    maintenanceCountdown = setInterval(() => {
      secondsRemaining--
      if (timerTextElement) {
        timerTextElement.textContent = i18n.t('popup.maintenance.autoRetry', { seconds: secondsRemaining })
      }

      if (secondsRemaining <= 0) {
        clearInterval(maintenanceCountdown)
      }
    }, 1000)
  }

  // Auto-retry after 30 seconds
  maintenanceRetryTimer = setTimeout(async () => {
    debugLog('Auto-retrying maintenance check...')
    await checkMaintenanceModeAndLoad()
  }, 30000)
}

/**
 * Check maintenance mode and load appropriate screen
 */
async function checkMaintenanceModeAndLoad() {
  const statusElement = document.getElementById('maintenanceStatus')
  const retryBtn = buttons.retryMaintenance

  try {
    // Show checking status
    if (statusElement) {
      statusElement.className = 'maintenance-status checking'
      statusElement.textContent = i18n.t('popup.maintenance.checking')
      statusElement.style.display = 'block'
    }

    // Disable retry button
    if (retryBtn) retryBtn.disabled = true

    // IMPORTANT: Force re-authentication to get fresh JWT from server
    // This will make an API call and return a new JWT with updated maintenance_mode
    debugLog('Forcing re-authentication to get fresh JWT...')
    const reauthed = await sendMessage('ensureValidToken')

    if (!reauthed) {
      debugLog('Re-authentication failed during maintenance check')
      // Failed to re-authenticate, show error and retry
      if (statusElement) {
        statusElement.className = 'maintenance-status error'
        statusElement.textContent = i18n.t('popup.maintenance.stillInMaintenance')
        statusElement.style.display = 'block'

        // Hide message after 5 seconds
        setTimeout(() => {
          if (statusElement) {
            statusElement.style.display = 'none'
          }
        }, 5000)
      }

      // Restart the countdown timer
      showMaintenanceScreen()
      return
    }

    // Now check the fresh JWT for maintenance mode
    const response = await chrome.runtime.sendMessage({ action: 'getJWTData' })

    if (response && response.success && response.data) {
      if (response.data.maintenanceMode === true) {
        debugLog('Server still in maintenance mode')

        // Show still in maintenance message
        if (statusElement) {
          statusElement.className = 'maintenance-status error'
          statusElement.textContent = i18n.t('popup.maintenance.stillInMaintenance')
          statusElement.style.display = 'block'

          // Hide message after 5 seconds
          setTimeout(() => {
            if (statusElement) {
              statusElement.style.display = 'none'
            }
          }, 5000)
        }

        // Restart the countdown timer
        showMaintenanceScreen()
      } else {
        debugLog('Maintenance mode ended, loading main screen')

        // Clear timers
        if (maintenanceRetryTimer) clearTimeout(maintenanceRetryTimer)
        if (maintenanceCountdown) clearInterval(maintenanceCountdown)

        // Load main screen
        await loadMainScreen()
      }
    } else {
      // Failed to get JWT data
      if (statusElement) {
        statusElement.className = 'maintenance-status error'
        statusElement.textContent = i18n.t('popup.maintenance.stillInMaintenance')
        statusElement.style.display = 'block'

        // Hide message after 5 seconds
        setTimeout(() => {
          if (statusElement) {
            statusElement.style.display = 'none'
          }
        }, 5000)
      }

      // Restart the countdown timer
      showMaintenanceScreen()
    }
  } catch (error) {
    console.error('Maintenance check error:', error)

    if (statusElement) {
      statusElement.className = 'maintenance-status error'
      statusElement.textContent = i18n.t('popup.maintenance.stillInMaintenance')
      statusElement.style.display = 'block'

      // Hide message after 5 seconds
      setTimeout(() => {
        if (statusElement) {
          statusElement.style.display = 'none'
        }
      }, 5000)
    }

    // Restart the countdown timer
    showMaintenanceScreen()
  } finally {
    // Re-enable retry button
    if (retryBtn) retryBtn.disabled = false
  }
}

/**
 * Handle retry maintenance button click
 */
async function handleRetryMaintenance() {
  debugLog('Manual retry maintenance check')

  // Clear existing timers
  if (maintenanceRetryTimer) clearTimeout(maintenanceRetryTimer)
  if (maintenanceCountdown) clearInterval(maintenanceCountdown)

  // Hide timer
  const timerElement = document.getElementById('maintenanceTimer')
  if (timerElement) timerElement.style.display = 'none'

  // Check maintenance mode
  await checkMaintenanceModeAndLoad()
}

/**
 * Toggle dropdown menu visibility
 *
 * @returns {void}
 */
function toggleMenu() {
  debugLog('toggleMenu called')
  debugLog('sections.dropdownMenu:', sections.dropdownMenu)
  debugLog('buttons.menu:', buttons.menu)

  if (!sections.dropdownMenu || !buttons.menu) {
    console.error('Menu elements not found!')
    return
  }

  const isOpen = sections.dropdownMenu.style.display === 'block'
  debugLog('Menu is currently:', isOpen ? 'OPEN' : 'CLOSED')
  
  if (isOpen) {
    closeMenu()
  } else {
    openMenu()
  }
}

/**
 * Open dropdown menu
 * 
 * @returns {void}
 */
function openMenu() {
  debugLog('openMenu called')

  if (!sections.dropdownMenu || !buttons.menu) {
    console.error('Cannot open menu - elements not found')
    return
  }

  sections.dropdownMenu.style.display = 'block'
  buttons.menu.classList.add('active')

  debugLog('Menu display set to:', sections.dropdownMenu.style.display)
  debugLog('Menu button active:', buttons.menu.classList.contains('active'))
}

/**
 * Close dropdown menu
 * 
 * @returns {void}
 */
function closeMenu() {
  debugLog('closeMenu called')

  if (!sections.dropdownMenu || !buttons.menu) return

  sections.dropdownMenu.style.display = 'none'
  buttons.menu.classList.remove('active')

  debugLog('Menu closed')
}

/**
 * Handle clicks outside the menu to close it
 * 
 * @param {MouseEvent} event - Click event
 * @returns {void}
 */
function handleOutsideClick(event) {
  if (!sections.dropdownMenu || !buttons.menu) return
  
  const isMenuOpen = sections.dropdownMenu.style.display === 'block'
  if (!isMenuOpen) return
  
  // Check if click is outside menu button and dropdown
  const isClickInsideMenu = buttons.menu.contains(event.target)
  const isClickInsideDropdown = sections.dropdownMenu.contains(event.target)
  
  if (!isClickInsideMenu && !isClickInsideDropdown) {
    closeMenu()
  }
}

/**
 * Load dark mode preference from storage
 * 
 * @returns {Promise<void>}
 */
async function loadDarkModePreference() {
  try {
    const storage = await chrome.storage.local.get(['dark_mode_enabled'])
    const isDarkMode = storage.dark_mode_enabled === true

    debugLog('Dark mode preference loaded:', isDarkMode)
    
    if (isDarkMode) {
      document.body.classList.add('dark-mode')
      updateDarkModeUI(true)
    } else {
      document.body.classList.remove('dark-mode')
      updateDarkModeUI(false)
    }
  } catch (error) {
    console.error('Failed to load dark mode preference:', error)
  }
}

/**
 * Toggle dark mode on/off
 * 
 * @returns {Promise<void>}
 */
async function toggleDarkMode() {
  try {
    const isDarkMode = document.body.classList.toggle('dark-mode')

    debugLog('Dark mode toggled:', isDarkMode)
    
    // Save preference to storage
    await chrome.storage.local.set({ dark_mode_enabled: isDarkMode })
    
    // Update UI
    updateDarkModeUI(isDarkMode)
    
    // Don't close menu - let user see the change
    
  } catch (error) {
    console.error('Failed to toggle dark mode:', error)
    showToast('❌ ' + i18n.t('popup.settings.darkModeEnabled'), 'error')
  }
}

/**
 * Update dark mode UI elements
 * 
 * @param {boolean} isDarkMode - Whether dark mode is enabled
 * @returns {void}
 */
function updateDarkModeUI(isDarkMode) {
  if (!displays.darkModeIcon || !displays.darkModeToggle) return

  if (isDarkMode) {
    displays.darkModeIcon.textContent = '☀️'
    displays.darkModeToggle.textContent = 'ON'
    displays.darkModeToggle.classList.add('active')
  } else {
    displays.darkModeIcon.textContent = '🌙'
    displays.darkModeToggle.textContent = 'OFF'
    displays.darkModeToggle.classList.remove('active')
  }
}

/**
 * Load icon style preference from storage
 *
 * @returns {Promise<void>}
 */
async function loadIconStylePreference() {
  try {
    const storage = await chrome.storage.local.get(['icon_style'])
    const iconStyle = storage.icon_style || 'fontawesome'

    debugLog('Icon style preference loaded:', iconStyle)

    // Update active icon set
    icons = iconSets[iconStyle]

    // Update UI
    updateIconStyleUI(iconStyle)
  } catch (error) {
    console.error('Failed to load icon style preference:', error)
  }
}

/**
 * Toggle icon style between Font Awesome and Emoji
 *
 * @returns {Promise<void>}
 */
async function toggleIconStyle() {
  try {
    const storage = await chrome.storage.local.get(['icon_style'])
    const currentStyle = storage.icon_style || 'fontawesome'
    const newStyle = currentStyle === 'fontawesome' ? 'emoji' : 'fontawesome'

    debugLog('Icon style toggled:', newStyle)

    // Update active icon set
    icons = iconSets[newStyle]

    // Save preference to storage
    await chrome.storage.local.set({ icon_style: newStyle })

    // Update UI
    updateIconStyleUI(newStyle)

    // Refresh the items list to show new icons
    await loadItemsForCurrentPage()

    showToast(i18n.t('popup.settings.iconStyleChanged'), 'success')

  } catch (error) {
    console.error('Failed to toggle icon style:', error)
    showToast(i18n.t('popup.settings.iconStyleChanged'), 'error')
  }
}

/**
 * Update icon style UI elements
 *
 * @param {string} iconStyle - Current icon style ('fontawesome' or 'emoji')
 * @returns {void}
 */
function updateIconStyleUI(iconStyle) {
  if (!displays.iconStyleToggle) return

  if (iconStyle === 'emoji') {
    displays.iconStyleToggle.textContent = 'Emoji'
    displays.iconStyleToggle.classList.add('active')
  } else {
    displays.iconStyleToggle.textContent = 'Font Awesome'
    displays.iconStyleToggle.classList.remove('active')
  }

  // Update all menu icons (including iconStyle icon)
  updateMenuIcons()
}

/**
 * Update menu icons based on current icon style
 * Updates all dropdown menu item icons
 */
function updateMenuIcons() {
  // Map of element IDs to icon names
  const menuIconMap = {
    'openTeampassBtn': 'link',
    'refreshBtn': 'refresh',
    'darkModeBtn': 'moon',
    'iconStyleBtn': 'iconset',
    'openOptionsBtn2': 'gear',
    'aboutBtn': 'info',
    'logoutBtn': 'logout'
  }

  // Update each menu item icon
  Object.entries(menuIconMap).forEach(([btnId, iconName]) => {
    const button = document.getElementById(btnId)
    if (button) {
      const iconSpan = button.querySelector('.menu-icon')
      if (iconSpan && icons[iconName]) {
        setIconContent(iconSpan, icons[iconName])
      }
    }
  })
}

/**
 * Handle pin button click - open/close detached window
 * If in normal popup: open as detached window
 * If in detached window: close window
 *
 * @returns {Promise<void>}
 */
/**
 * Handle open Teampass button click
 * Opens Teampass in a new tab
 * 
 * @returns {Promise<void>}
 */
async function handleOpenTeampass() {
  closeMenu() // Close menu before opening Teampass
  
  try {
    // Get Teampass URL from storage
    const storage = await chrome.storage.local.get(['teampass_url'])

    if (!storage.teampass_url) {
      showToast('❌ ' + i18n.t('popup.teampass.teampassUrlNotConfigured'), 'error')
      return
    }
    
    // Open Teampass in a new tab
    await chrome.tabs.create({
      url: storage.teampass_url,
      active: true
    })

    debugLog('Opened Teampass in new tab:', storage.teampass_url)
    
    // Optional: close popup after opening (uncomment if desired)
    // window.close()
    
  } catch (error) {
    console.error('Failed to open Teampass:', error)
    showToast('❌ ' + i18n.t('popup.teampass.failedToOpenInTeampass'), 'error')
  }
}

/**
 * Handle about button click
 * Shows the About screen within the extension
 * 
 * @returns {void}
 */
function handleAbout() {
  closeMenu() // Close menu before showing About

  try {
    // Populate About screen with text content
    const manifest = chrome.runtime.getManifest()
    document.getElementById('aboutVersion').textContent = `Version ${manifest.version}`

    // Description (title is auto-translated via data-i18n)
    document.getElementById('aboutDescText').textContent = i18n.t('popup.about.descriptionText')

    // Features (title is auto-translated via data-i18n)
    const featList = document.getElementById('aboutFeatList')
    featList.replaceChildren()
    const features = i18n.translations.popup.about.features
    features.forEach(item => {
      const li = document.createElement('li')
      li.textContent = item
      featList.appendChild(li)
    })

    // Security (title is auto-translated via data-i18n)
    const secList = document.getElementById('aboutSecList')
    secList.replaceChildren()
    const security = i18n.translations.popup.about.security
    security.forEach(item => {
      const li = document.createElement('li')
      li.textContent = item
      secList.appendChild(li)
    })

    // License (title is auto-translated via data-i18n)
    document.getElementById('aboutLicenseText').textContent = i18n.t('popup.about.licenseText')

    // Copyright
    const copyright = i18n.t('popup.about.copyright', { year: CONFIG.YEAR })
    document.getElementById('aboutCopyright').textContent = copyright

    // Show About screen
    showScreen('about')

    debugLog('Showing About screen')

  } catch (error) {
    console.error('Error showing About screen:', error)
    showToast('❌ ' + i18n.t('popup.about.failedToShowAbout'), 'error')
  }
}

/**
 * Handle back from About button
 * Returns to main screen
 *
 * @returns {void}
 */
function handleBackFromAbout() {
  showScreen('main')
}

/**
 * Handle account button click
 * Shows the account screen with user info, permissions and licence
 *
 * @returns {void}
 */
function handleAccount() {
  closeMenu() // Close menu before showing Account
  loadAccountScreen()
  debugLog('Showing Account screen')
}

/**
 * Handle back from Account button
 * Returns to main screen
 *
 * @returns {void}
 */
function handleBackFromAccount() {
  showScreen('main')
}

/**
 * Favorite Folder Functions
 */

/**
 * Update favorite folder display in Account screen
 */
async function updateFavoriteFolderDisplay() {
  const favoriteFolderName = document.getElementById('favoriteFolderName')

  if (!favoriteFolderName) return

  try {
    const storage = await chrome.storage.local.get(['teampass_favorite_folder_id'])

    if (storage.teampass_favorite_folder_id) {
      // Get folder name from cache or fetch
      const folders = await sendMessage('getWritableFolders')
      // Use == instead of === to handle string vs number comparison
      const favoriteFolder = folders.find(f => f.id == storage.teampass_favorite_folder_id)

      if (favoriteFolder) {
        favoriteFolderName.textContent = favoriteFolder.label
        favoriteFolderName.setAttribute('data-empty', 'false')
      } else {
        console.warn('Favorite folder not found in available folders. ID:', storage.teampass_favorite_folder_id)
        favoriteFolderName.textContent = i18n.t('popup.account.defineFavoriteFolder')
        favoriteFolderName.setAttribute('data-empty', 'true')
      }
    } else {
      favoriteFolderName.textContent = i18n.t('popup.account.defineFavoriteFolder')
      favoriteFolderName.setAttribute('data-empty', 'true')
    }
  } catch (error) {
    console.error('Failed to update favorite folder display:', error)
    favoriteFolderName.textContent = i18n.t('popup.account.defineFavoriteFolder')
    favoriteFolderName.setAttribute('data-empty', 'true')
  }
}

/**
 * Initialize language selector with saved language preference
 */
async function initializeLanguageSelector() {
  const languageSelect = document.getElementById('languageSelect')

  if (!languageSelect) return

  try {
    // Get saved language preference
    const storage = await chrome.storage.local.get(['teampass_preferred_language'])
    const savedLanguage = storage.teampass_preferred_language || 'en'

    // Load the saved language
    await i18n.init(savedLanguage)

    // Apply translations to DOM
    if (typeof applyDOMTranslations === 'function') {
      applyDOMTranslations()
    }

    // Update selector
    languageSelect.value = savedLanguage

    console.log('[Language] Initialized with language:', savedLanguage)
  } catch (error) {
    console.error('Failed to initialize language selector:', error)
    // Fallback to English
    languageSelect.value = 'en'
  }
}

/**
 * Handle language change
 */
async function handleLanguageChange(event) {
  const selectedLanguage = event.target.value

  try {
    // Save language preference
    await chrome.storage.local.set({ teampass_preferred_language: selectedLanguage })

    // Reload translations
    await i18n.init(selectedLanguage)

    // Apply translations to DOM
    if (typeof applyDOMTranslations === 'function') {
      applyDOMTranslations()
    }

    // Update dynamic content that uses i18n.t()
    await updateFavoriteFolderDisplay()

    // Show success message
    showToast(i18n.t('popup.account.languageChanged'), 'success')

    console.log('[Language] Changed to:', selectedLanguage)
  } catch (error) {
    console.error('Failed to change language:', error)
    showToast('Failed to change language', 'error')
  }
}

/**
 * Open favorite folder modal
 */
async function handleOpenFavoriteFolderModal() {
  debugLog('[FavoriteFolder] Opening favorite folder modal...')
  const modal = document.getElementById('favoriteFolderModal')
  const modalFolderSelect = document.getElementById('modalFolderSelect')
  const modalFolderSearch = document.getElementById('modalFolderSearch')

  debugLog('[FavoriteFolder] Modal elements found:', {
    modal: !!modal,
    modalFolderSelect: !!modalFolderSelect,
    modalFolderSearch: !!modalFolderSearch
  })

  if (!modal || !modalFolderSelect) {
    console.error('[FavoriteFolder] Required modal elements not found!')
    return
  }

  // Show modal
  modal.style.display = 'flex'

  // Reset search
  if (modalFolderSearch) modalFolderSearch.value = ''

  try {
    // Show loading state
    modalFolderSelect.innerHTML = ''
    modalFolderSelect.appendChild(createLoadingOption(i18n.t('popup.favoriteFolder.loadingFolders')))
    modalFolderSelect.disabled = true
    if (modalFolderSearch) modalFolderSearch.disabled = true

    // Fetch writable folders
    const folders = await sendMessage('getWritableFolders')

    if (folders && folders.length > 0) {
      // Sort folders in tree order
      const sortedFolders = sortFoldersInTreeOrder(folders)

      // Store folders globally
      window.favoriteFoldersCache = sortedFolders

      // Display all folders initially
      displayModalFolders(sortedFolders)

      modalFolderSelect.disabled = false
      if (modalFolderSearch) modalFolderSearch.disabled = false

      // Load and select current favorite folder
      const storage = await chrome.storage.local.get(['teampass_favorite_folder_id'])
      if (storage.teampass_favorite_folder_id) {
        modalFolderSelect.value = storage.teampass_favorite_folder_id
      }
    } else {
      // No folders available
      modalFolderSelect.innerHTML = '<option value="">No writable folders available</option>'
      modalFolderSelect.disabled = true
      if (modalFolderSearch) modalFolderSearch.disabled = true
    }

  } catch (error) {
    console.error('Failed to load folders for modal:', error)
    modalFolderSelect.innerHTML = '<option value="">Failed to load folders</option>'
    modalFolderSelect.disabled = true
    if (modalFolderSearch) modalFolderSearch.disabled = true
  }
}

/**
 * Close favorite folder modal
 */
function handleCloseFavoriteFolderModal() {
  const modal = document.getElementById('favoriteFolderModal')
  if (modal) modal.style.display = 'none'
}

/**
 * Display folders in modal selector
 */
function displayModalFolders(folders) {
  const modalFolderSelect = document.getElementById('modalFolderSelect')

  if (!modalFolderSelect) return

  // Use safe DOM manipulation to populate folder select
  populateFolderSelect(modalFolderSelect, folders, '-- Select a folder --')
}

/**
 * Handle modal folder search input
 */
function handleModalFolderSearch(event) {
  const searchTerm = event.target.value.toLowerCase().trim()

  if (!window.favoriteFoldersCache) return

  if (searchTerm === '') {
    // Show all folders
    displayModalFolders(window.favoriteFoldersCache)
  } else {
    // Filter folders
    const filteredFolders = window.favoriteFoldersCache.filter(folder =>
      folder.label.toLowerCase().includes(searchTerm)
    )
    displayModalFolders(filteredFolders)
  }
}

/**
 * Handle save favorite folder from modal
 */
async function handleSaveModalFavoriteFolder() {
  const modalFolderSelect = document.getElementById('modalFolderSelect')

  if (!modalFolderSelect || !modalFolderSelect.value) {
    showToast(i18n.t('popup.favoriteFolder.noFavoriteFolderSet'), 'error')
    return
  }

  try {
    await chrome.storage.local.set({
      teampass_favorite_folder_id: modalFolderSelect.value
    })

    showToast('✅ ' + i18n.t('popup.favoriteFolder.favoriteFolderSelected'), 'success')

    // Update favorite folder buttons state
    await updateFavoriteFolderButtonsState()

    // Update display in Account screen
    await updateFavoriteFolderDisplay()

    // Close modal
    handleCloseFavoriteFolderModal()

  } catch (error) {
    console.error('Failed to save favorite folder:', error)
    showToast('❌ ' + i18n.t('popup.favoriteFolder.failedToSaveFavoriteFolder'), 'error')
  }
}

/**
 * Handle use favorite folder button click
 */
async function handleUseFavoriteFolder(targetSelectId) {
  try {
    const storage = await chrome.storage.local.get(['teampass_favorite_folder_id'])

    if (!storage.teampass_favorite_folder_id) {
      showToast(i18n.t('popup.favoriteFolder.noFavoriteFolderSet'), 'error')
      return
    }

    const folderSelect = document.getElementById(targetSelectId)

    if (!folderSelect) {
      console.error('Target folder select not found:', targetSelectId)
      return
    }

    // Set the value
    folderSelect.value = storage.teampass_favorite_folder_id

    // Scroll to selected option
    const selectedOption = folderSelect.querySelector(`option[value="${storage.teampass_favorite_folder_id}"]`)
    if (selectedOption) {
      selectedOption.scrollIntoView({ block: 'nearest' })
    }

    showToast('📁 ' + i18n.t('popup.favoriteFolder.favoriteFolderSelected'), 'success')

  } catch (error) {
    console.error('Failed to use favorite folder:', error)
    showToast('❌ ' + i18n.t('popup.favoriteFolder.failedToUseFavoriteFolder'), 'error')
  }
}

/**
 * Update favorite folder buttons state (enable/disable)
 */
async function updateFavoriteFolderButtonsState() {
  try {
    const storage = await chrome.storage.local.get(['teampass_favorite_folder_id'])
    const hasFavorite = !!storage.teampass_favorite_folder_id

    const useFavoriteFolderBtn = document.getElementById('useFavoriteFolderBtn')
    const useEditFavoriteFolderBtn = document.getElementById('useEditFavoriteFolderBtn')
    const quickSaveUseFavoriteFolderBtn = document.getElementById('quickSaveUseFavoriteFolderBtn')
    const updateUseFavoriteFolderBtn = document.getElementById('updateUseFavoriteFolderBtn')

    if (useFavoriteFolderBtn) {
      useFavoriteFolderBtn.disabled = !hasFavorite
    }

    if (useEditFavoriteFolderBtn) {
      useEditFavoriteFolderBtn.disabled = !hasFavorite
    }

    if (quickSaveUseFavoriteFolderBtn) {
      quickSaveUseFavoriteFolderBtn.disabled = !hasFavorite
    }

    if (updateUseFavoriteFolderBtn) {
      updateUseFavoriteFolderBtn.disabled = !hasFavorite
    }

  } catch (error) {
    console.error('Failed to update favorite folder buttons state:', error)
  }
}

/**
 * Refresh folders list for a specific screen
 * @param {string} screenType - Type of screen: 'add', 'edit', 'quickSave', 'update'
 */
async function handleRefreshFolders(screenType) {
  debugLog(`[RefreshFolders] Refreshing folders for ${screenType} screen...`)

  let selectElement, searchElement, displayFunction, allFoldersVar

  // Determine which elements to use based on screen type
  switch (screenType) {
    case 'add':
      selectElement = document.getElementById('itemFolderId')
      searchElement = document.getElementById('folderSearch')
      displayFunction = displayFilteredFolders
      allFoldersVar = 'allFolders'
      break
    case 'edit':
      selectElement = document.getElementById('editFolderId')
      searchElement = document.getElementById('editFolderSearch')
      displayFunction = displayFilteredEditFolders
      allFoldersVar = 'allEditFolders'
      break
    case 'quickSave':
      selectElement = document.getElementById('quickSaveFolderId')
      searchElement = document.getElementById('quickSaveFolderSearch')
      // For quickSave, we need to call save-modes.js methods
      if (typeof window.saveModesHandler !== 'undefined' && window.saveModesHandler.displayFilteredQuickSaveFolders) {
        displayFunction = (folders) => window.saveModesHandler.displayFilteredQuickSaveFolders(folders, selectElement.value)
        allFoldersVar = 'saveModesHandler.allFolders'
      }
      break
    case 'update':
      selectElement = document.getElementById('updateFolderId')
      searchElement = document.getElementById('updateFolderSearch')
      // For update, we need to call save-modes.js methods
      if (typeof window.saveModesHandler !== 'undefined' && window.saveModesHandler.displayFilteredUpdateFolders) {
        displayFunction = (folders) => window.saveModesHandler.displayFilteredUpdateFolders(folders, selectElement.value)
        allFoldersVar = 'saveModesHandler.allFolders'
      }
      break
    default:
      console.error(`[RefreshFolders] Unknown screen type: ${screenType}`)
      return
  }

  if (!selectElement) {
    console.error(`[RefreshFolders] Select element not found for ${screenType}`)
    return
  }

  try {
    // Store current selection to restore after refresh
    const currentValue = selectElement.value

    // Show loading state
    selectElement.innerHTML = ''
    selectElement.appendChild(createLoadingOption(i18n.t('popup.addItem.folderSelect')))
    selectElement.disabled = true
    if (searchElement) searchElement.disabled = true

    // Fetch fresh folders from server
    debugLog(`[RefreshFolders] Fetching folders from server...`)
    const folders = await sendMessage('getWritableFolders')
    debugLog(`[RefreshFolders] Received ${folders?.length || 0} folders`)

    if (folders && folders.length > 0) {
      // Sort folders in tree order
      const sortedFolders = sortFoldersInTreeOrder(folders)

      // Update global variable based on screen type
      if (screenType === 'add') {
        allFolders = sortedFolders
      } else if (screenType === 'edit') {
        allEditFolders = sortedFolders
      } else if (screenType === 'quickSave' || screenType === 'update') {
        if (typeof window.saveModesHandler !== 'undefined') {
          window.saveModesHandler.allFolders = sortedFolders
        }
      }

      // Display folders
      if (displayFunction) {
        displayFunction(sortedFolders)
      }

      // Restore previous selection if it still exists
      if (currentValue) {
        const optionExists = Array.from(selectElement.options).some(opt => opt.value === currentValue)
        if (optionExists) {
          selectElement.value = currentValue
        }
      }

      selectElement.disabled = false
      if (searchElement) searchElement.disabled = false

      showToast('✅ ' + i18n.t('popup.folders.foldersRefreshed'), 'success')
      debugLog(`[RefreshFolders] Folders refreshed successfully`)
    } else {
      selectElement.innerHTML = '<option value="">No writable folders available</option>'
      selectElement.disabled = true
      if (searchElement) searchElement.disabled = true
      showToast('⚠️ No writable folders available', 'warning')
    }
  } catch (error) {
    console.error(`[RefreshFolders] Failed to refresh folders for ${screenType}:`, error)
    selectElement.innerHTML = '<option value="">Failed to load folders</option>'
    selectElement.disabled = true
    if (searchElement) searchElement.disabled = true
    showToast('❌ Failed to refresh folders', 'error')
  }
}

/**
 * Handle back from Add Item screen
 * Returns to main screen and resets form
 *
 * @returns {void}
 */
function handleBackFromAddItem() {
  if (forms.addItem) {
    forms.addItem.reset()
  }
  showScreen('main')
  // Load items for current page when returning from Add Item screen
  if (typeof loadItemsForCurrentPage === 'function') {
    loadItemsForCurrentPage()
  }
}

/**
 * Show add item screen
 *
 * @returns {void}
 */
async function showAddItemScreen() {
  // Show loading state on the button
  const addItemBtn = buttons.addItem
  if (addItemBtn) {
    addItemBtn.disabled = true
    // Store original icon to restore later
    addItemBtn.dataset.originalIcon = '<i class="fas fa-plus"></i>'
    setButtonIcon(addItemBtn, '<i class="fas fa-spinner fa-spin"></i>')
  }

  try {
    // Pre-fill Label with host (hostname + port if specified)
    const labelInput = document.getElementById('itemLabel')
    if (labelInput && currentTabUrl) {
      try {
        const urlObj = new URL(currentTabUrl)
        labelInput.value = urlObj.host
      } catch (error) {
        // Ignore URL parsing errors
      }
    }

    // Pre-fill URL from current tab (protocol + host with port if specified)
    const urlInput = document.getElementById('itemUrl')
    if (urlInput && currentTabUrl) {
      try {
        const urlObj = new URL(currentTabUrl)
        urlInput.value = `${urlObj.protocol}//${urlObj.host}`
      } catch (error) {
        // Ignore URL parsing errors
      }
    }

    // Try to get login/password values from the current page
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })

      if (tab && tab.id) {
        // Send message to content script to get form values
        const response = await chrome.tabs.sendMessage(tab.id, {
          action: 'getLoginFormValues'
        })

        if (response && response.success && response.data) {
          // Pre-fill login if available
          const loginInput = document.getElementById('itemLogin')
          if (loginInput && response.data.username) {
            loginInput.value = response.data.username
          }

          // Pre-fill password if available
          const passwordInput = document.getElementById('itemPassword')
          if (passwordInput && response.data.password) {
            passwordInput.value = response.data.password

            // Update password strength indicator
            updatePasswordStrength(response.data.password)
          }
        }
      }
    } catch (error) {
      // Silently fail if content script is not available
      // This can happen on pages where content scripts cannot run (chrome://, file://, etc.)
      debugLog('Could not retrieve form values from page:', error.message)
    }

    // Load writable folders
    await loadWritableFolders()

    // Update favorite folder button state
    await updateFavoriteFolderButtonsState()

    showScreen('addItem')
  } finally {
    // Restore button state
    if (addItemBtn) {
      addItemBtn.disabled = false
      if (addItemBtn.dataset.originalIcon) {
        // Restore original icon
        setButtonIcon(addItemBtn, addItemBtn.dataset.originalIcon)
        delete addItemBtn.dataset.originalIcon
      } else {
        setButtonIcon(addItemBtn, '<i class="fas fa-plus"></i>')
      }
    }
  }
}

// Store all folders for filtering
let allFolders = []
let allEditFolders = []

/**
 * Sort folders in tree order (parent followed by children)
 * Folders with first_position=1 and their children are placed at the top
 *
 * @param {Array} folders - Flat list of folders
 * @returns {Array} Folders sorted in tree order with level property
 */
function sortFoldersInTreeOrder(folders) {
  // Create a map of folders by ID for quick lookup
  const folderMap = new Map()
  folders.forEach(folder => folderMap.set(folder.id, { ...folder }))

  // Find folder with first_position = 1
  const firstPositionFolder = folders.find(f => f.first_position === 1 || f.first_position === '1')

  // Build tree structure - group children by parent_id
  const childrenMap = new Map()
  folders.forEach(folder => {
    const parentId = folder.parent_id || 0
    if (!childrenMap.has(parentId)) {
      childrenMap.set(parentId, [])
    }
    childrenMap.get(parentId).push(folder)
  })

  // Sort children alphabetically within each parent
  childrenMap.forEach(children => {
    children.sort((a, b) => a.label.localeCompare(b.label))
  })

  // Function to get all descendants of a folder with level tracking
  function getAllDescendants(folderId, level, excludeIds = new Set()) {
    const descendants = []
    const children = childrenMap.get(folderId) || []

    children.forEach(child => {
      if (!excludeIds.has(child.id)) {
        child.level = level
        descendants.push(child)
        descendants.push(...getAllDescendants(child.id, level + 1, excludeIds))
      }
    })

    return descendants
  }

  // If there's a first_position folder, collect it and all its descendants
  const firstPositionBranch = []
  const excludeIds = new Set()

  if (firstPositionFolder) {
    firstPositionFolder.level = 0
    firstPositionBranch.push(firstPositionFolder)
    excludeIds.add(firstPositionFolder.id)

    // Get all descendants of the first_position folder
    const descendants = getAllDescendants(firstPositionFolder.id, 1)
    firstPositionBranch.push(...descendants)

    // Mark all descendants to exclude from main tree
    descendants.forEach(desc => excludeIds.add(desc.id))
  }

  // Traverse tree in depth-first order (parent, then children, then grandchildren...)
  // but exclude the first_position branch
  const result = []

  function traverse(parentId, level) {
    const children = childrenMap.get(parentId) || []
    children.forEach(folder => {
      if (!excludeIds.has(folder.id)) {
        folder.level = level
        result.push(folder)
        traverse(folder.id, level + 1) // Recursively add children
      }
    })
  }

  // Start with root folders (parent_id = 0 or null)
  traverse(0, 0)

  // Also handle folders with null parent_id
  if (childrenMap.has(null)) {
    childrenMap.get(null).forEach(folder => {
      if (!excludeIds.has(folder.id)) {
        folder.level = 0
        result.push(folder)
        traverse(folder.id, 1)
      }
    })
  }

  // Return first_position branch first, then the rest
  return [...firstPositionBranch, ...result]
}

/**
 * Load writable folders into the folder dropdown
 *
 * @returns {Promise<void>}
 */
async function loadWritableFolders() {
  const folderSelect = document.getElementById('itemFolderId')
  const folderSearch = document.getElementById('folderSearch')

  if (!folderSelect) {
    console.error('Folder select element not found')
    return
  }

  try {
    // Show loading state
    folderSelect.innerHTML = ''
    folderSelect.appendChild(createLoadingOption(i18n.t('popup.addItem.folderSelect')))
    folderSelect.disabled = true
    if (folderSearch) folderSearch.disabled = true

    // Fetch writable folders
    const folders = await sendMessage('getWritableFolders')

    if (folders && folders.length > 0) {
      // Sort folders in tree order (parent followed by children)
      const sortedFolders = sortFoldersInTreeOrder(folders)

      // Store sorted folders globally for filtering
      allFolders = sortedFolders

      // Display all folders initially
      displayFilteredFolders(sortedFolders)

      folderSelect.disabled = false
      if (folderSearch) {
        folderSearch.disabled = false

        // Add search event listener
        folderSearch.addEventListener('input', handleFolderSearch)
      }
    } else {
      // No folders available
      folderSelect.innerHTML = '<option value="">No writable folders available</option>'
      folderSelect.disabled = true
      if (folderSearch) folderSearch.disabled = true
      showToast('⚠️ ' + i18n.t('popup.addItem.noFoldersWithWriteAccess'), 'error')
    }

  } catch (error) {
    console.error('Failed to load folders:', error)
    folderSelect.innerHTML = '<option value="">Failed to load folders</option>'
    folderSelect.disabled = true
    if (folderSearch) folderSearch.disabled = true
    showToast('❌ ' + i18n.t('common.foldersLoadFailed'), 'error')
  }
}

/**
 * Display filtered folders in the select dropdown
 *
 * @param {Array} folders - Folders to display
 * @returns {void}
 */
function displayFilteredFolders(folders) {
  const folderSelect = document.getElementById('itemFolderId')

  if (!folderSelect) return

  // Use safe DOM manipulation to populate folder select
  populateFolderSelect(folderSelect, folders, '-- Select a folder --')
}

/**
 * Handle folder search input
 *
 * @param {Event} event - Input event
 * @returns {void}
 */
function handleFolderSearch(event) {
  const searchTerm = event.target.value.toLowerCase().trim()

  if (!searchTerm) {
    // No search term, show all folders
    displayFilteredFolders(allFolders)
    return
  }

  // Filter folders by label
  const filteredFolders = allFolders.filter(folder =>
    folder.label.toLowerCase().includes(searchTerm)
  )

  displayFilteredFolders(filteredFolders)

  // Show message if no results
  if (filteredFolders.length === 0) {
    const folderSelect = document.getElementById('itemFolderId')
    folderSelect.innerHTML = ''
    const option = document.createElement('option')
    option.value = ''
    option.textContent = 'No folders found'
    folderSelect.appendChild(option)
  }
}

/**
 * Display filtered folders in the edit form select dropdown
 *
 * @param {Array} folders - Folders to display
 * @returns {void}
 */
function displayFilteredEditFolders(folders) {
  const folderSelect = inputs.editFolderId

  if (!folderSelect) return

  // Use safe DOM manipulation to populate folder select
  populateFolderSelect(folderSelect, folders, i18n.t('popup.editItem.folderSelect'))
}

/**
 * Handle edit folder search input
 *
 * @param {Event} event - Input event
 * @returns {void}
 */
function handleEditFolderSearch(event) {
  const searchTerm = event.target.value.toLowerCase().trim()

  if (!searchTerm) {
    // No search term, show all folders
    displayFilteredEditFolders(allEditFolders)
    return
  }

  // Filter folders by label
  const filteredFolders = allEditFolders.filter(folder =>
    folder.label.toLowerCase().includes(searchTerm)
  )

  displayFilteredEditFolders(filteredFolders)

  // Show message if no results
  if (filteredFolders.length === 0) {
    if (inputs.editFolderId) {
      inputs.editFolderId.innerHTML = '<option value="">No folders found</option>'
    }
  }
}

/**
 * Hide add item modal
 *
 * @returns {void}
 */
function hideAddItemModal() {
  if (!sections.addItemModal) return
  sections.addItemModal.style.display = 'none'

  // Reset form
  if (forms.addItem) {
    forms.addItem.reset()
  }
}

/**
 * Handle add item form submission
 *
 * @param {Event} event - Form submit event
 * @returns {Promise<void>}
 */
async function handleAddItemSubmit(event) {
  event.preventDefault()

  const formData = new FormData(forms.addItem)
  const itemData = {
    label: formData.get('label'),
    login: formData.get('login') || '',
    password: formData.get('password'),
    url: formData.get('url') || '',
    email: formData.get('email') || '',
    description: formData.get('description') || '',
    tags: formData.get('tags') || '',
    icon: formData.get('icon') || '',
    anyone_can_modify: formData.get('anyone_can_modify') ? 1 : 0,
    totp: formData.get('totp') || '',
    folder_id: parseInt(formData.get('folder_id'), 10)
  }

  // Validate required fields
  if (!itemData.label || !itemData.password || !itemData.folder_id) {
    showToast('❌ ' + i18n.t('popup.addItem.requiredFieldsMissing'), 'error')
    return
  }

  const submitBtn = document.getElementById('submitAddItem')

  // Disable button and show loading state
  submitBtn.disabled = true
  submitBtn.textContent = i18n.t('popup.addItem.creatingItem')

  try {
    // Call service worker to create item
    const newItem = await sendMessage('createItem', { itemData })

    if (newItem) {
      showToast('✅ ' + i18n.t('popup.addItem.itemCreated'))

      // Return to main screen
      showScreen('main')

      // Reload items list
      await loadItemsForCurrentPage()

      // Update badge count
      await sendMessage('updateBadge')

      // Reset form (after screen change so button state doesn't flash)
      forms.addItem.reset()
      // Reset button state for next use
      submitBtn.disabled = false
      submitBtn.textContent = i18n.t('popup.addItem.createButton')
    } else {
      showToast('❌ ' + i18n.t('popup.addItem.failedToCreateItem'), 'error')
      // Re-enable button and reset text on error (so user can retry)
      submitBtn.disabled = false
      submitBtn.textContent = i18n.t('popup.addItem.createButton')
    }

  } catch (error) {
    console.error('Create item error:', error)
    showToast('❌ ' + i18n.t('popup.addItem.failedToCreateItem', { message: error.message }), 'error')
    // Re-enable button and reset text on error (so user can retry)
    submitBtn.disabled = false
    submitBtn.textContent = i18n.t('popup.addItem.createButton')
  }
}

/**
 * Global Search Functions
 */

// Variable to track if we're in search mode
let isSearchMode = false

/**
 * Perform global search
 */
async function handleGlobalSearch() {
  try {
    const searchTerm = inputs.globalSearch.value.trim()

    if (!searchTerm) {
      showToast(i18n.t('popup.search.searchTermRequired'), 'error')
      return
    }

    debugLog('Performing global search for:', searchTerm)

    // Hide current page URL in search mode
    if (displays.currentPageUrl) {
      displays.currentPageUrl.style.display = 'none'
    }

    // Show loading
    sections.items.style.display = 'none'
    sections.noItems.style.display = 'none'
    sections.loadingItems.style.display = 'block'

    // Call the API via service worker
    const items = await sendMessage('globalSearch', { searchTerm })

    // Hide loading
    sections.loadingItems.style.display = 'none'

    if (items && items.length > 0) {
      debugLog(`Found ${items.length} item(s) from search`)

      // Set search mode flag
      isSearchMode = true

      // Display items
      displayItems(items)

      // Show search results header and items section
      sections.searchResultsHeader.style.display = 'flex'
      sections.items.style.display = 'block'
    } else {
      debugLog('No items found from search')
      sections.noItems.style.display = 'block'

      // Update the no items message for search
      const noItemsMessage = sections.noItems.querySelector('.info-message p')
      if (noItemsMessage) {
        noItemsMessage.textContent = 'No password found for this search'
      }
    }

  } catch (error) {
    console.error('Global search failed:', error)
    sections.loadingItems.style.display = 'none'
    sections.noItems.style.display = 'block'
    showToast(i18n.t('popup.search.searchFailed', { message: error.message }), 'error')
  }
}

/**
 * Clear search and return to normal view
 */
async function handleClearSearch() {
  try {
    debugLog('Clearing search results')

    // Reset search mode flag
    isSearchMode = false

    // Clear search input
    inputs.globalSearch.value = ''

    // Hide clear input button
    if (buttons.clearSearchInput) {
      buttons.clearSearchInput.style.display = 'none'
    }

    // Hide search results header
    sections.searchResultsHeader.style.display = 'none'

    // Show current page URL again
    if (displays.currentPageUrl) {
      displays.currentPageUrl.style.display = 'block'
    }

    // Restore the original no items message
    const noItemsMessage = sections.noItems.querySelector('.info-message p')
    if (noItemsMessage) {
      noItemsMessage.textContent = i18n.t('popup.items.noItems')
    }

    // Reload items for current page
    await loadItemsForCurrentPage()

  } catch (error) {
    console.error('Failed to clear search:', error)
    showToast(i18n.t('popup.search.failedToClearSearch', { message: error.message }), 'error')
  }
}

/**
 * Update search input clear button visibility
 */
function updateSearchClearButton() {
  if (buttons.clearSearchInput && inputs.globalSearch) {
    if (inputs.globalSearch.value.trim().length > 0) {
      buttons.clearSearchInput.style.display = 'flex'
    } else {
      buttons.clearSearchInput.style.display = 'none'
    }
  }
}

// Listen for licence status changes in storage to update the indicator in real-time
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === 'local' && changes.teampass_ext_licence) {
    debugLog('[POPUP] Licence data changed in storage, updating indicator...')
    const newLicenceData = changes.teampass_ext_licence.newValue
    if (newLicenceData) {
      updateLicenceIndicator(newLicenceData)
      debugLog('[POPUP] Licence indicator updated from storage change')
    }
  }
})

// Wait for DOM to be ready
document.addEventListener('DOMContentLoaded', () => {
  // Initialize DOM elements first
  initializeElements()
  
  // Add event listeners (check if elements exist)
  if (forms.config) forms.config.addEventListener('submit', handleConfigSubmit)
  if (forms.login) forms.login.addEventListener('submit', handleLoginSubmit)
  if (forms.addItem) forms.addItem.addEventListener('submit', handleAddItemSubmit)
  if (buttons.testConnection) buttons.testConnection.addEventListener('click', handleTestConnection)
  if (buttons.changeServer) buttons.changeServer.addEventListener('click', handleChangeServer)
  if (buttons.logout) buttons.logout.addEventListener('click', handleLogout)
  if (buttons.refresh) buttons.refresh.addEventListener('click', handleRefresh)
  if (buttons.passwordGenerator) {
    debugLog('EVENT: Attaching click listener to passwordGeneratorBtn')
    buttons.passwordGenerator.addEventListener('click', showStandalonePasswordGeneratorModal)
    debugLog('EVENT: Click listener attached successfully')
  }
  if (buttons.addItem) {
    debugLog('EVENT: Attaching click listener to addItemBtn')
    buttons.addItem.addEventListener('click', showAddItemScreen)
    debugLog('EVENT: Click listener attached successfully')
  } else {
    console.error('EVENT: addItemBtn not found, cannot attach listener!')
  }
  if (buttons.openTeampass) buttons.openTeampass.addEventListener('click', handleOpenTeampass)
  if (buttons.menu) buttons.menu.addEventListener('click', toggleMenu)
  if (buttons.darkMode) buttons.darkMode.addEventListener('click', toggleDarkMode)
  if (buttons.iconStyle) buttons.iconStyle.addEventListener('click', toggleIconStyle)
  if (buttons.openOptions2) buttons.openOptions2.addEventListener('click', handleOpenOptions)
  if (buttons.about) buttons.about.addEventListener('click', handleAbout)
  if (buttons.backFromAbout) buttons.backFromAbout.addEventListener('click', handleBackFromAbout)
  if (buttons.backFromAbout2) buttons.backFromAbout2.addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://teampass.net' })
  })
  if (buttons.account) buttons.account.addEventListener('click', handleAccount)
  if (buttons.backFromAccount) buttons.backFromAccount.addEventListener('click', handleBackFromAccount)
  if (buttons.backFromAddItem) buttons.backFromAddItem.addEventListener('click', handleBackFromAddItem)

  // Favorite folder event listeners
  const openFavoriteFolderModal = document.getElementById('openFavoriteFolderModal')
  const closeFavoriteFolderModal = document.getElementById('closeFavoriteFolderModal')
  const cancelFavoriteFolderModal = document.getElementById('cancelFavoriteFolderModal')
  const saveModalFavoriteFolder = document.getElementById('saveModalFavoriteFolder')
  const modalFolderSearch = document.getElementById('modalFolderSearch')
  const useFavoriteFolderBtn = document.getElementById('useFavoriteFolderBtn')
  const useEditFavoriteFolderBtn = document.getElementById('useEditFavoriteFolderBtn')
  const quickSaveUseFavoriteFolderBtn = document.getElementById('quickSaveUseFavoriteFolderBtn')
  const updateUseFavoriteFolderBtn = document.getElementById('updateUseFavoriteFolderBtn')

  debugLog('[FavoriteFolder] Attaching event listeners...')
  debugLog('[FavoriteFolder] openFavoriteFolderModal button found:', !!openFavoriteFolderModal)

  if (openFavoriteFolderModal) {
    // Log button state for debugging
    const computedStyle = window.getComputedStyle(openFavoriteFolderModal)
    const rect = openFavoriteFolderModal.getBoundingClientRect()

    // Check what element is actually at the button's position
    const centerX = rect.left + rect.width / 2
    const centerY = rect.top + rect.height / 2
    const elementAtPoint = document.elementFromPoint(centerX, centerY)

    debugLog('[FavoriteFolder] Button state:', {
      disabled: openFavoriteFolderModal.disabled,
      display: computedStyle.display,
      visibility: computedStyle.visibility,
      pointerEvents: computedStyle.pointerEvents,
      zIndex: computedStyle.zIndex,
      position: { top: rect.top, left: rect.left, width: rect.width, height: rect.height },
      elementAtCenter: elementAtPoint ? elementAtPoint.tagName + '#' + elementAtPoint.id + '.' + elementAtPoint.className : 'null',
      isButtonAtCenter: elementAtPoint === openFavoriteFolderModal || openFavoriteFolderModal.contains(elementAtPoint)
    })

    // Add comprehensive event listeners to track all mouse interactions
    openFavoriteFolderModal.addEventListener('click', (e) => {
      debugLog('[FavoriteFolder] ✅ Button CLICKED!', e)
      handleOpenFavoriteFolderModal()
    }, { capture: true })

    openFavoriteFolderModal.addEventListener('mousedown', (e) => {
      debugLog('[FavoriteFolder] 👇 Button MOUSEDOWN', e.button)
    }, { capture: true })

    openFavoriteFolderModal.addEventListener('mouseup', (e) => {
      debugLog('[FavoriteFolder] 👆 Button MOUSEUP', e.button)
    }, { capture: true })

    openFavoriteFolderModal.addEventListener('mouseenter', () => {
      debugLog('[FavoriteFolder] 🔵 Button MOUSEENTER')
    })

    openFavoriteFolderModal.addEventListener('mouseleave', () => {
      debugLog('[FavoriteFolder] 🔴 Button MOUSELEAVE')
    })

    debugLog('[FavoriteFolder] All event listeners attached successfully')
  }
  if (closeFavoriteFolderModal) closeFavoriteFolderModal.addEventListener('click', handleCloseFavoriteFolderModal)
  if (cancelFavoriteFolderModal) cancelFavoriteFolderModal.addEventListener('click', handleCloseFavoriteFolderModal)
  if (saveModalFavoriteFolder) saveModalFavoriteFolder.addEventListener('click', handleSaveModalFavoriteFolder)
  if (modalFolderSearch) modalFolderSearch.addEventListener('input', handleModalFolderSearch)
  if (useFavoriteFolderBtn) useFavoriteFolderBtn.addEventListener('click', () => handleUseFavoriteFolder('itemFolderId'))
  if (useEditFavoriteFolderBtn) useEditFavoriteFolderBtn.addEventListener('click', () => handleUseFavoriteFolder('editFolderId'))
  if (quickSaveUseFavoriteFolderBtn) quickSaveUseFavoriteFolderBtn.addEventListener('click', () => handleUseFavoriteFolder('quickSaveFolderId'))
  if (updateUseFavoriteFolderBtn) updateUseFavoriteFolderBtn.addEventListener('click', () => handleUseFavoriteFolder('updateFolderId'))

  // Refresh folders event listeners
  const refreshFoldersBtn = document.getElementById('refreshFoldersBtn')
  const refreshEditFoldersBtn = document.getElementById('refreshEditFoldersBtn')
  if (refreshFoldersBtn) refreshFoldersBtn.addEventListener('click', () => handleRefreshFolders('add'))
  if (refreshEditFoldersBtn) refreshEditFoldersBtn.addEventListener('click', () => handleRefreshFolders('edit'))

  // Language selector event listener
  const languageSelect = document.getElementById('languageSelect')
  if (languageSelect) languageSelect.addEventListener('change', handleLanguageChange)

  // Password generator event listeners (Add Item form)
  const generatePasswordBtn = document.getElementById('generatePasswordBtn')
  const togglePasswordBtn = document.getElementById('togglePasswordBtn')
  const copyPasswordBtn = document.getElementById('copyPasswordBtn')
  const passwordInput = document.getElementById('itemPassword')

  if (generatePasswordBtn) generatePasswordBtn.addEventListener('click', handleGeneratePassword)
  if (togglePasswordBtn) togglePasswordBtn.addEventListener('click', handleTogglePassword)
  if (copyPasswordBtn) copyPasswordBtn.addEventListener('click', handleCopyPassword)
  if (passwordInput) {
    passwordInput.addEventListener('input', (e) => updatePasswordStrength(e.target.value))
  }

  // Password generator event listeners (Edit Item form)
  const editGeneratePasswordBtn = document.getElementById('editGeneratePasswordBtn')
  const editTogglePasswordBtn = document.getElementById('editTogglePasswordBtn')
  const editCopyPasswordBtn = document.getElementById('editCopyPasswordBtn')
  const editPasswordInput = document.getElementById('editPassword')

  if (editGeneratePasswordBtn) editGeneratePasswordBtn.addEventListener('click', handleEditGeneratePassword)
  if (editTogglePasswordBtn) editTogglePasswordBtn.addEventListener('click', handleEditTogglePassword)
  if (editCopyPasswordBtn) editCopyPasswordBtn.addEventListener('click', handleEditCopyPassword)
  if (editPasswordInput) {
    editPasswordInput.addEventListener('input', (e) => updateEditPasswordStrength(e.target.value))
  }

  // Edit item event listeners
  debugLog('=== ATTACHING EDIT EVENT LISTENERS ===')
  debugLog('forms.edit:', forms.edit)
  debugLog('buttons.backFromEdit:', buttons.backFromEdit)
  debugLog('buttons.editCancel:', buttons.editCancel)
  debugLog('buttons.editUpdate:', buttons.editUpdate)

  if (forms.edit) {
    debugLog('Attaching submit listener to edit form')
    forms.edit.addEventListener('submit', handleEditSubmit)
  } else {
    console.error('Edit form not found!')
  }

  if (buttons.backFromEdit) buttons.backFromEdit.addEventListener('click', handleBackFromEdit)

  // Edit folder search
  if (inputs.editFolderSearch) inputs.editFolderSearch.addEventListener('input', handleEditFolderSearch)

  // View item event listeners
  if (buttons.backFromView) buttons.backFromView.addEventListener('click', handleBackFromView)
  if (buttons.deleteItem) buttons.deleteItem.addEventListener('click', handleDeleteItem)
  if (buttons.editFromView) buttons.editFromView.addEventListener('click', handleEditFromView)
  if (buttons.viewPasswordToggle) buttons.viewPasswordToggle.addEventListener('click', handleViewPasswordToggle)

  // Login screen button event listeners
  if (buttons.reauth) buttons.reauth.addEventListener('click', handleReauth)
  if (buttons.openOptions) buttons.openOptions.addEventListener('click', handleOpenOptions)

  // Maintenance screen button event listener
  if (buttons.retryMaintenance) buttons.retryMaintenance.addEventListener('click', handleRetryMaintenance)

  // Global search event listeners
  if (buttons.globalSearch) buttons.globalSearch.addEventListener('click', handleGlobalSearch)
  if (buttons.clearSearch) buttons.clearSearch.addEventListener('click', handleClearSearch)
  if (buttons.clearSearchInput) buttons.clearSearchInput.addEventListener('click', handleClearSearch)
  if (inputs.globalSearch) {
    inputs.globalSearch.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        handleGlobalSearch()
      }
    })
    inputs.globalSearch.addEventListener('input', updateSearchClearButton)
  }

  // Close menu when clicking outside
  document.addEventListener('click', handleOutsideClick)

  // Initialize app
  initialize()
})
/**
 * Password Generator Functions
 */

/**
 * Generate a random secure password
 * @param {number} length - Password length (default: 16)
 * @param {object} options - Options for password generation
 * @returns {string} Generated password
 */
function generateSecurePassword(length = 16, options = {}) {
  const defaults = {
    lowercase: true,
    uppercase: true,
    numbers: true,
    symbols: true
  }
  
  const opts = { ...defaults, ...options }
  
  const lowercase = 'abcdefghijklmnopqrstuvwxyz'
  const uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
  const numbers = '0123456789'
  const symbols = '!@#$%^&*()_+-=[]{}|;:,.<>?'
  
  let chars = ''
  let password = ''
  
  // Build character set
  if (opts.lowercase) chars += lowercase
  if (opts.uppercase) chars += uppercase
  if (opts.numbers) chars += numbers
  if (opts.symbols) chars += symbols
  
  if (chars.length === 0) {
    chars = lowercase + uppercase + numbers // Fallback
  }
  
  // Generate password using crypto.getRandomValues for security
  const array = new Uint32Array(length)
  crypto.getRandomValues(array)
  
  for (let i = 0; i < length; i++) {
    password += chars[array[i] % chars.length]
  }
  
  // Ensure at least one character from each selected type
  if (opts.uppercase && !/[A-Z]/.test(password)) {
    password = password.substring(0, length - 1) + uppercase[Math.floor(Math.random() * uppercase.length)]
  }
  if (opts.numbers && !/[0-9]/.test(password)) {
    password = password.substring(0, length - 1) + numbers[Math.floor(Math.random() * numbers.length)]
  }
  if (opts.symbols && !/[!@#$%^&*()_+\-=\[\]{}|;:,.<>?]/.test(password)) {
    password = password.substring(0, length - 1) + symbols[Math.floor(Math.random() * symbols.length)]
  }
  
  return password
}

/**
 * Calculate password strength
 * @param {string} password - Password to check
 * @returns {object} Strength score and level
 */
function calculatePasswordStrength(password) {
  let score = 0
  
  if (!password) return { score: 0, level: 'weak', text: 'Weak' }
  
  // Length scoring
  if (password.length >= 8) score += 1
  if (password.length >= 12) score += 1
  if (password.length >= 16) score += 1
  
  // Character variety scoring
  if (/[a-z]/.test(password)) score += 1
  if (/[A-Z]/.test(password)) score += 1
  if (/[0-9]/.test(password)) score += 1
  if (/[^a-zA-Z0-9]/.test(password)) score += 1
  
  // Determine level
  let level, text
  if (score <= 3) {
    level = 'weak'
    text = 'Weak'
  } else if (score <= 5) {
    level = 'medium'
    text = 'Medium'
  } else {
    level = 'strong'
    text = 'Strong'
  }
  
  return { score, level, text }
}

/**
 * Update password strength indicator
 * @param {string} password - Password to check
 */
function updatePasswordStrength(password) {
  const strengthBar = document.getElementById('passwordStrength')
  const strengthFill = document.getElementById('strengthFill')
  const strengthText = document.getElementById('strengthText')
  
  if (!strengthBar || !strengthFill || !strengthText) return
  
  if (!password || password.length === 0) {
    strengthBar.style.display = 'none'
    return
  }
  
  const { level, text } = calculatePasswordStrength(password)
  
  strengthBar.style.display = 'flex'
  strengthFill.className = `strength-fill ${level}`
  strengthText.className = `strength-text ${level}`
  strengthText.textContent = text
}

/**
 * Show password generator modal
 * @param {string} targetInputId - ID of the password input field (default: 'itemPassword')
 */
async function showPasswordGeneratorModal(targetInputId = 'itemPassword') {
  // Remove existing modal if any
  const existingModal = document.getElementById('passwordGenModal')
  if (existingModal) {
    existingModal.remove()
  }

  // Load saved password preferences (length + character types)
  const savedPreferences = await new Promise((resolve) => {
    chrome.storage.local.get([
      'passwordGeneratorLength',
      'passwordGeneratorLowercase',
      'passwordGeneratorUppercase',
      'passwordGeneratorNumbers',
      'passwordGeneratorSymbols'
    ], (result) => {
      resolve({
        length: result.passwordGeneratorLength || 16,
        lowercase: result.passwordGeneratorLowercase ?? true,
        uppercase: result.passwordGeneratorUppercase ?? true,
        numbers: result.passwordGeneratorNumbers ?? true,
        symbols: result.passwordGeneratorSymbols ?? true
      })
    })
  })

  const savedLength = savedPreferences.length

  // Get maximum password length from JWT
  const maxLength = await getPasswordMaxLength()

  // Create modal
  const modal = document.createElement('div')
  modal.id = 'passwordGenModal'
  modal.className = 'password-gen-modal'

  // Create and append modal content safely
  const modalContent = createPasswordGeneratorModalContent(savedLength, maxLength)
  modal.appendChild(modalContent)

  document.body.appendChild(modal)

  // Animate in
  setTimeout(() => modal.classList.add('show'), 10)

  // Get elements
  const lengthSlider = document.getElementById('genLengthSlider')
  const lengthValue = document.getElementById('genLengthValue')
  const lowercaseCheck = document.getElementById('genLowercase')
  const uppercaseCheck = document.getElementById('genUppercase')
  const numbersCheck = document.getElementById('genNumbers')
  const symbolsCheck = document.getElementById('genSymbols')
  const display = document.getElementById('genDisplay')
  const generateBtn = document.getElementById('genGenerateBtn')
  const copyBtn = document.getElementById('genCopyBtn')
  const useBtn = document.getElementById('genUseBtn')
  const closeBtn = document.getElementById('passwordGenClose')

  let currentPassword = ''

  // Apply saved checkbox preferences
  if (lowercaseCheck) lowercaseCheck.checked = savedPreferences.lowercase
  if (uppercaseCheck) uppercaseCheck.checked = savedPreferences.uppercase
  if (numbersCheck) numbersCheck.checked = savedPreferences.numbers
  if (symbolsCheck) symbolsCheck.checked = savedPreferences.symbols

  // Length slider handler
  lengthSlider.addEventListener('input', (e) => {
    lengthValue.textContent = e.target.value
    // Save preference
    chrome.storage.local.set({ passwordGeneratorLength: parseInt(e.target.value) })
  })

  // Checkbox change handlers - save preferences
  const checkboxHandler = (checkbox, storageKey) => {
    if (checkbox) {
      checkbox.addEventListener('change', (e) => {
        chrome.storage.local.set({ [storageKey]: e.target.checked })
      })
    }
  }

  checkboxHandler(lowercaseCheck, 'passwordGeneratorLowercase')
  checkboxHandler(uppercaseCheck, 'passwordGeneratorUppercase')
  checkboxHandler(numbersCheck, 'passwordGeneratorNumbers')
  checkboxHandler(symbolsCheck, 'passwordGeneratorSymbols')

  // Auto-generate password on modal open with saved preferences
  currentPassword = generateSecurePassword(savedPreferences.length, {
    lowercase: savedPreferences.lowercase,
    uppercase: savedPreferences.uppercase,
    numbers: savedPreferences.numbers,
    symbols: savedPreferences.symbols
  })
  display.textContent = currentPassword
  display.classList.remove('empty')
  copyBtn.disabled = false
  useBtn.disabled = false

  // Generate button handler
  generateBtn.addEventListener('click', () => {
    const length = parseInt(lengthSlider.value)
    const options = {
      lowercase: lowercaseCheck.checked,
      uppercase: uppercaseCheck.checked,
      numbers: numbersCheck.checked,
      symbols: symbolsCheck.checked
    }

    // Ensure at least one option is selected
    if (!options.lowercase && !options.uppercase && !options.numbers && !options.symbols) {
      showToast(i18n.t('popup.passwordGenerator.selectCharacterType'), 'error')
      return
    }

    currentPassword = generateSecurePassword(length, options)
    display.textContent = currentPassword
    display.classList.remove('empty')

    // Enable copy and use buttons
    copyBtn.disabled = false
    useBtn.disabled = false
  })

  // Copy button handler
  copyBtn.addEventListener('click', async () => {
    if (!currentPassword) return

    try {
      await copyToClipboard(currentPassword)
      showToast(i18n.t('popup.password.passwordCopied'), 'success')
    } catch (error) {
      showToast(i18n.t('popup.password.failedToCopyPassword'), 'error')
    }
  })

  // Use button handler
  useBtn.addEventListener('click', () => {
    if (!currentPassword) return

    const passwordInput = document.getElementById(targetInputId)
    if (passwordInput) {
      passwordInput.value = currentPassword
      passwordInput.type = 'text'

      // Update password strength based on which form
      if (targetInputId === 'editPassword') {
        updateEditPasswordStrength(currentPassword)
      } else {
        updatePasswordStrength(currentPassword)
      }

      // Update toggle button
      const toggleBtnId = targetInputId === 'editPassword' ? 'editTogglePasswordBtn' : 'togglePasswordBtn'
      const toggleBtn = document.getElementById(toggleBtnId)
      if (toggleBtn) {
        setButtonIcon(toggleBtn, '<i class="fas fa-eye-slash"></i>')
      }

      showToast(i18n.t('popup.password.passwordApplied'), 'success')
    }

    // Close modal
    modal.classList.remove('show')
    setTimeout(() => modal.remove(), 300)
  })

  // Close button
  closeBtn.addEventListener('click', () => {
    modal.classList.remove('show')
    setTimeout(() => modal.remove(), 300)
  })

  // Click outside to close
  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      modal.classList.remove('show')
      setTimeout(() => modal.remove(), 300)
    }
  })
}

/**
 * Handle password generation button click
 */
function handleGeneratePassword() {
  showPasswordGeneratorModal()
}

/**
 * Handle password visibility toggle
 */
function handleTogglePassword() {
  const passwordInput = document.getElementById('itemPassword')
  const toggleBtn = document.getElementById('togglePasswordBtn')
  
  if (!passwordInput || !toggleBtn) return

  if (passwordInput.type === 'password') {
    passwordInput.type = 'text'
    setButtonIcon(toggleBtn, '<i class="fas fa-eye-slash"></i>')
  } else {
    passwordInput.type = 'password'
    setButtonIcon(toggleBtn, '<i class="fas fa-eye"></i>')
  }
}

/**
 * Handle copy password to clipboard
 */
async function handleCopyPassword() {
  const passwordInput = document.getElementById('itemPassword')
  if (!passwordInput || !passwordInput.value) {
    showToast(i18n.t('popup.password.noPasswordToCopy'), 'error')
    return
  }

  try {
    await copyToClipboard(passwordInput.value)
    showToast(i18n.t('popup.password.passwordCopied'), 'success')
  } catch (error) {
    showToast(i18n.t('popup.password.failedToCopyPassword'), 'error')
  }
}

/**
 * Edit Form Password Functions
 */

/**
 * Update password strength indicator for Edit form
 * @param {string} password - Password to check
 */
function updateEditPasswordStrength(password) {
  const strengthBar = document.getElementById('editPasswordStrength')
  const strengthFill = document.getElementById('editStrengthFill')
  const strengthText = document.getElementById('editStrengthText')

  if (!strengthBar || !strengthFill || !strengthText) return

  if (!password || password.length === 0) {
    strengthBar.style.display = 'none'
    return
  }

  const { level, text } = calculatePasswordStrength(password)

  strengthBar.style.display = 'flex'
  strengthFill.className = `strength-fill ${level}`
  strengthText.className = `strength-text ${level}`
  strengthText.textContent = text
}

/**
 * Handle generate password for Edit form
 */
function handleEditGeneratePassword() {
  showPasswordGeneratorModal('editPassword')
}

/**
 * Handle password visibility toggle for Edit form
 */
function handleEditTogglePassword() {
  const passwordInput = document.getElementById('editPassword')
  const toggleBtn = document.getElementById('editTogglePasswordBtn')

  if (!passwordInput || !toggleBtn) return

  if (passwordInput.type === 'password') {
    passwordInput.type = 'text'
    setButtonIcon(toggleBtn, '<i class="fas fa-eye-slash"></i>')
  } else {
    passwordInput.type = 'password'
    setButtonIcon(toggleBtn, '<i class="fas fa-eye"></i>')
  }
}

/**
 * Handle copy password to clipboard for Edit form
 */
async function handleEditCopyPassword() {
  const passwordInput = document.getElementById('editPassword')
  if (!passwordInput || !passwordInput.value) {
    showToast(i18n.t('popup.password.noPasswordToCopy'), 'error')
    return
  }

  try {
    await copyToClipboard(passwordInput.value)
    showToast(i18n.t('popup.password.passwordCopied'), 'success')
  } catch (error) {
    showToast(i18n.t('popup.password.failedToCopyPassword'), 'error')
  }
}

/**
 * Show standalone password generator modal (from header button)
 */
async function showStandalonePasswordGeneratorModal() {
  const modal = document.getElementById('passwordGeneratorModal')
  if (!modal) {
    console.error('Password generator modal not found')
    return
  }

  // Get maximum password length from JWT
  const maxLength = await getPasswordMaxLength()

  // Load saved password preferences (length + character types)
  chrome.storage.local.get([
    'passwordGeneratorLength',
    'passwordGeneratorLowercase',
    'passwordGeneratorUppercase',
    'passwordGeneratorNumbers',
    'passwordGeneratorSymbols'
  ], (result) => {
    const savedLength = result.passwordGeneratorLength || 16
    const savedLowercase = result.passwordGeneratorLowercase ?? true
    const savedUppercase = result.passwordGeneratorUppercase ?? true
    const savedNumbers = result.passwordGeneratorNumbers ?? true
    const savedSymbols = result.passwordGeneratorSymbols ?? true

    // Update slider and display
    const slider = document.getElementById('passwordLengthSlider')
    const valueDisplay = document.getElementById('passwordLengthValue')
    if (slider) {
      slider.max = maxLength.toString()
      slider.value = Math.min(savedLength, maxLength).toString()
    }
    if (valueDisplay) valueDisplay.textContent = Math.min(savedLength, maxLength).toString()

    // Update checkboxes
    const lowercaseCheck = document.getElementById('passwordGenLowercase')
    const uppercaseCheck = document.getElementById('passwordGenUppercase')
    const numbersCheck = document.getElementById('passwordGenNumbers')
    const symbolsCheck = document.getElementById('passwordGenSymbols')

    if (lowercaseCheck) lowercaseCheck.checked = savedLowercase
    if (uppercaseCheck) uppercaseCheck.checked = savedUppercase
    if (numbersCheck) numbersCheck.checked = savedNumbers
    if (symbolsCheck) symbolsCheck.checked = savedSymbols

    // Setup event listeners and auto-generate password
    setupPasswordGeneratorModalListeners(savedLength, {
      lowercase: savedLowercase,
      uppercase: savedUppercase,
      numbers: savedNumbers,
      symbols: savedSymbols
    })
  })

  // Show modal
  modal.style.display = 'flex'
  // Add show class for opacity transition
  setTimeout(() => modal.classList.add('show'), 10)
}

/**
 * Setup event listeners for password generator modal
 * @param {number} savedLength - Saved password length
 * @param {object} savedOptions - Saved character type options
 */
function setupPasswordGeneratorModalListeners(savedLength, savedOptions) {
  const modal = document.getElementById('passwordGeneratorModal')
  const closeBtn = document.getElementById('closePasswordGeneratorModal')
  const closeBtn2 = document.getElementById('closePasswordGeneratorModalBtn')
  const generateBtn = document.getElementById('generatePasswordBtn2')
  const copyBtn = document.getElementById('copyGeneratedPasswordBtn')
  const slider = document.getElementById('passwordLengthSlider')
  const valueDisplay = document.getElementById('passwordLengthValue')
  const output = document.getElementById('generatedPasswordOutput')
  const lowercaseCheck = document.getElementById('passwordGenLowercase')
  const uppercaseCheck = document.getElementById('passwordGenUppercase')
  const numbersCheck = document.getElementById('passwordGenNumbers')
  const symbolsCheck = document.getElementById('passwordGenSymbols')

  // Close button handlers
  const closeModal = () => {
    // Remove show class for opacity transition
    modal.classList.remove('show')
    // Wait for transition then hide
    setTimeout(() => {
      modal.style.display = 'none'
      // Clear output
      if (output) {
        output.textContent = i18n.t('popup.passwordGenerator.outputPlaceholder') || 'Click Generate to create a password'
        output.classList.add('empty')
      }
      if (copyBtn) copyBtn.disabled = true
    }, 300)
  }

  if (closeBtn) {
    closeBtn.removeEventListener('click', closeModal)
    closeBtn.addEventListener('click', closeModal)
  }
  
  if (closeBtn2) {
    closeBtn2.removeEventListener('click', closeModal)
    closeBtn2.addEventListener('click', closeModal)
  }

  // Click outside to close
  const outsideClickHandler = (e) => {
    if (e.target === modal) {
      closeModal()
    }
  }
  modal.removeEventListener('click', outsideClickHandler)
  modal.addEventListener('click', outsideClickHandler)

  // Slider handler
  if (slider && valueDisplay) {
    const sliderHandler = (e) => {
      const newLength = parseInt(e.target.value)
      valueDisplay.textContent = newLength
      // Save preference
      chrome.storage.local.set({ passwordGeneratorLength: newLength })
    }
    slider.removeEventListener('input', sliderHandler)
    slider.addEventListener('input', sliderHandler)
  }

  // Checkbox handlers - save preferences when changed
  const checkboxHandler = (checkboxId, storageKey) => {
    const checkbox = document.getElementById(checkboxId)
    if (checkbox) {
      const handler = (e) => {
        chrome.storage.local.set({ [storageKey]: e.target.checked })
      }
      checkbox.removeEventListener('change', handler)
      checkbox.addEventListener('change', handler)
    }
  }

  checkboxHandler('passwordGenLowercase', 'passwordGeneratorLowercase')
  checkboxHandler('passwordGenUppercase', 'passwordGeneratorUppercase')
  checkboxHandler('passwordGenNumbers', 'passwordGeneratorNumbers')
  checkboxHandler('passwordGenSymbols', 'passwordGeneratorSymbols')

  // Generate button handler
  if (generateBtn && output && copyBtn) {
    const generateHandler = () => {
      const length = parseInt(slider.value)
      const options = {
        lowercase: document.getElementById('passwordGenLowercase')?.checked ?? true,
        uppercase: document.getElementById('passwordGenUppercase')?.checked ?? true,
        numbers: document.getElementById('passwordGenNumbers')?.checked ?? true,
        symbols: document.getElementById('passwordGenSymbols')?.checked ?? true
      }

      // Ensure at least one option is selected
      if (!options.lowercase && !options.uppercase && !options.numbers && !options.symbols) {
        showToast(i18n.t('popup.passwordGenerator.selectCharacterType') || 'Please select at least one character type', 'error')
        return
      }

      // Generate password
      const password = generateSecurePassword(length, options)
      output.textContent = password
      output.classList.remove('empty')
      copyBtn.disabled = false
    }
    generateBtn.removeEventListener('click', generateHandler)
    generateBtn.addEventListener('click', generateHandler)
  }

  // Copy button handler
  if (copyBtn && output) {
    const copyHandler = async () => {
      const password = output.textContent
      if (!password || output.classList.contains('empty')) return

      try {
        await copyToClipboard(password)
        showToast(i18n.t('popup.password.passwordCopied') || 'Password copied to clipboard', 'success')

        // Visual feedback
        setButtonIcon(copyBtn, '<i class="fas fa-check"></i>')
        setTimeout(() => {
          setButtonIcon(copyBtn, icons.copy)
        }, 2000)
      } catch (error) {
        showToast(i18n.t('popup.password.failedToCopyPassword') || 'Failed to copy password', 'error')
      }
    }
    copyBtn.removeEventListener('click', copyHandler)
    copyBtn.addEventListener('click', copyHandler)
  }

  // Auto-generate password on modal open with saved preferences
  if (output && copyBtn && savedOptions) {
    const password = generateSecurePassword(savedLength, savedOptions)
    output.textContent = password
    output.classList.remove('empty')
    copyBtn.disabled = false
  }
}
