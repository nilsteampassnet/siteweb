/**
 * Extension Name: Teampass Manager Extension
 * Copyright (c) 2026, LogCarré. All Rights Reserved.
 *
 * This code is proprietary software. It is distributed on a non-public,
 * limited-use basis under the terms of a Commercial License.
 *
 * Unauthorized copying, modification, redistribution, or reverse engineering
 * of this code, or any part thereof, is strictly prohibited.
 */

/**
 * i18n (Internationalization) Module
 *
 * Provides translation functions for the Teampass extension.
 * Currently supports English as the base language.
 *
 * Usage:
 *   const i18n = new I18n();
 *   await i18n.init();
 *   const text = i18n.t('popup.main.addItemButton'); // Returns "Add new item"
 *   const textWithPlaceholder = i18n.t('content.toast.saveCredentialsFor', { domain: 'example.com' });
 */

class I18n {
  constructor() {
    this.currentLocale = 'en' // Default locale
    this.translations = {}
    this.isInitialized = false
  }

  /**
   * Initialize i18n - loads translation file
   * @param {string} locale - Locale to load (default: 'en')
   * @returns {Promise<void>}
   */
  async init(locale = 'en') {
    try {
      this.currentLocale = locale

      // Load translation file
      const response = await fetch(chrome.runtime.getURL(`i18n/${locale}.json`))

      if (!response.ok) {
        throw new Error(`Failed to load translations for locale: ${locale}`)
      }

      this.translations = await response.json()
      this.isInitialized = true

      console.log(`[i18n] Translations loaded for locale: ${locale}`)
    } catch (error) {
      console.error('[i18n] Failed to load translations:', error)
      // Fallback to empty translations
      this.translations = {}
      this.isInitialized = true
    }
  }

  /**
   * Get translation for a key
   * @param {string} key - Translation key in dot notation (e.g., 'popup.main.addItemButton')
   * @param {object} params - Optional parameters for string interpolation
   * @returns {string} Translated string or key if not found
   */
  t(key, params = {}) {
    if (!this.isInitialized) {
      console.warn('[i18n] Not initialized yet. Call init() first.')
      return key
    }

    // Navigate through nested object using dot notation
    const keys = key.split('.')
    let value = this.translations

    for (const k of keys) {
      if (value && typeof value === 'object' && k in value) {
        value = value[k]
      } else {
        // Key not found, return the key itself as fallback
        console.warn(`[i18n] Translation key not found: ${key}`)
        return key
      }
    }

    // If value is not a string, return key
    if (typeof value !== 'string') {
      console.warn(`[i18n] Translation value is not a string for key: ${key}`)
      return key
    }

    // Replace placeholders {param} with values from params object
    return this.interpolate(value, params)
  }

  /**
   * Interpolate placeholders in a string
   * @param {string} template - String template with {placeholder} syntax
   * @param {object} params - Parameters to replace
   * @returns {string} Interpolated string
   *
   * Example:
   *   interpolate("Hello {name}!", { name: "World" }) => "Hello World!"
   */
  interpolate(template, params) {
    return template.replace(/\{(\w+)\}/g, (match, key) => {
      return params.hasOwnProperty(key) ? params[key] : match
    })
  }

  /**
   * Get current locale
   * @returns {string} Current locale code
   */
  getLocale() {
    return this.currentLocale
  }

  /**
   * Check if i18n is initialized
   * @returns {boolean} True if initialized
   */
  isReady() {
    return this.isInitialized
  }
}

// Create singleton instance
const i18n = new I18n()

// Make available globally first
if (typeof window !== 'undefined') {
  window.i18n = i18n
}

// Auto-initialize with English on load
// Delay initialization to ensure the extension context is fully ready
// This prevents "Unable to load JavaScript file" errors in Chrome/Edge
if (typeof window !== 'undefined') {
  // Use setTimeout to defer initialization after script loading
  setTimeout(() => {
    i18n.init('en').catch(error => {
      console.error('[i18n] Auto-initialization failed:', error)
    })
  }, 0)
}
