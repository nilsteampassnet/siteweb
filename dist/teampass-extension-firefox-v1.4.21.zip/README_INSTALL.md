# Teampass Browser Extension - Firefox

## Version 1.4.21

### Installation Instructions

#### Mozilla Firefox


1. Open Firefox
2. Navigate to `about:debugging#/runtime/this-firefox`
3. Click "Load Temporary Add-on..."
4. Select the `manifest.json` file from this directory
5. The extension will be loaded temporarily

**Note**: For permanent installation on Firefox, the extension must be signed by Mozilla or you must disable signature verification in about:config (xpinstall.signatures.required = false)


### Configuration

1. Right-click the extension icon → Options
2. Fill in your Teampass server details:
   - Server URL: https://your-teampass-server.com
   - Licence Email: your-email@company.com
   - Instance FQDN: your-server.com
   - Username: your_username
   - Password: your_password
   - API Key: your_api_key

3. Click "Save Configuration"
4. Click "Test Licence" to verify your licence
5. Click "Force Re-authenticate" to test connection

### Font Awesome

Font Awesome icons are **already included** in this package.

**Location**: `assets/fontawesome/`
- `fontawesome.min.css`
- `webfonts/fa-solid-900.woff2`
- `webfonts/fa-regular-400.woff2`

If icons are not displaying properly, verify that the `assets/fontawesome/` directory exists and contains the files above.

### Support

For issues or questions:
- Email: support@teampass.net
- Documentation: https://teampass.readthedocs.io/

### Licence

This extension requires a valid Teampass licence.
Licence verification is performed automatically.

© 2024 Teampass - Collaborative Password Manager
