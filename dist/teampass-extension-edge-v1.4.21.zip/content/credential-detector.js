/**
 * Extension Name: Teampass Manager Extension
 * Copyright (c) 2026, LogCarré. All Rights Reserved.
 *
 * This code is proprietary software. It is distributed on a non-public,
 * limited-use basis under the terms of a Commercial License.
 *
 * Unauthorized copying, modification, redistribution, or reverse engineering
 * of this code, or any part thereof, is strictly prohibited.
 */

/**
 * Teampass Credential Detector
 *
 * Detects login form submissions and triggers credential save workflow
 */

class CredentialDetector {
  constructor() {
    // No instance state needed - everything stored in chrome.storage.session
  }

  /**
   * Initialize credential detection
   */
  async initialize() {
    debugLog('🔐 [Teampass] === Credential Detector Initialize START ===')
    debugLog('🔐 [Teampass] CONFIG available:', typeof CONFIG !== 'undefined')

    if (typeof CONFIG === 'undefined') {
      console.error('🔐 [Teampass] CONFIG is not defined! Cannot initialize credential detector.')
      return
    }

    debugLog('🔐 [Teampass] CONFIG.CREDENTIAL_SAVE:', CONFIG.CREDENTIAL_SAVE)

    if (!CONFIG.CREDENTIAL_SAVE.ENABLE_AUTO_DETECT) {
      debugLog('🔐 [Teampass] Credential auto-detect is DISABLED in config')
      return
    }

    debugLog('🔐 [Teampass] ✅ Credential detector initialized successfully')
    debugLog('🔐 [Teampass] Current URL:', window.location.href)
    debugLog('🔐 [Teampass] TeampassToast available:', typeof window.teampassToast !== 'undefined')

    // Check for pending credentials from previous page (after navigation)
    await this.checkPendingCredentialsAfterNavigation()

    // Setup form submit listeners
    this.setupFormListeners()

    debugLog('🔐 [Teampass] === Credential Detector Initialize END ===')
  }

  /**
   * Check if current page is a TOTP/2FA verification page
   *
   * @returns {boolean} True if current page is a TOTP/2FA page
   */
  isTotpOrTwoFactorPage() {
    const url = window.location.href.toLowerCase()
    const pathname = window.location.pathname.toLowerCase()

    // Common TOTP/2FA URL patterns
    const totpPatterns = [
      '/2fa',
      '/totp',
      '/otp',
      '/verify',
      '/verification',
      '/mfa',
      '/two-factor',
      '/two_factor',
      '/authenticator',
      '/security-code',
      '/security_code',
      '/challenge',
      '/confirm'
    ]

    // Check if URL or pathname contains any TOTP pattern
    const hasTotpPattern = totpPatterns.some(pattern =>
      url.includes(pattern) || pathname.includes(pattern)
    )

    if (hasTotpPattern) {
      debugLog('🔐 [Teampass] TOTP/2FA page detected:', window.location.href)
      return true
    }

    // Check for TOTP input fields on the page
    const hasOtpInput = document.querySelector(
      'input[type="text"][autocomplete="one-time-code"], ' +
      'input[name*="otp"], ' +
      'input[name*="totp"], ' +
      'input[name*="code"], ' +
      'input[id*="otp"], ' +
      'input[id*="totp"], ' +
      'input[id*="verification"], ' +
      'input[placeholder*="code"]'
    )

    if (hasOtpInput) {
      debugLog('🔐 [Teampass] TOTP/2FA input field detected on page')
      return true
    }

    return false
  }

  /**
   * Check if there are pending credentials from a previous page (after navigation)
   */
  async checkPendingCredentialsAfterNavigation() {
    try {
      debugLog('🔐 [Teampass] Checking for pending credentials after navigation...')

      // Use service worker as proxy to access storage
      const response = await chrome.runtime.sendMessage({
        action: 'getPendingCredential'
      })

      if (!response.success || !response.data) {
        debugLog('🔐 [Teampass] No pending credentials found')
        return
      }

      const credentials = response.data
      const currentUrl = window.location.href

      debugLog('🔐 [Teampass] Found pending credentials!')
      debugLog('🔐 [Teampass] Stored URL:', credentials.url)
      debugLog('🔐 [Teampass] Current URL:', currentUrl)

      // Check if URL has changed (navigation occurred)
      if (credentials.url !== currentUrl) {
        debugLog('🔐 [Teampass] ✅ URL changed! Navigation detected')

        // Check if this is a TOTP/2FA page - if so, wait for next navigation
        if (this.isTotpOrTwoFactorPage()) {
          debugLog('🔐 [Teampass] ⏸️  TOTP/2FA page detected - waiting for complete authentication...')
          return // Keep credentials in storage, don't show toast yet
        }

        debugLog('🔐 [Teampass] ✅ Not a TOTP page - processing successful login...')

        // Check if navigation happened recently (within timeout)
        const timeSinceCapture = Date.now() - credentials.timestamp
        if (timeSinceCapture > CONFIG.CREDENTIAL_SAVE.URL_CHANGE_TIMEOUT) {
          debugLog('🔐 [Teampass] ❌ Credentials too old, ignoring')
          // Use service worker to remove credentials
          await chrome.runtime.sendMessage({
            action: 'removePendingCredential'
          })
          return
        }

        // Process successful login
        await this.processSuccessfulLogin(credentials)
      } else {
        debugLog('🔐 [Teampass] URL not changed yet, still on same page')
      }
    } catch (error) {
      console.error('🔐 [Teampass] Error checking pending credentials:', error)
    }
  }

  /**
   * Setup listeners for form submissions
   */
  setupFormListeners() {
    debugLog('🔐 [Teampass] Setting up form listeners...')

    // Listen for form submit events
    document.addEventListener('submit', (event) => {
      debugLog('🔐 [Teampass] ⚡ Submit event captured!', event)
      this.handleFormSubmit(event)
    }, true) // Use capture phase to catch before preventDefault

    // Also listen for click events on submit buttons (for AJAX forms)
    document.addEventListener('click', (event) => {
      const target = event.target

      // Check if clicked element is a submit button
      if (target.matches('button[type="submit"], input[type="submit"], button:not([type])')) {
        debugLog('🔐 [Teampass] ⚡ Submit button clicked!', target)

        // Find the parent form (if exists)
        const form = target.closest('form')

        // Delay slightly to let the form fields be filled
        setTimeout(() => {
          if (form) {
            debugLog('🔐 [Teampass] Found parent form:', form)
            this.handleFormClick(form)
          } else {
            debugLog('🔐 [Teampass] No parent form found, checking entire document for login fields')
            // Handle formless login pages (like Proxmox)
            this.handleFormClick(null)
          }
        }, 100)
      }
    }, true)

    debugLog('🔐 [Teampass] ✅ Form listeners attached (submit + click)')
  }

  /**
   * Handle form click (for AJAX forms that don't trigger submit event)
   *
   * @param {HTMLFormElement|null} form - Form element (or null for formless pages)
   */
  async handleFormClick(form) {
    debugLog('🔐 [Teampass] Handling form click')

    // Check if this is a login form (works with or without <form> element)
    if (!this.isLoginForm(form)) {
      debugLog('🔐 [Teampass] Not a login form, ignoring')
      return
    }

    debugLog('🔐 [Teampass] ✅ Login form detected via click! Capturing credentials...')

    // Capture credentials (works with or without <form> element)
    const credentials = this.captureCredentials(form)

    if (!credentials || !credentials.username || !credentials.password) {
      debugLog('🔐 [Teampass] ❌ No valid credentials found (maybe form not filled yet)')
      return
    }

    debugLog('🔐 [Teampass] ✅ Credentials captured from click:', { username: credentials.username, domain: credentials.domain })

    // Validate password length
    if (credentials.password.length < CONFIG.CREDENTIAL_SAVE.MIN_PASSWORD_LENGTH) {
      debugLog('🔐 [Teampass] Password too short, ignoring')
      return
    }

    // Check HTTPS requirement
    if (CONFIG.CREDENTIAL_SAVE.REQUIRE_HTTPS && window.location.protocol !== 'https:') {
      debugLog('🔐 [Teampass] Not HTTPS, ignoring')
      return
    }

    // Store credentials in session storage IMMEDIATELY (before navigation)
    debugLog('🔐 [Teampass] Storing credentials in session storage...')
    await this.storeCredentialsInSession(credentials)
    debugLog('🔐 [Teampass] ✅ Credentials stored, waiting for navigation...')
  }

  /**
   * Handle form submission
   *
   * @param {Event} event - Submit event
   */
  async handleFormSubmit(event) {
    const form = event.target
    debugLog('🔐 [Teampass] Form submitted', form)

    // Check if this is a login form
    if (!this.isLoginForm(form)) {
      debugLog('🔐 [Teampass] Not a login form, ignoring')
      return
    }

    debugLog('🔐 [Teampass] ✅ Login form detected! Capturing credentials...')

    // Capture credentials
    const credentials = this.captureCredentials(form)

    if (!credentials || !credentials.username || !credentials.password) {
      debugLog('🔐 [Teampass] ❌ No valid credentials found')
      return
    }

    debugLog('🔐 [Teampass] ✅ Credentials captured:', { username: credentials.username, domain: credentials.domain })

    // Validate password length
    if (credentials.password.length < CONFIG.CREDENTIAL_SAVE.MIN_PASSWORD_LENGTH) {
      debugLog('🔐 [Teampass] Password too short, ignoring')
      return
    }

    // Check HTTPS requirement
    if (CONFIG.CREDENTIAL_SAVE.REQUIRE_HTTPS && window.location.protocol !== 'https:') {
      debugLog('🔐 [Teampass] Not HTTPS, ignoring')
      return
    }

    // Store credentials in session storage IMMEDIATELY (before navigation)
    debugLog('🔐 [Teampass] Storing credentials in session storage...')
    await this.storeCredentialsInSession(credentials)
    debugLog('🔐 [Teampass] ✅ Credentials stored, waiting for navigation...')
  }

  /**
   * Check if form is a login form
   * Works with traditional <form> elements AND formless login pages
   *
   * @param {HTMLFormElement|null} form - Form element (or null to check entire document)
   * @returns {boolean} True if login form
   */
  isLoginForm(form) {
    // Use shared utility function that works with or without <form> element
    return hasLoginFormInContext(form)
  }

  /**
   * Capture credentials from form or entire page
   * Works with traditional <form> elements AND formless login pages
   *
   * @param {HTMLFormElement|null} form - Form element (or null for entire document)
   * @returns {object|null} Captured credentials
   */
  captureCredentials(form) {
    // Use shared utility function that works with or without <form> element
    return captureCredentialsFromContext(form)
  }

  /**
   * Process successful login (called after navigation is detected)
   *
   * @param {object} credentials - Credentials that were captured
   */
  async processSuccessfulLogin(credentials) {
    debugLog('🔐 [Teampass] Processing successful login...')

    try {
      // Check if entry already exists
      const existingCheck = await this.checkExistingEntry(credentials)

      // Show toast
      this.showSaveToast(existingCheck, credentials)

      debugLog('🔐 [Teampass] ✅ Toast shown successfully!')
    } catch (error) {
      console.error('🔐 [Teampass] Error processing successful login:', error)
    }
  }

  /**
   * Store credentials in session storage
   * Uses service worker as proxy to avoid "Access to storage is not allowed" error
   *
   * @param {object} credentials - Credentials to store
   */
  async storeCredentialsInSession(credentials) {
    try {
      // Use service worker as proxy to access storage
      const response = await chrome.runtime.sendMessage({
        action: 'storeCredentialInSession',
        data: {
          credential: credentials
        }
      })

      if (response.success) {
        debugLog('🔐 [Teampass] Credentials stored in session storage')
      } else {
        console.error('🔐 [Teampass] Failed to store credentials:', response.error)
      }
    } catch (error) {
      console.error('🔐 [Teampass] Failed to store credentials:', error)
    }
  }

  /**
   * Check if entry already exists in Teampass
   *
   * @param {object} credentials - Credentials to check
   * @returns {Promise<object>} Check result
   */
  async checkExistingEntry(credentials) {
    try {
      debugLog('🔐 [Teampass] Checking for existing entry...')

      const response = await chrome.runtime.sendMessage({
        action: 'checkCredentialExists',
        data: {
          url: credentials.url,
          login: credentials.username
        }
      })

      if (response && response.success) {
        debugLog('🔐 [Teampass] Existing entry check result:', response.data)
        return response.data
      } else {
        console.error('🔐 [Teampass] Failed to check existing entry:', response?.error)
        return { exists: false, mode: 'new' }
      }
    } catch (error) {
      console.error('🔐 [Teampass] Error checking existing entry:', error)
      return { exists: false, mode: 'new' }
    }
  }

  /**
   * Show save toast notification
   *
   * @param {object} checkResult - Result from existing entry check
   * @param {object} credentials - Captured credentials
   */
  showSaveToast(checkResult, credentials) {
    const { exists, mode, item, hasChanged } = checkResult

    // Check if teampassToast is available
    if (typeof window.teampassToast === 'undefined') {
      console.error('🔐 [Teampass] TeampassToast not available, cannot show save toast')
      return
    }

    debugLog('🔐 [Teampass] Showing save toast:', { mode: exists ? 'update' : 'new', domain: credentials.domain })

    // Show toast
    window.teampassToast.show({
      mode: exists ? 'update' : 'new',
      domain: credentials.domain,
      hasChanged: hasChanged || false,
      onSave: () => this.handleSaveClick(mode, item),
      onSkip: () => this.handleSkipClick()
    })
  }

  /**
   * Handle Save button click in toast
   *
   * @param {string} mode - Save mode ('new' or 'update')
   * @param {object|null} existingItem - Existing item if update mode
   */
  async handleSaveClick(mode, existingItem) {
    debugLog('🔐 [Teampass] Save clicked, opening popup in save mode:', mode)

    try {
      // Send message to service worker to open popup
      // CRITICAL: This must be called synchronously from the click handler
      // to preserve the user gesture context for chrome.action.openPopup()
      await chrome.runtime.sendMessage({
        action: 'openSavePopup',
        data: {
          mode,
          existingItem
        }
      })
    } catch (error) {
      console.error('🔐 [Teampass] Failed to open save popup:', error)
    }
  }

  /**
   * Handle Skip button click in toast
   */
  async handleSkipClick() {
    debugLog('🔐 [Teampass] Skip clicked, clearing session credentials')

    try {
      // Use service worker to clear session storage
      await chrome.runtime.sendMessage({
        action: 'removePendingCredential'
      })
    } catch (error) {
      console.error('🔐 [Teampass] Failed to clear session:', error)
    }
  }
}

// Initialize detector when DOM is ready
let credentialDetector = null

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    credentialDetector = new CredentialDetector()
    credentialDetector.initialize()

    // Export for testing/debugging
    if (typeof window !== 'undefined') {
      window.credentialDetector = credentialDetector
    }
  })
} else {
  credentialDetector = new CredentialDetector()
  credentialDetector.initialize()

  // Export for testing/debugging
  if (typeof window !== 'undefined') {
    window.credentialDetector = credentialDetector
  }
}
