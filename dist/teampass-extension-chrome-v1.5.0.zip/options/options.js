/**
 * Extension Name: Teampass Manager Extension
 * Copyright (c) 2026, LogCarré. All Rights Reserved.
 *
 * This code is proprietary software. It is distributed on a non-public, 
 * limited-use basis under the terms of a Commercial License.
 *
 * Unauthorized copying, modification, redistribution, or reverse engineering 
 * of this code, or any part thereof, is strictly prohibited.
 */


// Import dependencies
import { CryptoHelper } from '../lib/modules/crypto-helper.js'
import { LicenceChecker } from '../lib/modules/licence-checker.js'
import { debugLog, initDebugLogging, setupDebugLoggingListener } from '../lib/modules/debug-logger.js'
import CONFIG from '../config.js'
import i18n from '../i18n/i18n.js'
import { applyDOMTranslations } from '../i18n/i18n-dom.js'
// Initialize crypto helper
const cryptoHelper = new CryptoHelper()
const licenceChecker = new LicenceChecker()

// DOM elements - will be initialized when DOM is ready
let form, serverUrlInput, licenceEmailInput, licenceFqdnInput, licenceTokenInput
let usernameInput, passwordInput, apiKeyInput
let rememberMeCheckbox, autoRefreshCheckbox, debugLoggingCheckbox
let togglePasswordBtn, testLicenceBtn, testConnectionBtn, forceAuthBtn, authAndAutoFillBtn
let saveBtn, clearAllBtn, statusMessage, currentStatus, debugInfo
let globalLoader, globalLoaderText

// Track initial form values for change detection
let initialFormValues = {}

/**
 * Show global modal loader with custom text
 * @param {string} text - Loader text to display
 */
function showLoader(text = i18n.t('options.messages.processing')) {
  if (globalLoader && globalLoaderText) {
    globalLoaderText.textContent = text
    globalLoader.style.display = 'flex'
  }
}

/**
 * Hide global modal loader
 */
function hideLoader() {
  if (globalLoader) {
    globalLoader.style.display = 'none'
  }
}

// Load saved settings and attach event listeners when DOM is ready
document.addEventListener('DOMContentLoaded', async () => {
  // Initialize async modules first
  try {
    await Promise.all([
      initDebugLogging(),
      i18n.init('en')
    ])
    setupDebugLoggingListener()
    applyDOMTranslations()
  } catch (error) {
    console.error('Failed to initialize modules:', error)
  }

  // Initialize DOM elements
  form = document.getElementById('settingsForm')
  serverUrlInput = document.getElementById('serverUrl')
  licenceEmailInput = document.getElementById('licenceEmail')
  licenceFqdnInput = document.getElementById('licenceFqdn')
  licenceTokenInput = document.getElementById('licenceToken')
  usernameInput = document.getElementById('username')
  passwordInput = document.getElementById('password')
  apiKeyInput = document.getElementById('apiKey')
  rememberMeCheckbox = document.getElementById('rememberMe')
  autoRefreshCheckbox = document.getElementById('autoRefresh')
  debugLoggingCheckbox = document.getElementById('debugLogging')
  togglePasswordBtn = document.getElementById('togglePassword')
  testLicenceBtn = document.getElementById('testLicenceBtn')
  testConnectionBtn = document.getElementById('testConnectionBtn')
  forceAuthBtn = document.getElementById('forceAuthBtn')
  authAndAutoFillBtn = document.getElementById('authAndAutoFillBtn')
  saveBtn = document.getElementById('saveBtn')
  clearAllBtn = document.getElementById('clearAllBtn')
  statusMessage = document.getElementById('statusMessage')
  currentStatus = document.getElementById('currentStatus')
  debugInfo = document.getElementById('debugInfo')
  globalLoader = document.getElementById('globalLoader')
  globalLoaderText = document.getElementById('globalLoaderText')

  // Ensure loader is hidden on page load
  hideLoader()

  // Load settings
  loadSettings()

  // Event listeners
  form.addEventListener('submit', handleSave)
  testLicenceBtn.addEventListener('click', handleTestLicence)
  testConnectionBtn.addEventListener('click', handleTestConnection)
  forceAuthBtn.addEventListener('click', handleForceAuth)
  authAndAutoFillBtn.addEventListener('click', handleAuthAndAutoFill)
  clearAllBtn.addEventListener('click', handleClearAll)
  togglePasswordBtn.addEventListener('click', handleTogglePassword)

  // Auto-fill FQDN when server URL changes
  serverUrlInput.addEventListener('input', handleServerUrlChange)

  // Add change detection listeners to all form fields
  addChangeDetectionListeners()
})

/**
 * Auto-fill FQDN from server URL
 */
function handleServerUrlChange() {
  const serverUrl = serverUrlInput.value.trim()

  // Only auto-fill if FQDN is empty
  if (serverUrl && !licenceFqdnInput.value) {
    try {
      const url = new URL(serverUrl)
      licenceFqdnInput.value = url.hostname
    } catch (error) {
      // Invalid URL, ignore
    }
  }

  // Check for changes after auto-fill
  checkForChanges()
}

/**
 * Store current form values as initial values
 */
function storeInitialFormValues() {
  initialFormValues = {
    serverUrl: serverUrlInput.value.trim(),
    licenceEmail: licenceEmailInput.value.trim(),
    licenceFqdn: licenceFqdnInput.value.trim(),
    licenceToken: licenceTokenInput.value.trim(),
    username: usernameInput.value.trim(),
    password: passwordInput.value,
    apiKey: apiKeyInput.value.trim(),
    rememberMe: rememberMeCheckbox.checked,
    autoRefresh: autoRefreshCheckbox.checked,
    debugLogging: debugLoggingCheckbox.checked
  }
  debugLog('Initial form values stored:', initialFormValues)
}

/**
 * Check if form has unsaved changes
 */
function hasUnsavedChanges() {
  return (
    serverUrlInput.value.trim() !== initialFormValues.serverUrl ||
    licenceEmailInput.value.trim() !== initialFormValues.licenceEmail ||
    licenceFqdnInput.value.trim() !== initialFormValues.licenceFqdn ||
    licenceTokenInput.value.trim() !== initialFormValues.licenceToken ||
    usernameInput.value.trim() !== initialFormValues.username ||
    passwordInput.value !== initialFormValues.password ||
    apiKeyInput.value.trim() !== initialFormValues.apiKey ||
    rememberMeCheckbox.checked !== initialFormValues.rememberMe ||
    autoRefreshCheckbox.checked !== initialFormValues.autoRefresh ||
    debugLoggingCheckbox.checked !== initialFormValues.debugLogging
  )
}

/**
 * Update Save button style based on unsaved changes
 */
function checkForChanges() {
  const hasChanges = hasUnsavedChanges()

  if (hasChanges) {
    // Has changes: make button blue (primary style)
    saveBtn.classList.remove('btn-secondary')
    saveBtn.classList.add('btn-primary')
    saveBtn.style.background = 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
    saveBtn.style.color = 'white'
    debugLog('Changes detected - button set to primary (blue)')
  } else {
    // No changes: make button gray (secondary style)
    saveBtn.classList.remove('btn-primary')
    saveBtn.classList.add('btn-secondary')
    saveBtn.style.background = ''
    saveBtn.style.color = ''
    debugLog('No changes - button set to secondary (gray)')
  }
}

/**
 * Add change detection listeners to all form fields
 */
function addChangeDetectionListeners() {
  // Text inputs
  const textInputs = [
    serverUrlInput,
    licenceEmailInput,
    licenceFqdnInput,
    licenceTokenInput,
    usernameInput,
    passwordInput,
    apiKeyInput
  ]

  textInputs.forEach(input => {
    input.addEventListener('input', checkForChanges)
  })

  // Checkboxes
  const checkboxes = [
    rememberMeCheckbox,
    autoRefreshCheckbox,
    debugLoggingCheckbox
  ]

  checkboxes.forEach(checkbox => {
    checkbox.addEventListener('change', checkForChanges)
  })
}

/**
 * Refresh extension settings from API
 * Calls the refreshExtensionSettings endpoint to get latest FQDN, token, and URL
 * @param {string} serverUrl - The Teampass server URL to use for the API call
 * @param {string} jwt - Optional JWT token for authentication
 */
async function refreshExtensionSettingsWithUrl(serverUrl, jwt = null) {
  try {
    // Check if server URL is provided
    if (!serverUrl || serverUrl.trim() === '') {
      debugLog('No server URL provided, skipping refreshExtensionSettings')
      return null
    }

    const apiUrl = `${serverUrl.trim()}/api/index.php/misc/refreshExtensionSettings`

    debugLog('Calling refreshExtensionSettings API:', apiUrl)

    const headers = {
      'Content-Type': 'application/json'
    }

    // Add JWT to headers if provided
    if (jwt) {
      headers['Authorization'] = `Bearer ${jwt}`
      debugLog('Including JWT in request')
    }

    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: headers
    })

    if (!response.ok) {
      console.warn('refreshExtensionSettings API returned error:', response.status)
      return null
    }

    const data = await response.json()
    debugLog('refreshExtensionSettings API response:', data)

    return data
  } catch (error) {
    console.error('Failed to refresh extension settings:', error)
    return null
  }
}

/**
 * Load saved settings from storage
 */
async function loadSettings() {
  try {
    const storage = await chrome.storage.local.get([
      'teampass_url',
      'teampass_licence_email',
      'teampass_licence_fqdn',
      'teampass_licence_token',
      'teampass_ext_licence',
      'teampass_credentials_encrypted',
      'teampass_remember_me',
      'teampass_auto_refresh',
      'debug_logging_enabled',
      'teampass_token',
      'token_expiry'
    ])


    debugLog('Loading settings - storage:', storage)

    // Server URL - always restore value (empty string if not set)
    serverUrlInput.value = storage.teampass_url || ''
    debugLog('Server URL restored:', storage.teampass_url)

    // Licence fields - always restore values (empty string if not set)
    licenceEmailInput.value = storage.teampass_licence_email || ''
    licenceFqdnInput.value = storage.teampass_licence_fqdn || ''
    licenceTokenInput.value = storage.teampass_licence_token || ''

    // Credentials (decrypt if saved)
    if (storage.teampass_credentials_encrypted) {
      try {
        const credentials = await cryptoHelper.decryptCredentials(
          storage.teampass_credentials_encrypted
        )
        debugLog('Credentials decrypted successfully')
        usernameInput.value = credentials.username
        passwordInput.value = credentials.password
        apiKeyInput.value = credentials.apiKey
      } catch (error) {
        console.error('Failed to decrypt credentials:', error)
        showMessage(i18n.t('options.messages.credentialsCorrupted'), 'error')
      }
    }
    
    // Options
    rememberMeCheckbox.checked = storage.teampass_remember_me !== false
    autoRefreshCheckbox.checked = storage.teampass_auto_refresh !== false
    debugLoggingCheckbox.checked = storage.debug_logging_enabled === true

    // Store initial values after loading
    storeInitialFormValues()

    // Set initial button state (no changes)
    checkForChanges()

    // Update status
    updateStatus(storage)

    // Auto-refresh status every 5 seconds
    setInterval(async () => {
      const currentStorage = await chrome.storage.local.get([
        'teampass_url',
        'teampass_licence_email',
        'teampass_licence_fqdn',
        'teampass_ext_licence',
        'teampass_credentials_encrypted',
        'teampass_token',
        'token_expiry',
        'teampass_auto_refresh',
        'debug_logging_enabled'
      ])
      updateStatus(currentStorage)
    }, 5000)
    
  } catch (error) {
    console.error('Failed to load settings:', error)
    showMessage(i18n.t('options.messages.loadSettingsFailed') + ' ' + error.message, 'error')
  }
}

/**
 * Update current status display
 */
function updateStatus(storage) {
  const hasUrl = !!storage.teampass_url
  const hasCredentials = !!storage.teampass_credentials_encrypted
  const hasToken = !!storage.teampass_token
  const isTokenValid = storage.token_expiry && Date.now() < storage.token_expiry

  // Clear current status
  currentStatus.textContent = ''

  // Configuration status
  const configP = document.createElement('p')
  const configLabel = document.createElement('strong')
  configLabel.textContent = 'Configuration: '
  configP.appendChild(configLabel)

  const configBadge = document.createElement('span')
  if (hasUrl && hasCredentials) {
    configBadge.className = 'status-badge active'
    configBadge.textContent = i18n.t('options.status.configured')
  } else {
    configBadge.className = 'status-badge inactive'
    configBadge.textContent = i18n.t('options.status.notConfigured')
  }
  configP.appendChild(configBadge)

  // Show test connection result if available
  if (storage._test_connection_result) {
    const testTime = new Date(storage._test_connection_time)
    configP.appendChild(document.createElement('br'))
    const testResult = document.createElement('small')
    if (storage._test_connection_result === 'success') {
      testResult.textContent = `✅ ${i18n.t('options.messages.connectionTestSuccess')} (${testTime.toLocaleTimeString()})`
    } else {
      testResult.textContent = `❌ ${i18n.t('options.messages.connectionTestFailed')} (${testTime.toLocaleTimeString()})`
    }
    configP.appendChild(testResult)
  }

  currentStatus.appendChild(configP)

  // Authentication status
  const authP = document.createElement('p')
  const authLabel = document.createElement('strong')
  authLabel.textContent = 'Authentication: '
  authP.appendChild(authLabel)

  if (hasToken && isTokenValid) {
    const expiryDate = new Date(storage.token_expiry)
    const minutesLeft = Math.floor((storage.token_expiry - Date.now()) / 60000)

    const authBadge = document.createElement('span')
    authBadge.className = 'status-badge active'
    authBadge.textContent = i18n.t('options.status.active')
    authP.appendChild(authBadge)
    authP.appendChild(document.createElement('br'))

    const expirySmall = document.createElement('small')
    expirySmall.textContent = `${i18n.t('options.status.expires')} ${expiryDate.toLocaleTimeString()} (${minutesLeft} ${i18n.t('options.status.min')})`
    authP.appendChild(expirySmall)
  } else if (hasToken && !isTokenValid) {
    const authBadge = document.createElement('span')
    authBadge.className = 'status-badge inactive'
    authBadge.textContent = i18n.t('options.status.expired')
    authP.appendChild(authBadge)
  } else {
    const authBadge = document.createElement('span')
    authBadge.className = 'status-badge inactive'
    authBadge.textContent = i18n.t('options.status.notAuthenticated')
    authP.appendChild(authBadge)
  }

  currentStatus.appendChild(authP)

  // Licence status
  const licenceP = document.createElement('p')
  const licenceLabel = document.createElement('strong')
  licenceLabel.textContent = 'Licence: '
  licenceP.appendChild(licenceLabel)

  const hasLicenceEmail = !!storage.teampass_licence_email
  const hasLicenceFqdn = !!storage.teampass_licence_fqdn

  if (hasLicenceEmail && hasLicenceFqdn) {
    // Check licence data
    let licenceData = null
    try {
      if (storage.teampass_ext_licence) {
        licenceData = JSON.parse(storage.teampass_ext_licence)
      }
    } catch (error) {
      console.error('Failed to parse licence data:', error)
    }

    if (licenceData) {
      if (licenceData.status === 'VALID') {
        const validBadge = document.createElement('span')
        validBadge.className = 'status-badge active'
        validBadge.textContent = i18n.t('options.status.valid')
        licenceP.appendChild(validBadge)
        licenceP.appendChild(document.createElement('br'))

        // Display max users if available
        if (licenceData.maxUsers) {
          const maxUsersSmall = document.createElement('small')
          maxUsersSmall.textContent = `${i18n.t('options.status.maxUsers')} ${licenceData.maxUsers}`
          licenceP.appendChild(maxUsersSmall)
          licenceP.appendChild(document.createElement('br'))
        }

        // Display expiration date if available
        if (licenceData.expirationDate) {
          const expirySmall = document.createElement('small')
          expirySmall.textContent = `${i18n.t('options.status.expires')} ${licenceData.expirationDate}`
          licenceP.appendChild(expirySmall)
          licenceP.appendChild(document.createElement('br'))
        }

        // Display JWT status
        if (licenceData.jwt && licenceData.jwtExpires) {
          const jwtExpiry = new Date(licenceData.jwtExpires * 1000)
          const isJWTValid = Date.now() < (licenceData.jwtExpires * 1000)
          const jwtSmall = document.createElement('small')
          jwtSmall.textContent = `${i18n.t('options.status.jwt')} ${isJWTValid ? i18n.t('options.status.jwtValid') : i18n.t('options.status.jwtExpired')} (${i18n.t('options.status.until')} ${jwtExpiry.toLocaleString()})`
          licenceP.appendChild(jwtSmall)
          licenceP.appendChild(document.createElement('br'))
        }

        if (licenceData.lastSuccess) {
          const lastCheck = new Date(licenceData.lastSuccess)
          const lastCheckSmall = document.createElement('small')
          lastCheckSmall.textContent = `${i18n.t('options.status.lastVerified')} ${lastCheck.toLocaleString()}`
          licenceP.appendChild(lastCheckSmall)
        }
      } else if (licenceData.status === 'EXPIRED') {
        const expiredBadge = document.createElement('span')
        expiredBadge.className = 'status-badge inactive'
        expiredBadge.textContent = i18n.t('options.status.licenceExpired')
        licenceP.appendChild(expiredBadge)
      } else if (licenceData.status === 'INVALID') {
        const invalidBadge = document.createElement('span')
        invalidBadge.className = 'status-badge inactive'
        invalidBadge.textContent = i18n.t('options.status.invalid')
        licenceP.appendChild(invalidBadge)
      } else if (licenceData.status === 'LIMIT_EXCEEDED') {
        const limitBadge = document.createElement('span')
        limitBadge.className = 'status-badge inactive'
        limitBadge.textContent = i18n.t('options.status.licenceLimitExceeded')
        licenceP.appendChild(limitBadge)
      } else if (licenceData.status === 'SIGNATURE_INVALID') {
        const signatureBadge = document.createElement('span')
        signatureBadge.className = 'status-badge inactive'
        signatureBadge.style.backgroundColor = '#d32f2f'
        signatureBadge.textContent = '⛔ Signature invalide'
        licenceP.appendChild(signatureBadge)
        licenceP.appendChild(document.createElement('br'))

        const errorMessage = document.createElement('small')
        errorMessage.style.color = '#d32f2f'
        errorMessage.style.fontWeight = 'bold'
        errorMessage.textContent = licenceData.signatureError || 'Réponse du serveur non authentifiée'
        licenceP.appendChild(errorMessage)
      } else if (licenceData.status === 'RATE_LIMITED') {
        const rateLimitBadge = document.createElement('span')
        rateLimitBadge.className = 'status-badge inactive'
        rateLimitBadge.style.backgroundColor = '#f59e0b'
        rateLimitBadge.textContent = '⏱️ Trop de requêtes'
        licenceP.appendChild(rateLimitBadge)
        licenceP.appendChild(document.createElement('br'))

        const warningMessage = document.createElement('small')
        warningMessage.style.color = '#f59e0b'
        warningMessage.textContent = 'Veuillez attendre avant de réessayer'
        licenceP.appendChild(warningMessage)
      } else {
        const unknownBadge = document.createElement('span')
        unknownBadge.className = 'status-badge inactive'
        unknownBadge.textContent = i18n.t('options.status.licenceUnknown')
        licenceP.appendChild(unknownBadge)
      }
    } else {
      const notVerifiedBadge = document.createElement('span')
      notVerifiedBadge.className = 'status-badge inactive'
      notVerifiedBadge.textContent = i18n.t('options.status.licenceNotVerified')
      licenceP.appendChild(notVerifiedBadge)
    }
  } else {
    const notConfiguredBadge = document.createElement('span')
    notConfiguredBadge.className = 'status-badge inactive'
    notConfiguredBadge.textContent = 'Not configured'
    licenceP.appendChild(notConfiguredBadge)
  }

  currentStatus.appendChild(licenceP)

  // Auto-refresh status
  const autoRefreshP = document.createElement('p')
  const autoRefreshLabel = document.createElement('strong')
  autoRefreshLabel.textContent = 'Auto-refresh: '
  autoRefreshP.appendChild(autoRefreshLabel)

  const autoRefreshBadge = document.createElement('span')
  if (storage.teampass_auto_refresh !== false) {
    autoRefreshBadge.className = 'status-badge active'
    autoRefreshBadge.textContent = i18n.t('options.status.autoRefreshEnabled')
  } else {
    autoRefreshBadge.className = 'status-badge inactive'
    autoRefreshBadge.textContent = i18n.t('options.status.autoRefreshDisabled')
  }
  autoRefreshP.appendChild(autoRefreshBadge)

  currentStatus.appendChild(autoRefreshP)
  
  // Update debug info
  if (debugInfo) {
    // Parse licence data for debug info
    let licenceDataDebug = null
    try {
      if (storage.teampass_ext_licence) {
        licenceDataDebug = JSON.parse(storage.teampass_ext_licence)
      }
    } catch (error) {
      console.error('Failed to parse licence data for debug:', error)
    }

    // Get telemetry data
    const telemetry = storage.teampass_telemetry || { actionsCount: 0 }

    const debugData = {
      'Server URL': storage.teampass_url || '(not set)',
      'Has credentials': hasCredentials ? 'Yes' : 'No',
      'Has token': hasToken ? 'Yes' : 'No',
      'Token expiry': storage.token_expiry ? new Date(storage.token_expiry).toLocaleString() : '(not set)',
      'Token valid': isTokenValid ? 'Yes' : 'No',
      'Remember me': storage.teampass_remember_me !== false ? 'Yes' : 'No',
      'Auto-refresh': storage.teampass_auto_refresh !== false ? 'Yes' : 'No',
      'Licence status': licenceDataDebug?.status || '(not set)',
      'Licence max users': licenceDataDebug?.maxUsers || '(not set)',
      'Licence expiry': licenceDataDebug?.expirationDate || '(not set)',
      'JWT expires': licenceDataDebug?.jwtExpires ? new Date(licenceDataDebug.jwtExpires * 1000).toLocaleString() : '(not set)',
      'Actions count': telemetry.actionsCount || 0,
      'Current time': new Date().toLocaleString()
    }

    let debugText = ''
    for (const [key, value] of Object.entries(debugData)) {
      debugText += `${key}: ${value}\n`
    }

    debugInfo.textContent = debugText
  }
}

/**
 * Handle form submission
 */
async function handleSave(event) {
  event.preventDefault()

  const serverUrl = serverUrlInput.value.trim()
  const licenceEmail = licenceEmailInput.value.trim()
  const licenceFqdn = licenceFqdnInput.value.trim()
  const licenceToken = licenceTokenInput.value.trim()
  const username = usernameInput.value.trim()
  const password = passwordInput.value
  const apiKey = apiKeyInput.value.trim()
  const rememberMe = rememberMeCheckbox.checked
  const autoRefresh = autoRefreshCheckbox.checked
  const debugLogging = debugLoggingCheckbox.checked

  // Validation
  if (!serverUrl || !licenceEmail || !licenceFqdn || !username || !password || !apiKey) {
    showMessage(i18n.t('options.messages.allFieldsRequired'), 'error')
    return
  }

  // Show global loader
  showLoader('💾 ' + i18n.t('options.messages.savingSettings'))

  try {
    // Encrypt credentials if "Remember me" is checked
    let encryptedCredentials = null
    if (rememberMe) {
      encryptedCredentials = await cryptoHelper.encryptCredentials({
        username,
        password,
        apiKey
      })
    }

    // Check if licence token has changed - if so, invalidate licence cache
    const oldToken = initialFormValues.licenceToken || ''
    const hasTokenChanged = oldToken !== licenceToken

    if (hasTokenChanged) {
      debugLog('[OPTIONS] Licence token changed, invalidating licence cache...')
      // Remove licence cache to force revalidation on next check
      await chrome.storage.local.remove('teampass_ext_licence')
    }

    // Save to storage
    await chrome.storage.local.set({
      teampass_url: serverUrl,
      teampass_licence_email: licenceEmail,
      teampass_licence_fqdn: licenceFqdn,
      teampass_licence_token: licenceToken,
      teampass_credentials_encrypted: encryptedCredentials,
      teampass_remember_me: rememberMe,
      teampass_auto_refresh: autoRefresh,
      debug_logging_enabled: debugLogging
    })

    showMessage(i18n.t('options.messages.settingsSaved'), 'success')

    // Update initial values after successful save
    storeInitialFormValues()
    checkForChanges()

    // Reload status
    setTimeout(async () => {
      const storage = await chrome.storage.local.get([
        'teampass_url',
        'teampass_credentials_encrypted',
        'teampass_remember_me',
        'teampass_auto_refresh',
        'debug_logging_enabled',
        'teampass_token',
        'token_expiry'
      ])
      updateStatus(storage)
    }, 500)
    
  } catch (error) {
    console.error('Save error:', error)
    showMessage(i18n.t('options.messages.saveFailed') + ' ' + error.message, 'error')
  } finally {
    hideLoader()
  }
}

/**
 * Test licence configuration
 */
async function handleTestLicence() {
  debugLog('[OPTIONS] handleTestLicence() called')
  const licenceEmail = licenceEmailInput.value.trim()
  const licenceFqdn = licenceFqdnInput.value.trim()
  const licenceToken = licenceTokenInput.value.trim()

  debugLog('[OPTIONS] Licence email:', licenceEmail)
  debugLog('[OPTIONS] Licence FQDN:', licenceFqdn)
  debugLog('[OPTIONS] Licence token:', licenceToken ? '***' : 'not set')

  if (!licenceEmail || !licenceFqdn || !licenceToken) {
    debugLog('[OPTIONS] Missing email, FQDN, or token')
    showMessage(i18n.t('options.messages.licenceEmailFqdnRequired'), 'error')
    return
  }

  // Show global loader
  showLoader('🔍 ' + i18n.t('options.messages.testingLicence'))

  try {
    debugLog('[OPTIONS] Saving licence data to storage...')
    // Save to storage for the test
    await chrome.storage.local.set({
      teampass_licence_email: licenceEmail,
      teampass_licence_fqdn: licenceFqdn,
      teampass_licence_token: licenceToken
    })

    debugLog('[OPTIONS] Licence data saved, calling testLicence()...')
    // Test licence
    const result = await licenceChecker.testLicence()

    debugLog('[OPTIONS] Test result:', result)

    // Save test result to storage so it appears in Current Status
    if (result.success) {
      const licenceData = {
        instanceFqdn: licenceFqdn,
        status: 'VALID',
        lastSuccess: Date.now(),
        // Save full data from API response if available
        jwt: result.data?.jwt || null,
        jwtExpires: result.data?.jwt_expires || null,
        maxUsers: result.data?.max_users || null,
        expirationDate: result.data?.expiration_date || null
      }
      await chrome.storage.local.set({
        teampass_ext_licence: JSON.stringify(licenceData)
      })

      // IMPORTANT: Unblock extension after successful test
      await licenceChecker.unblockExtension()
      debugLog('[OPTIONS] Extension unblocked after successful licence test')
    } else {
      // Determine status from error message
      let status = 'INVALID'
      if (result.message.includes('expired')) {
        status = 'EXPIRED'
      } else if (result.message.includes('Maximum number')) {
        status = 'LIMIT_EXCEEDED'
      } else if (result.message.includes('Trop de requêtes')) {
        status = 'RATE_LIMITED'
      }
      const licenceData = {
        instanceFqdn: licenceFqdn,
        status: status,
        lastSuccess: null
      }
      await chrome.storage.local.set({
        teampass_ext_licence: JSON.stringify(licenceData)
      })
    }

    // Reload current status to reflect test result
    const storage = await chrome.storage.local.get([
      'teampass_url',
      'teampass_licence_email',
      'teampass_licence_fqdn',
      'teampass_ext_licence',
      'teampass_credentials_encrypted',
      'teampass_token',
      'token_expiry',
      'teampass_auto_refresh',
      'debug_logging_enabled'
    ])
    updateStatus(storage)

  } catch (error) {
    debugLog('[OPTIONS] Test licence error:', error)
    showMessage('❌ ' + i18n.t('options.messages.licenceTestFailed') + ' ' + error.message, 'error')
  } finally {
    hideLoader()
  }
}

/**
 * Test connection to Teampass server
 */
async function handleTestConnection() {
  const serverUrl = serverUrlInput.value.trim()

  if (!serverUrl) {
    showMessage(i18n.t('options.messages.serverUrlRequired'), 'error')
    return
  }

  // Show global loader
  showLoader('🔌 ' + i18n.t('options.messages.testingConnection'))

  try {
    // Send message to service worker to test connection
    const response = await sendMessage('testConnection', { serverUrl })

    // Update status to reflect test result
    const storage = await chrome.storage.local.get([
      'teampass_url',
      'teampass_licence_email',
      'teampass_licence_fqdn',
      'teampass_ext_licence',
      'teampass_credentials_encrypted',
      'teampass_token',
      'token_expiry',
      'teampass_auto_refresh',
      'debug_logging_enabled'
    ])

    // Add test result to storage for display
    storage._test_connection_result = response ? 'success' : 'failed'
    storage._test_connection_time = Date.now()
    updateStatus(storage)

  } catch (error) {
    // Update status with error
    const storage = await chrome.storage.local.get([
      'teampass_url',
      'teampass_licence_email',
      'teampass_licence_fqdn',
      'teampass_ext_licence',
      'teampass_credentials_encrypted',
      'teampass_token',
      'token_expiry',
      'teampass_auto_refresh',
      'debug_logging_enabled'
    ])
    storage._test_connection_result = 'failed'
    storage._test_connection_time = Date.now()
    updateStatus(storage)
  } finally {
    hideLoader()
  }
}

/**
 * Force re-authentication with saved credentials
 */
async function handleForceAuth() {
  try {
    // Get current configuration
    const storage = await chrome.storage.local.get([
      'teampass_url',
      'teampass_credentials_encrypted'
    ])

    if (!storage.teampass_url) {
      showMessage('❌ ' + i18n.t('options.messages.noServerUrl'), 'error')
      return
    }

    if (!storage.teampass_credentials_encrypted) {
      showMessage('❌ ' + i18n.t('options.messages.noCredentialsSaved'), 'error')
      return
    }

    // Hide any previous messages and show global loader
    statusMessage.style.display = 'none'
    showLoader('🔐 ' + i18n.t('options.messages.authenticating'))

    // Decrypt credentials
    const credentials = await cryptoHelper.decryptCredentials(
      storage.teampass_credentials_encrypted
    )

    debugLog('Force auth - Sending authenticate message to service worker')

    // Send authenticate message to service worker
    const response = await sendMessage('authenticate', {
      serverUrl: storage.teampass_url,
      username: credentials.username,
      password: credentials.password,
      apiKey: credentials.apiKey
    })

    debugLog('Force auth - Response received:', response)

    // Check if authenticated - response should have userId, username, or permissions
    if (response && (response.userId || response.username || response.permissions)) {
      debugLog('Force auth - Authentication successful, waiting for token to be saved...')

      // Wait a bit for storage to be updated
      await new Promise(resolve => setTimeout(resolve, CONFIG.REAUTH_WAIT_DELAY))

      // Verify token is saved
      let attempts = 0
      let authenticated = false

      while (attempts < 5 && !authenticated) {
        const newStorage = await chrome.storage.local.get([
          'teampass_token',
          'token_expiry'
        ])

        if (newStorage.teampass_token && newStorage.token_expiry &&
            Date.now() < newStorage.token_expiry) {
          authenticated = true
          debugLog('Force auth - Token verified in storage')
        } else {
          debugLog(`Force auth - Waiting for token (attempt ${attempts + 1}/5)`)
          await new Promise(resolve => setTimeout(resolve, CONFIG.REAUTH_WAIT_DELAY))
          attempts++
        }
      }

      // Hide loader
      hideLoader()

      if (authenticated) {
        // Refresh status after successful authentication (no message needed, status shows below)
        const finalStorage = await chrome.storage.local.get([
          'teampass_url',
          'teampass_credentials_encrypted',
          'teampass_token',
          'token_expiry',
          'teampass_auto_refresh'
        ])
        updateStatus(finalStorage)
      } else {
        showMessage('⚠️ ' + i18n.t('options.messages.authTimedOut'), 'warning')
      }

    } else {
      // Hide loader
      hideLoader()
      console.error('Force auth - Authentication failed:', response)
      showMessage('❌ ' + i18n.t('options.messages.authFailed'), 'error')
    }

  } catch (error) {
    // Hide loader
    hideLoader()
    console.error('Force auth error:', error)
    showMessage('❌ ' + i18n.t('options.messages.authFailedPrefix') + ' ' + error.message, 'error')
  } finally {
    hideLoader()
  }
}

/**
 * Extract email from JWT token
 * @param {string} token - JWT token string
 * @returns {string|null} Email from JWT payload or null
 */
function getEmailFromJWT(token) {
  try {
    // JWT format: header.payload.signature
    const parts = token.split('.')
    if (parts.length !== 3) {
      return null
    }

    // Decode base64url payload (second part)
    const payload = parts[1]
    // Replace base64url chars with base64 chars
    const base64 = payload.replace(/-/g, '+').replace(/_/g, '/')
    // Pad with '=' if needed
    const padded = base64.padEnd(base64.length + (4 - base64.length % 4) % 4, '=')

    // Decode and parse JSON
    const decoded = atob(padded)
    const data = JSON.parse(decoded)

    return data.email || null
  } catch (error) {
    console.error('Error extracting email from JWT:', error)
    return null
  }
}

/**
 * Authenticate and auto-fill licence fields from server
 * Tests authentication with current form values, then fetches licence data
 */
async function handleAuthAndAutoFill() {
  try {
    // Get current form values
    const serverUrl = serverUrlInput.value.trim()
    const username = usernameInput.value.trim()
    const password = passwordInput.value
    const apiKey = apiKeyInput.value.trim()

    // Validation
    if (!serverUrl || !username || !password || !apiKey) {
      showMessage('❌ ' + i18n.t('options.messages.allFieldsRequiredAuth'), 'error')
      return
    }

    // Hide any previous messages and show global loader
    statusMessage.style.display = 'none'
    showLoader('🔐 ' + i18n.t('options.messages.authenticating'))

    debugLog('[AUTH_AUTOFILL] Sending authenticate message to service worker')

    // Send authenticate message to service worker
    const response = await sendMessage('authenticate', {
      serverUrl: serverUrl,
      username: username,
      password: password,
      apiKey: apiKey
    })

    debugLog('[AUTH_AUTOFILL] Response received:', response)

    // Check if authenticated
    if (response && (response.userId || response.username || response.permissions)) {
      debugLog('[AUTH_AUTOFILL] Authentication successful, waiting for token...')

      // Wait for token to be saved
      await new Promise(resolve => setTimeout(resolve, CONFIG.REAUTH_WAIT_DELAY))

      // Get JWT from storage
      let attempts = 0
      let jwt = null

      while (attempts < 5 && !jwt) {
        const storage = await chrome.storage.local.get(['teampass_token', 'token_expiry'])

        if (storage.teampass_token && storage.token_expiry && Date.now() < storage.token_expiry) {
          jwt = storage.teampass_token
          debugLog('[AUTH_AUTOFILL] JWT retrieved from storage')
        } else {
          debugLog(`[AUTH_AUTOFILL] Waiting for JWT (attempt ${attempts + 1}/5)`)
          await new Promise(resolve => setTimeout(resolve, CONFIG.REAUTH_WAIT_DELAY))
          attempts++
        }
      }

      if (!jwt) {
        hideLoader()
        showMessage('⚠️ ' + i18n.t('options.messages.authSuccessJwtNotFound'), 'warning')
        return
      }

      // Call refreshExtensionSettings with JWT
      showLoader('📡 ' + i18n.t('options.messages.fetchingLicence'))
      debugLog('[AUTH_AUTOFILL] Calling refreshExtensionSettings with JWT')

      const extensionSettings = await refreshExtensionSettingsWithUrl(serverUrl, jwt)

      if (extensionSettings) {
        debugLog('[AUTH_AUTOFILL] Settings received:', extensionSettings)

        // Update Server URL if not empty
        if (extensionSettings.extension_url && extensionSettings.extension_url.trim() !== '') {
          serverUrlInput.value = extensionSettings.extension_url
        }

        // Update Licence Email - Priority: JWT email > API email > username
        const jwtEmail = getEmailFromJWT(jwt)
        if (jwtEmail && jwtEmail.trim() !== '') {
          licenceEmailInput.value = jwtEmail
          debugLog('[AUTH_AUTOFILL] Using email from JWT:', jwtEmail)
        } else if (extensionSettings.extension_email && extensionSettings.extension_email.trim() !== '') {
          licenceEmailInput.value = extensionSettings.extension_email
          debugLog('[AUTH_AUTOFILL] Using email from API:', extensionSettings.extension_email)
        } else if (response.username) {
          // Use authenticated username as fallback if no email available
          licenceEmailInput.value = response.username
          debugLog('[AUTH_AUTOFILL] Using username as fallback:', response.username)
        }

        // Update FQDN if not empty
        if (extensionSettings.extension_fqdn && extensionSettings.extension_fqdn.trim() !== '') {
          licenceFqdnInput.value = extensionSettings.extension_fqdn
        }

        // Update Token if not empty
        if (extensionSettings.extension_key && extensionSettings.extension_key.trim() !== '') {
          licenceTokenInput.value = extensionSettings.extension_key
        }

        hideLoader()
        showMessage('✅ ' + i18n.t('options.messages.authSuccessLicenceAutoFilled'), 'success')
        // Check for changes after auto-fill
        checkForChanges()
      } else {
        hideLoader()
        showMessage('⚠️ ' + i18n.t('options.messages.authSuccessLicenceFailed'), 'warning')
      }

    } else {
      hideLoader()
      console.error('[AUTH_AUTOFILL] Authentication failed:', response)
      showMessage('❌ ' + i18n.t('options.messages.authFailed'), 'error')
    }

  } catch (error) {
    hideLoader()
    console.error('[AUTH_AUTOFILL] Error:', error)
    showMessage('❌ ' + i18n.t('options.messages.errorPrefix') + ' ' + error.message, 'error')
  }
}

/**
 * Clear all saved data
 */
async function handleClearAll() {
  if (!confirm(i18n.t('options.dangerZone.confirmMessage'))) {
    return
  }
  
  clearAllBtn.disabled = true
  
  try {
    // Clear crypto keys
    await cryptoHelper.clearKeys()
    
    // Clear all storage
    await chrome.storage.local.clear()
    
    // Reset form
    form.reset()
    rememberMeCheckbox.checked = true
    autoRefreshCheckbox.checked = true

    showMessage(i18n.t('options.messages.allDataCleared'), 'success')

    // Update status
    updateStatus({})

  } catch (error) {
    console.error('Clear error:', error)
    showMessage(i18n.t('options.messages.clearFailed') + ' ' + error.message, 'error')
  } finally {
    clearAllBtn.disabled = false
  }
}

/**
 * Toggle password visibility
 */
function handleTogglePassword() {
  const type = passwordInput.type === 'password' ? 'text' : 'password'
  passwordInput.type = type
  togglePasswordBtn.textContent = type === 'password' ? '👁️' : '🙈'
}

/**
 * Show status message
 */
function showMessage(message, type = 'info') {
  statusMessage.textContent = message
  statusMessage.className = `message ${type}`
  statusMessage.style.display = 'block'
  
  // Set colors based on type
  if (type === 'success') {
    statusMessage.style.backgroundColor = '#d4edda'
    statusMessage.style.color = '#155724'
    statusMessage.style.borderColor = '#c3e6cb'
  } else if (type === 'error') {
    statusMessage.style.backgroundColor = '#f8d7da'
    statusMessage.style.color = '#721c24'
    statusMessage.style.borderColor = '#f5c6cb'
  } else if (type === 'warning') {
    statusMessage.style.backgroundColor = '#fff3cd'
    statusMessage.style.color = '#856404'
    statusMessage.style.borderColor = '#ffeeba'
  } else {
    statusMessage.style.backgroundColor = '#d1ecf1'
    statusMessage.style.color = '#0c5460'
    statusMessage.style.borderColor = '#bee5eb'
  }
  
  // Auto-hide after 5 seconds for success messages
  if (type === 'success') {
    setTimeout(() => {
      statusMessage.style.display = 'none'
    }, 5000)
  }
}

/**
 * Wake up service worker (Firefox compatibility)
 * Sends a dummy message to ensure the service worker is loaded
 */
async function wakeUpServiceWorker() {
  try {
    // Try to get auth state - this will wake up the service worker
    await chrome.runtime.sendMessage({ action: 'getAuthState' })
  } catch (error) {
    // Ignore errors, we just want to wake up the worker
    debugLog('Wake up service worker attempt:', error.message)
  }
}

/**
 * Send message to service worker with retry logic and timeout
 * Includes timeout to prevent infinite waiting if service worker doesn't respond
 */
function sendMessage(action, data = {}, retryCount = 0) {
  return new Promise((resolve, reject) => {
    debugLog(`sendMessage: Sending ${action} (attempt ${retryCount + 1})`, data)

    let timeoutTriggered = false

    // Set a timeout to reject the promise if no response is received
    const timeoutId = setTimeout(() => {
      timeoutTriggered = true
      console.error(`sendMessage: Timeout for ${action} after ${CONFIG.MESSAGE_TIMEOUT}ms`)

      // Retry on timeout (Chrome may have terminated service worker)
      if (retryCount < 3) {
        debugLog(`sendMessage: Retrying ${action} after timeout...`)
        wakeUpServiceWorker().then(() => {
          setTimeout(() => {
            sendMessage(action, data, retryCount + 1)
              .then(resolve)
              .catch(reject)
          }, 100 * (retryCount + 1))
        })
      } else {
        reject(new Error(i18n.t('options.messages.serviceWorkerTimeout', { count: retryCount + 1 })))
      }
    }, CONFIG.MESSAGE_TIMEOUT)

    chrome.runtime.sendMessage(
      { action, data },
      response => {
        // Ignore response if timeout already triggered
        if (timeoutTriggered) {
          debugLog(`sendMessage: Ignoring late response for ${action}`)
          return
        }

        // Clear timeout since we got a response
        clearTimeout(timeoutId)

        debugLog(`sendMessage: Response for ${action}`, response)

        if (chrome.runtime.lastError) {
          const errorMsg = chrome.runtime.lastError.message
          console.error(`sendMessage: Chrome error for ${action}:`, errorMsg)

          // Retry on connection errors (service worker not ready)
          if (errorMsg.includes('Receiving end does not exist') && retryCount < 3) {
            debugLog(`sendMessage: Retrying ${action} after service worker connection error...`)
            // Wake up service worker before retry
            wakeUpServiceWorker().then(() => {
              setTimeout(() => {
                sendMessage(action, data, retryCount + 1)
                  .then(resolve)
                  .catch(reject)
              }, 100 * (retryCount + 1)) // Exponential backoff: 100ms, 200ms, 300ms
            })
          } else {
            reject(new Error(errorMsg))
          }
        } else if (!response) {
          console.error(`sendMessage: No response for ${action}`)
          reject(new Error('No response from service worker'))
        } else if (response.success || response.isAuthenticated !== undefined) {
          // Accept response if success=true OR if isAuthenticated is present
          debugLog(`sendMessage: Success for ${action}, resolving with:`, response.data || response)
          resolve(response.data || response)
        } else {
          console.error(`sendMessage: Error for ${action}:`, response.error)
          reject(new Error(response.error || 'Unknown error'))
        }
      }
    )
  })
}