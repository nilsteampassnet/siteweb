/**
 * Extension Name: Teampass Manager Extension
 * Copyright (c) 2026, LogCarré. All Rights Reserved.
 *
 * This code is proprietary software. It is distributed on a non-public,
 * limited-use basis under the terms of a Commercial License.
 *
 * Unauthorized copying, modification, redistribution, or reverse engineering
 * of this code, or any part thereof, is strictly prohibited.
 */

/**
 * Teampass Password Generator Injector
 *
 * Injects password generator buttons into signup/registration forms
 * Allows users to generate secure passwords directly on web pages
 */

// State management
const passwordGeneratorState = {
  markers: [],
  activeModal: null,
  observerInitialized: false
}

/**
 * Create SVG icon for password generator
 *
 * @param {string} type - Icon type: 'key', 'copy', 'sync', 'check'
 * @returns {SVGElement} SVG icon element
 */
function createPasswordGenIcon(type) {
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg')
  svg.setAttribute('viewBox', '0 0 24 24')
  svg.setAttribute('fill', 'currentColor')
  svg.style.width = '1em'
  svg.style.height = '1em'
  svg.style.display = 'inline-block'
  svg.style.verticalAlign = 'middle'

  switch (type) {
    case 'key':
      // Key icon (FontAwesome fa-key equivalent)
      svg.innerHTML = '<path d="M12.65 10A5.99 5.99 0 0 0 7 6c-3.31 0-6 2.69-6 6s2.69 6 6 6a5.99 5.99 0 0 0 5.65-4H17v4h4v-4h2v-4H12.65zM7 14c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2z"/>'
      break
    case 'copy':
      // Copy icon (FontAwesome fa-copy equivalent)
      svg.innerHTML = '<path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/>'
      break
    case 'sync':
      // Sync/refresh icon (FontAwesome fa-sync-alt equivalent)
      svg.innerHTML = '<path d="M12 4V1L8 5l4 4V6c3.31 0 6 2.69 6 6 0 1.01-.25 1.97-.7 2.8l1.46 1.46C19.54 15.03 20 13.57 20 12c0-4.42-3.58-8-8-8zm0 14c-3.31 0-6-2.69-6-6 0-1.01.25-1.97.7-2.8L5.24 7.74C4.46 8.97 4 10.43 4 12c0 4.42 3.58 8 8 8v3l4-4-4-4v3z"/>'
      break
    case 'check':
      // Check/checkmark icon (FontAwesome fa-check equivalent)
      svg.innerHTML = '<path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>'
      break
    default:
      svg.innerHTML = '<circle cx="12" cy="12" r="10"/>'
  }

  return svg
}

/**
 * Detect if a field is a honeypot (fake field for bot detection)
 *
 * @param {HTMLInputElement} field - Field to check
 * @returns {boolean} True if field is a honeypot
 */
function isHoneypotField(field) {
  if (!field) return false

  // Check for explicit honeypot indicators in placeholder/label
  const placeholder = (field.placeholder || '').toLowerCase()
  const name = (field.name || '').toLowerCase()
  const id = (field.id || '').toLowerCase()
  const className = (field.className || '').toLowerCase()

  // Honeypot patterns: "leave blank", "do not fill", "bot check", etc.
  const honeypotTextPatterns = /leave.*blank|do.*not.*fill|bot.*check|spam.*check|honeypot/i

  if (honeypotTextPatterns.test(placeholder) ||
      honeypotTextPatterns.test(name) ||
      honeypotTextPatterns.test(id)) {
    debugLog('Honeypot detected (text pattern):', { name, id, placeholder })
    return true
  }

  // Check for "hidden" in class name (common honeypot pattern)
  // Use word boundaries to avoid false positives like "passwordHideShow"
  if (/\b(hidden|hide|invisible|d-none|visually-hidden)\b/i.test(className)) {
    debugLog('Honeypot detected (hidden class):', className)
    return true
  }

  // Check label text
  const label = field.labels?.[0] || document.querySelector(`label[for="${field.id}"]`)
  if (label) {
    const labelText = label.textContent.toLowerCase()
    if (honeypotTextPatterns.test(labelText)) {
      debugLog('Honeypot detected (label):', labelText)
      return true
    }
  }

  // Check for visually hidden fields (position: absolute; left: -9999px, etc.)
  const style = window.getComputedStyle(field)
  const left = parseInt(style.left)
  const top = parseInt(style.top)

  if (style.position === 'absolute' && (left < -1000 || top < -1000)) {
    debugLog('Honeypot detected (positioned off-screen):', { left, top })
    return true
  }

  // Check for tab index -1 (often used for honeypots)
  if (field.tabIndex === -1) {
    debugLog('Honeypot detected (tabindex -1)')
    return true
  }

  return false
}

/**
 * Detect if a password field is likely a new password field (signup/registration)
 *
 * @param {HTMLInputElement} field - Password field to check
 * @returns {boolean} True if field is for new password
 */
function isNewPasswordField(field) {
  if (!field || field.type !== 'password') return false

  // Exclude honeypot fields immediately
  if (isHoneypotField(field)) {
    debugLog('Password field excluded (honeypot):', field.name || field.id)
    return false
  }

  const name = (field.name || '').toLowerCase()
  const id = (field.id || '').toLowerCase()
  const placeholder = (field.placeholder || '').toLowerCase()
  const className = (field.className || '').toLowerCase()

  // ✅ Exclude login/signin fields explicitly
  // These patterns indicate a LOGIN form, not a SIGNUP form
  const loginPatterns = /\blogin\b|sign-?in|log-?in|connexion/i

  if (loginPatterns.test(name) ||
      loginPatterns.test(id) ||
      loginPatterns.test(className)) {
    debugLog('Password field excluded (login field):', field.name || field.id)
    return false
  }

  // Check autocomplete attribute
  const autocomplete = (field.autocomplete || '').toLowerCase()
  if (autocomplete.includes('new-password')) return true

  // Check name/id for signup patterns
  const newPasswordPatterns = /new.*password|password.*new|signup|sign-?up|register|create.*password|password.*create|set.*password/i

  if (newPasswordPatterns.test(name) ||
      newPasswordPatterns.test(id) ||
      newPasswordPatterns.test(placeholder)) {
    return true
  }

  // Check if the field is in a signup/register form
  const form = field.closest('form')
  if (form) {
    const formAction = (form.action || '').toLowerCase()
    const formClass = (form.className || '').toLowerCase()
    const formId = (form.id || '').toLowerCase()

    // ✅ Also check data-* attributes (data-testid, data-form-type, etc.)
    const dataAttrs = Array.from(form.attributes)
      .filter(attr => attr.name.startsWith('data-'))
      .map(attr => `${attr.name}=${attr.value}`)
      .join(' ')
      .toLowerCase()

    // Check for signup patterns FIRST (higher priority)
    const signupFormPatterns = /signup|sign-?up|register|create.*account|join/i

    if (signupFormPatterns.test(formAction) ||
        signupFormPatterns.test(formClass) ||
        signupFormPatterns.test(formId) ||
        signupFormPatterns.test(dataAttrs)) {
      return true
    }

    // Then exclude if form is explicitly a login form
    if (loginPatterns.test(formAction) ||
        loginPatterns.test(formClass) ||
        loginPatterns.test(formId) ||
        loginPatterns.test(dataAttrs)) {
      debugLog('Password field excluded (login form):', field.name || field.id)
      return false
    }
  }

  // Check nearby labels
  const label = field.labels?.[0] || document.querySelector(`label[for="${field.id}"]`)
  if (label) {
    const labelText = label.textContent.toLowerCase()
    if (newPasswordPatterns.test(labelText)) {
      return true
    }
  }

  return false
}

/**
 * Detect if a password field is a confirmation field
 *
 * @param {HTMLInputElement} field - Password field to check
 * @returns {boolean} True if field is a confirmation field
 */
function isPasswordConfirmationField(field) {
  if (!field || field.type !== 'password') return false

  const name = (field.name || '').toLowerCase()
  const id = (field.id || '').toLowerCase()
  const placeholder = (field.placeholder || '').toLowerCase()

  const confirmPatterns = /confirm|confirmation|verify|repeat|again|retype/i

  if (confirmPatterns.test(name) ||
      confirmPatterns.test(id) ||
      confirmPatterns.test(placeholder)) {
    return true
  }

  // Check nearby labels
  const label = field.labels?.[0] || document.querySelector(`label[for="${field.id}"]`)
  if (label) {
    const labelText = label.textContent.toLowerCase()
    if (confirmPatterns.test(labelText)) {
      return true
    }
  }

  return false
}

/**
 * Find the password confirmation field for a given password field
 *
 * @param {HTMLInputElement} passwordField - The main password field
 * @returns {HTMLInputElement|null} Confirmation field or null
 */
function findPasswordConfirmationFieldFor(passwordField) {
  if (!passwordField) return null

  // Get all password fields in the same form or nearby
  const form = passwordField.closest('form')
  const searchContext = form || passwordField.parentElement

  const allPasswordFields = searchContext.querySelectorAll('input[type="password"]')

  // Find the first field after the main password field that looks like a confirmation
  let foundMainField = false
  for (const field of allPasswordFields) {
    if (field === passwordField) {
      foundMainField = true
      continue
    }

    // If we found the main field, check if this is a confirmation field
    if (foundMainField && isPasswordConfirmationField(field) && isVisible(field)) {
      return field
    }
  }

  // If no confirmation field found with confirm patterns, try the next password field
  foundMainField = false
  for (const field of allPasswordFields) {
    if (field === passwordField) {
      foundMainField = true
      continue
    }

    // Return the next visible password field after the main one
    if (foundMainField && isVisible(field)) {
      return field
    }
  }

  return null
}

/**
 * Find all new password fields on the page (excluding confirmation fields)
 * Returns ALL new password fields regardless of visibility
 * Visibility is handled separately in updatePasswordMarkerPositions()
 *
 * @returns {HTMLInputElement[]} Array of new password fields (only first field if multiple)
 */
function findNewPasswordFields() {
  const allPasswordFields = document.querySelectorAll('input[type="password"]')
  const newPasswordFields = []

  debugLog(`Found ${allPasswordFields.length} total password fields`)

  for (const field of allPasswordFields) {
    const visible = isVisible(field)
    const isNew = isNewPasswordField(field)
    const isConfirm = isPasswordConfirmationField(field)

    debugLog('Password field check:', {
      name: field.name,
      id: field.id,
      visible: visible,
      isNew: isNew,
      isConfirm: isConfirm,
      accepted: isNew && !isConfirm  // ✅ No longer require visibility
    })

    // ✅ Accept all new password fields, even if hidden in tabs
    // Visibility will be handled by updatePasswordMarkerPositions()
    if (isNew && !isConfirm) {
      newPasswordFields.push(field)
    }
  }

  // If multiple password fields found in same form/context, keep only the first one
  // This handles cases where there are two "new password" fields (original + confirm)
  const uniqueFields = []
  const processedForms = new Set()

  for (const field of newPasswordFields) {
    const form = field.closest('form')
    const formKey = form ? form : field.parentElement

    // If we haven't processed this form yet, add the first field
    if (!processedForms.has(formKey)) {
      uniqueFields.push(field)
      processedForms.add(formKey)
    }
  }

  debugLog(`After deduplication: ${uniqueFields.length} unique password fields`)

  return uniqueFields
}

/**
 * Create password generator button/marker
 *
 * @param {HTMLInputElement} field - Password field to attach marker to
 * @returns {HTMLElement} Marker element
 */
function createPasswordGeneratorMarker(field) {
  const marker = document.createElement('div')
  marker.className = 'teampass-password-gen-marker'
  marker.setAttribute('data-teampass-pwgen', 'true')
  marker.setAttribute('title', i18n.t('content.passwordGenerator.generateSecurePassword'))

  // Add SVG icon instead of FontAwesome
  const icon = createPasswordGenIcon('key')
  icon.style.width = '14px'
  icon.style.height = '14px'
  icon.style.fill = 'white'
  marker.appendChild(icon)

  // Position marker next to field
  positionPasswordMarker(marker, field)

  // Add click handler
  marker.addEventListener('click', (e) => {
    e.preventDefault()
    e.stopPropagation()
    showPasswordGeneratorModal(field)
  })

  return marker
}

/**
 * Position marker next to password field (on the right side)
 *
 * @param {HTMLElement} marker - Marker element
 * @param {HTMLInputElement} field - Password field
 */
function positionPasswordMarker(marker, field) {
  const rect = field.getBoundingClientRect()
  const scrollTop = window.pageYOffset || document.documentElement.scrollTop
  const scrollLeft = window.pageXOffset || document.documentElement.scrollLeft

  marker.style.position = 'absolute'
  marker.style.top = `${rect.top + scrollTop + (rect.height - 24) / 2}px`
  // Position inside the field, aligned to the right (marker width = 24px, margin = 5px)
  marker.style.left = `${rect.right + scrollLeft - 29}px`
  marker.style.zIndex = '999998'
}

/**
 * Update marker positions when page scrolls or resizes
 */
function updatePasswordMarkerPositions() {
  passwordGeneratorState.markers.forEach(({ marker, field }) => {
    if (isVisible(field)) {
      positionPasswordMarker(marker, field)
      marker.style.display = 'flex'
    } else {
      marker.style.display = 'none'
    }
  })
}

/**
 * Generate a random secure password
 *
 * @param {number} length - Password length
 * @param {object} options - Generation options
 * @returns {string} Generated password
 */
function generateSecurePassword(length = 16, options = {}) {
  const defaults = {
    lowercase: true,
    uppercase: true,
    numbers: true,
    symbols: true
  }

  const opts = { ...defaults, ...options }

  const lowercase = 'abcdefghijklmnopqrstuvwxyz'
  const uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
  const numbers = '0123456789'
  const symbols = '!@#$%^&*()_+-=[]{}|;:,.<>?'

  let chars = ''
  let password = ''

  // Build character set
  if (opts.lowercase) chars += lowercase
  if (opts.uppercase) chars += uppercase
  if (opts.numbers) chars += numbers
  if (opts.symbols) chars += symbols

  if (chars.length === 0) {
    chars = lowercase + uppercase + numbers // Fallback
  }

  // Generate password ensuring at least one char from each enabled category
  const categories = []
  if (opts.lowercase) categories.push(lowercase)
  if (opts.uppercase) categories.push(uppercase)
  if (opts.numbers) categories.push(numbers)
  if (opts.symbols) categories.push(symbols)

  // Add one character from each category
  for (const category of categories) {
    const randomIndex = Math.floor(Math.random() * category.length)
    password += category[randomIndex]
  }

  // Fill the rest with random characters
  for (let i = password.length; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * chars.length)
    password += chars[randomIndex]
  }

  // Shuffle the password
  password = password.split('').sort(() => Math.random() - 0.5).join('')

  return password
}

/**
 * Show password generator modal
 *
 * @param {HTMLInputElement} targetField - Target password field
 */
async function showPasswordGeneratorModal(targetField) {
  // Close any existing modal
  if (passwordGeneratorState.activeModal) {
    passwordGeneratorState.activeModal.remove()
    passwordGeneratorState.activeModal = null
  }

  // Load saved password preferences (length + character types)
  const savedPreferences = await new Promise((resolve) => {
    chrome.storage.local.get([
      'passwordGeneratorLength',
      'passwordGeneratorLowercase',
      'passwordGeneratorUppercase',
      'passwordGeneratorNumbers',
      'passwordGeneratorSymbols'
    ], (result) => {
      resolve({
        length: result.passwordGeneratorLength || 16,
        lowercase: result.passwordGeneratorLowercase ?? true,
        uppercase: result.passwordGeneratorUppercase ?? true,
        numbers: result.passwordGeneratorNumbers ?? true,
        symbols: result.passwordGeneratorSymbols ?? true
      })
    })
  })

  const savedLength = savedPreferences.length

  // Create modal
  const modal = document.createElement('div')
  modal.className = 'teampass-pwgen-modal'

  // Create static HTML structure
  modal.innerHTML = `
    <div class="teampass-pwgen-modal-content">
      <div class="teampass-pwgen-header">
        <div class="teampass-pwgen-title-wrapper">
          <i class="fas fa-key teampass-pwgen-icon"></i>
          <span class="teampass-pwgen-title" id="pwgen-title"></span>
        </div>
        <button class="teampass-pwgen-close">✕</button>
      </div>

      <div class="teampass-pwgen-body">
        <!-- Generated Password Display -->
        <div class="teampass-pwgen-result">
          <input type="text" class="teampass-pwgen-output" readonly id="pwgen-output">
          <button class="teampass-pwgen-copy-btn" id="pwgen-copy-btn" disabled>
            <i class="fas fa-copy"></i>
          </button>
        </div>

        <!-- Length Selector -->
        <div class="teampass-pwgen-option-group">
          <label class="teampass-pwgen-option-label"><span id="pwgen-length-label"></span> <span class="teampass-pwgen-length-value" id="pwgen-length-value"></span></label>
          <input type="range" class="teampass-pwgen-length-slider" min="8" max="64" step="1" id="pwgen-length-slider">
        </div>

        <!-- Character Options -->
        <div class="teampass-pwgen-option-group">
          <label class="teampass-pwgen-option-label" id="pwgen-char-types"></label>
          <div class="teampass-pwgen-checkboxes">
            <label class="teampass-pwgen-checkbox">
              <input type="checkbox" id="teampass-pwgen-lowercase" checked>
              <span id="pwgen-lowercase-label"></span>
            </label>
            <label class="teampass-pwgen-checkbox">
              <input type="checkbox" id="teampass-pwgen-uppercase" checked>
              <span id="pwgen-uppercase-label"></span>
            </label>
            <label class="teampass-pwgen-checkbox">
              <input type="checkbox" id="teampass-pwgen-numbers" checked>
              <span id="pwgen-numbers-label"></span>
            </label>
            <label class="teampass-pwgen-checkbox">
              <input type="checkbox" id="teampass-pwgen-symbols" checked>
              <span id="pwgen-symbols-label"></span>
            </label>
          </div>
        </div>

        <!-- Actions -->
        <div class="teampass-pwgen-actions">
          <button class="teampass-pwgen-btn teampass-pwgen-btn-secondary teampass-pwgen-generate-btn">
            <i class="fas fa-sync-alt"></i> <span id="pwgen-generate-btn"></span>
          </button>
          <button class="teampass-pwgen-btn teampass-pwgen-btn-primary teampass-pwgen-use-btn" disabled>
            <i class="fas fa-check"></i> <span id="pwgen-use-btn"></span>
          </button>
        </div>
      </div>
    </div>
  `

  // Inject i18n values safely using textContent
  modal.querySelector('#pwgen-title').textContent = i18n.t('content.passwordGenerator.generatePassword')
  modal.querySelector('#pwgen-output').value = i18n.t('content.passwordGenerator.outputPlaceholder')
  modal.querySelector('#pwgen-copy-btn').title = i18n.t('content.passwordGenerator.copyToClipboard')
  modal.querySelector('#pwgen-length-label').textContent = i18n.t('content.passwordGenerator.lengthLabel')
  modal.querySelector('#pwgen-length-value').textContent = savedLength
  modal.querySelector('#pwgen-length-slider').value = savedLength
  modal.querySelector('#pwgen-char-types').textContent = i18n.t('content.passwordGenerator.characterTypes')
  modal.querySelector('#pwgen-lowercase-label').textContent = i18n.t('content.passwordGenerator.lowercase')
  modal.querySelector('#pwgen-uppercase-label').textContent = i18n.t('content.passwordGenerator.uppercase')
  modal.querySelector('#pwgen-numbers-label').textContent = i18n.t('content.passwordGenerator.numbers')
  modal.querySelector('#pwgen-symbols-label').textContent = i18n.t('content.passwordGenerator.symbols')
  modal.querySelector('#pwgen-generate-btn').textContent = i18n.t('content.passwordGenerator.generateButton')
  modal.querySelector('#pwgen-use-btn').textContent = i18n.t('content.passwordGenerator.usePasswordButton')

  // Apply saved checkbox preferences
  modal.querySelector('#teampass-pwgen-lowercase').checked = savedPreferences.lowercase
  modal.querySelector('#teampass-pwgen-uppercase').checked = savedPreferences.uppercase
  modal.querySelector('#teampass-pwgen-numbers').checked = savedPreferences.numbers
  modal.querySelector('#teampass-pwgen-symbols').checked = savedPreferences.symbols

  document.body.appendChild(modal)
  passwordGeneratorState.activeModal = modal

  // Replace FontAwesome icons with SVG
  const headerIcon = modal.querySelector('.teampass-pwgen-icon')
  if (headerIcon) {
    const keyIcon = createPasswordGenIcon('key')
    keyIcon.className = 'teampass-pwgen-icon'
    headerIcon.replaceWith(keyIcon)
  }

  const copyIcon = modal.querySelector('.teampass-pwgen-copy-btn i')
  if (copyIcon) {
    const svgCopy = createPasswordGenIcon('copy')
    copyIcon.replaceWith(svgCopy)
  }

  const generateIcon = modal.querySelector('.teampass-pwgen-generate-btn i')
  if (generateIcon) {
    const svgSync = createPasswordGenIcon('sync')
    svgSync.style.marginRight = '4px'
    generateIcon.replaceWith(svgSync)
  }

  const useIcon = modal.querySelector('.teampass-pwgen-use-btn i')
  if (useIcon) {
    const svgCheck = createPasswordGenIcon('check')
    svgCheck.style.marginRight = '4px'
    useIcon.replaceWith(svgCheck)
  }

  // Setup event listeners and auto-generate password
  setupModalEventListeners(modal, targetField, savedPreferences)

  // Show modal with animation
  setTimeout(() => modal.classList.add('show'), 10)

  // Close modal when clicking outside
  const closeHandler = (e) => {
    if (e.target === modal) {
      closeModal(modal)
      document.removeEventListener('click', closeHandler)
    }
  }
  setTimeout(() => document.addEventListener('click', closeHandler), 100)
}

/**
 * Setup event listeners for the modal
 *
 * @param {HTMLElement} modal - Modal element
 * @param {HTMLInputElement} targetField - Target password field
 * @param {object} savedPreferences - Saved preferences for password generation
 */
function setupModalEventListeners(modal, targetField, savedPreferences) {
  const closeBtn = modal.querySelector('.teampass-pwgen-close')
  const generateBtn = modal.querySelector('.teampass-pwgen-generate-btn')
  const useBtn = modal.querySelector('.teampass-pwgen-use-btn')
  const copyBtn = modal.querySelector('.teampass-pwgen-copy-btn')
  const lengthSlider = modal.querySelector('.teampass-pwgen-length-slider')
  const lengthValue = modal.querySelector('.teampass-pwgen-length-value')
  const outputField = modal.querySelector('.teampass-pwgen-output')
  const lowercaseCheck = modal.querySelector('#teampass-pwgen-lowercase')
  const uppercaseCheck = modal.querySelector('#teampass-pwgen-uppercase')
  const numbersCheck = modal.querySelector('#teampass-pwgen-numbers')
  const symbolsCheck = modal.querySelector('#teampass-pwgen-symbols')

  // Close button
  closeBtn.addEventListener('click', () => closeModal(modal))

  // Length slider
  lengthSlider.addEventListener('input', (e) => {
    const newLength = parseInt(e.target.value)
    lengthValue.textContent = newLength

    // Save the new length preference
    chrome.storage.local.set({ passwordGeneratorLength: newLength }, () => {
      debugLog('Password generator length saved:', newLength)
    })
  })

  // Checkbox change handlers - save preferences
  const checkboxHandler = (checkbox, storageKey) => {
    if (checkbox) {
      checkbox.addEventListener('change', (e) => {
        chrome.storage.local.set({ [storageKey]: e.target.checked }, () => {
          debugLog(`Password generator ${storageKey} saved:`, e.target.checked)
        })
      })
    }
  }

  checkboxHandler(lowercaseCheck, 'passwordGeneratorLowercase')
  checkboxHandler(uppercaseCheck, 'passwordGeneratorUppercase')
  checkboxHandler(numbersCheck, 'passwordGeneratorNumbers')
  checkboxHandler(symbolsCheck, 'passwordGeneratorSymbols')

  // Generate button
  generateBtn.addEventListener('click', () => {
    const length = parseInt(lengthSlider.value)
    const options = {
      lowercase: modal.querySelector('#teampass-pwgen-lowercase').checked,
      uppercase: modal.querySelector('#teampass-pwgen-uppercase').checked,
      numbers: modal.querySelector('#teampass-pwgen-numbers').checked,
      symbols: modal.querySelector('#teampass-pwgen-symbols').checked
    }

    const password = generateSecurePassword(length, options)
    outputField.value = password
    useBtn.disabled = false
    copyBtn.disabled = false
  })

  // Use password button
  useBtn.addEventListener('click', () => {
    const password = outputField.value
    if (password && password !== i18n.t('content.passwordGenerator.outputPlaceholder')) {
      // Fill the main password field
      targetField.value = password
      targetField.dispatchEvent(new Event('input', { bubbles: true }))
      targetField.dispatchEvent(new Event('change', { bubbles: true }))

      // Find and fill confirmation field if it exists
      const confirmField = findPasswordConfirmationFieldFor(targetField)
      if (confirmField) {
        confirmField.value = password
        confirmField.dispatchEvent(new Event('input', { bubbles: true }))
        confirmField.dispatchEvent(new Event('change', { bubbles: true }))
        debugLog('Password filled in both fields (main + confirmation)')
      } else {
        debugLog('Password filled in main field only (no confirmation field found)')
      }

      closeModal(modal)
    }
  })

  // Copy button
  copyBtn.addEventListener('click', async () => {
    const password = outputField.value
    if (password && password !== i18n.t('content.passwordGenerator.outputPlaceholder')) {
      try {
        await navigator.clipboard.writeText(password)
        // Replace with check icon
        copyBtn.textContent = ''
        copyBtn.appendChild(createPasswordGenIcon('check'))
        setTimeout(() => {
          // Replace back with copy icon
          copyBtn.textContent = ''
          copyBtn.appendChild(createPasswordGenIcon('copy'))
        }, 2000)
      } catch (error) {
        console.error('Failed to copy password:', error)
      }
    }
  })

  // Auto-generate password on modal open with saved preferences
  if (savedPreferences) {
    const password = generateSecurePassword(savedPreferences.length, {
      lowercase: savedPreferences.lowercase,
      uppercase: savedPreferences.uppercase,
      numbers: savedPreferences.numbers,
      symbols: savedPreferences.symbols
    })
    outputField.value = password
    useBtn.disabled = false
    copyBtn.disabled = false
    debugLog('Password auto-generated on modal open')
  }
}

/**
 * Close modal
 *
 * @param {HTMLElement} modal - Modal to close
 */
function closeModal(modal) {
  modal.classList.remove('show')
  setTimeout(() => {
    if (modal.parentNode) {
      modal.parentNode.removeChild(modal)
    }
    passwordGeneratorState.activeModal = null
  }, 300)
}

/**
 * Initialize password generator markers on the page
 */
async function initializePasswordGeneratorMarkers() {
  debugLog('Initializing password generator markers')

  // Find all new password fields
  const passwordFields = findNewPasswordFields()

  if (passwordFields.length === 0) {
    debugLog('No new password fields found on page')
    return
  }

  debugLog(`Found ${passwordFields.length} new password field(s)`)

  // Remove any existing markers first
  passwordGeneratorState.markers.forEach(({ marker }) => {
    if (marker && marker.parentNode) {
      marker.parentNode.removeChild(marker)
    }
  })
  passwordGeneratorState.markers = []

  // Add markers to each field
  for (const field of passwordFields) {
    const marker = createPasswordGeneratorMarker(field)
    document.body.appendChild(marker)
    passwordGeneratorState.markers.push({ marker, field })
    debugLog('Password generator marker added to field:', field)
  }

  // Setup event listeners for scroll/resize if not already done
  if (!passwordGeneratorState.observerInitialized) {
    window.addEventListener('scroll', updatePasswordMarkerPositions, { passive: true })
    window.addEventListener('resize', updatePasswordMarkerPositions, { passive: true })

    // Listen for clicks that might change tab visibility or open modals
    // Use a debounced approach to avoid too many re-checks
    let clickDebounceTimer = null
    document.addEventListener('click', (e) => {
      const target = e.target

      // Check if clicked element or its parents have tab-related attributes
      const isTabClick = target.closest('[data-tab-id], [role="tab"], .tabs__btn, .tab-button, button[data-tab]')

      // Check if clicked element might open a modal/overlay (signup/register buttons)
      const isModalTrigger = target.closest('button, a, [role="button"]')
      let isLikelyModalOpen = false

      if (isModalTrigger) {
        const text = (isModalTrigger.textContent || '').toLowerCase()
        const className = (isModalTrigger.className || '').toLowerCase()
        const dataAttrs = Array.from(isModalTrigger.attributes)
          .filter(attr => attr.name.startsWith('data-'))
          .map(attr => attr.value.toLowerCase())
          .join(' ')

        const modalTriggerPatterns = /sign.*up|register|create.*account|join|modal|overlay/i
        isLikelyModalOpen = modalTriggerPatterns.test(text) ||
                            modalTriggerPatterns.test(className) ||
                            modalTriggerPatterns.test(dataAttrs)
      }

      if (isTabClick || isLikelyModalOpen) {
        const delay = isLikelyModalOpen ? 500 : 200  // Longer delay for modals
        const action = isLikelyModalOpen ? 'Modal trigger' : 'Tab click'

        debugLog(`${action} detected, will re-check password fields in ${delay}ms`)

        // Debounce: wait for animation to complete
        clearTimeout(clickDebounceTimer)
        clickDebounceTimer = setTimeout(() => {
          debugLog('Re-checking password fields after click')

          // ✅ Always update marker positions after tab clicks
          // This handles cases where fields exist but visibility changed (tabs)
          updatePasswordMarkerPositions()

          const newFields = findNewPasswordFields()
          const currentCount = passwordGeneratorState.markers.length

          if (newFields.length !== currentCount) {
            debugLog(`Password field count changed (${currentCount} -> ${newFields.length}), re-initializing`)
            initializePasswordGeneratorMarkers()
          }
        }, delay)
      }
    }, { passive: true })

    passwordGeneratorState.observerInitialized = true
    debugLog('Scroll/resize/click listeners added for password generator markers')
  }

  // Setup MutationObserver to detect:
  // 1. Dynamically added password fields
  // 2. Visibility changes (class/style changes on tabs)
  // 3. Modal/overlay appearance
  const observer = new MutationObserver((mutations) => {
    let shouldReinitialize = false
    let isModalAppearance = false

    for (const mutation of mutations) {
      // Check if new nodes were added
      if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
        // Check if any added nodes are modals/overlays or contain password fields
        for (const node of mutation.addedNodes) {
          if (node.nodeType === Node.ELEMENT_NODE) {
            // Check if this is a modal/overlay element
            const isModal = node.matches &&
              (node.matches('.overlay, .modal, [role="dialog"], .dialog, .popup, [data-overlay]') ||
               node.querySelector('.overlay, .modal, [role="dialog"], .dialog, .popup, [data-overlay]'))

            if (isModal) {
              debugLog('Modal/overlay detected in DOM, will re-check with delay')
              isModalAppearance = true
              shouldReinitialize = true
              break
            }

            // Check if the node IS a password field OR contains password fields
            const isPasswordField = node.tagName === 'INPUT' && node.type === 'password'
            const hasPasswordFields = node.querySelector && node.querySelector('input[type="password"]')

            if (isPasswordField || hasPasswordFields) {
              debugLog('New password field added to DOM')
              shouldReinitialize = true
              break
            }
          }
        }

        if (shouldReinitialize) break
      }

      // Check if class or style attributes changed (tab visibility)
      if (mutation.type === 'attributes') {
        const target = mutation.target

        // Check if this is a modal/overlay that became visible
        const isModal = target.classList.contains('overlay') ||
                       target.classList.contains('modal') ||
                       target.classList.contains('dialog') ||
                       target.classList.contains('popup') ||
                       target.getAttribute('role') === 'dialog'

        if (isModal && (mutation.attributeName === 'class' ||
                       mutation.attributeName === 'style' ||
                       mutation.attributeName === 'aria-hidden')) {
          debugLog('Modal/overlay visibility changed, re-checking password fields in 500ms')
          isModalAppearance = true
          shouldReinitialize = true
        }

        // Check if this is a tab panel whose visibility changed
        const isTabPanel = target.classList.contains('tabs__panel') ||
                          target.classList.contains('tab-panel') ||
                          target.classList.contains('tab-pane') ||
                          target.getAttribute('role') === 'tabpanel'

        if (isTabPanel && (mutation.attributeName === 'class' || mutation.attributeName === 'style')) {
          debugLog('Tab panel visibility changed (class/style), updating marker positions')
          // Don't reinitialize, just update positions
          setTimeout(() => updatePasswordMarkerPositions(), 50)
        }

        // If a container's class or style changed, it might affect field visibility
        if (target.querySelector && target.querySelector('input[type="password"]')) {
          shouldReinitialize = true
          debugLog('Visibility change detected (container with password fields), re-checking')
        }
      }
    }

    if (shouldReinitialize) {
      const currentFieldsCount = passwordGeneratorState.markers.length
      const newFields = findNewPasswordFields()

      if (newFields.length !== currentFieldsCount) {
        // Use longer delay for modal appearance to account for animations
        const delay = isModalAppearance ? 500 : 100
        debugLog(`Password field count changed (${currentFieldsCount} -> ${newFields.length}), re-initializing markers in ${delay}ms`)
        setTimeout(initializePasswordGeneratorMarkers, delay)
      }
    }
  })

  observer.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: true,           // Watch attribute changes
    attributeFilter: ['class', 'style', 'aria-hidden']  // Watch visibility-related attributes
  })
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    setTimeout(initializePasswordGeneratorMarkers, 1000)
  })
} else {
  setTimeout(initializePasswordGeneratorMarkers, 1000)
}

debugLog('Password generator injector loaded')
