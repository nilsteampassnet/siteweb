/**
 * Extension Name: Teampass Manager Extension
 * Copyright (c) 2026, LogCarré. All Rights Reserved.
 *
 * This code is proprietary software. It is distributed on a non-public, 
 * limited-use basis under the terms of a Commercial License.
 *
 * Unauthorized copying, modification, redistribution, or reverse engineering 
 * of this code, or any part thereof, is strictly prohibited.
 */

/**
 * Options page initialization script
 * Separated from inline script to comply with CSP requirements
 */

// Load version from config
document.getElementById('extensionVersion').textContent = `v${CONFIG.RELEASE}`

// Handle About link
document.getElementById('aboutLink').addEventListener('click', (e) => {
  e.preventDefault()
  chrome.windows.create({
    url: chrome.runtime.getURL('about/about.html'),
    type: 'popup',
    width: 600,
    height: 700
  })
})
