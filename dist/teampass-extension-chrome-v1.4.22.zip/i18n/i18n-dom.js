/**
 * Extension Name: Teampass Manager Extension
 * Copyright (c) 2026, LogCarré. All Rights Reserved.
 *
 * This code is proprietary software. It is distributed on a non-public,
 * limited-use basis under the terms of a Commercial License.
 *
 * Unauthorized copying, modification, redistribution, or reverse engineering
 * of this code, or any part thereof, is strictly prohibited.
 */

/**
 * i18n DOM Helper
 *
 * Automatically replaces text in HTML elements with translations.
 * Works by finding elements with data-i18n attributes and replacing their text.
 *
 * Usage in HTML:
 *   <button data-i18n="popup.main.addItemButton">Add new item</button>
 *   <input data-i18n-placeholder="popup.main.searchPlaceholder" placeholder="Search...">
 *   <button data-i18n-title="popup.editItem.showHidePassword" title="Show/Hide">Toggle</button>
 *
 * This file must be loaded AFTER i18n.js
 */

/**
 * Apply translations to all elements with data-i18n attributes
 */
function applyDOMTranslations() {
  if (typeof i18n === 'undefined' || !i18n.isReady()) {
    console.warn('[i18n-dom] i18n not ready, retrying in 100ms...')
    setTimeout(applyDOMTranslations, 100)
    return
  }

  // Translate text content
  document.querySelectorAll('[data-i18n]').forEach(element => {
    const key = element.getAttribute('data-i18n')
    if (key) {
      // Get params from data-i18n-params if exists
      const paramsAttr = element.getAttribute('data-i18n-params')
      const params = paramsAttr ? JSON.parse(paramsAttr) : {}

      const translation = i18n.t(key, params)

      // Different handling based on element type
      if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
        // Don't replace value for inputs, only placeholder
        // (value translation is handled separately with data-i18n-placeholder)
      } else {
        element.textContent = translation
      }
    }
  })

  // Translate placeholders
  document.querySelectorAll('[data-i18n-placeholder]').forEach(element => {
    const key = element.getAttribute('data-i18n-placeholder')
    if (key) {
      const paramsAttr = element.getAttribute('data-i18n-params')
      const params = paramsAttr ? JSON.parse(paramsAttr) : {}
      element.placeholder = i18n.t(key, params)
    }
  })

  // Translate titles (tooltips)
  document.querySelectorAll('[data-i18n-title]').forEach(element => {
    const key = element.getAttribute('data-i18n-title')
    if (key) {
      const paramsAttr = element.getAttribute('data-i18n-params')
      const params = paramsAttr ? JSON.parse(paramsAttr) : {}
      element.title = i18n.t(key, params)
    }
  })

  // Translate aria-labels
  document.querySelectorAll('[data-i18n-aria-label]').forEach(element => {
    const key = element.getAttribute('data-i18n-aria-label')
    if (key) {
      const paramsAttr = element.getAttribute('data-i18n-params')
      const params = paramsAttr ? JSON.parse(paramsAttr) : {}
      element.setAttribute('aria-label', i18n.t(key, params))
    }
  })

  console.log('[i18n-dom] Translations applied to DOM')
}

// Auto-apply on DOM ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', applyDOMTranslations)
} else {
  applyDOMTranslations()
}

// Make function available globally for dynamic content
if (typeof window !== 'undefined') {
  window.applyDOMTranslations = applyDOMTranslations
}
