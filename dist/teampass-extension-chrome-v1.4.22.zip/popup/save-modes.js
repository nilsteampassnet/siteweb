/**
 * Extension Name: Teampass Manager Extension
 * Copyright (c) 2026, LogCarré. All Rights Reserved.
 *
 * This code is proprietary software. It is distributed on a non-public,
 * limited-use basis under the terms of a Commercial License.
 *
 * Unauthorized copying, modification, redistribution, or reverse engineering
 * of this code, or any part thereof, is strictly prohibited.
 */

/**
 * Save Modes Handler
 *
 * Manages the different credential save modes:
 * - Quick Save: Fast save with minimal fields
 * - Update Existing: Update an existing credential
 * - Advanced Save: Full form with all fields
 */

class SaveModesHandler {
  constructor() {
    this.currentMode = null
    this.pendingCredential = null
    this.existingItem = null
    this.allFolders = [] // Store all folders for search functionality
  }

  /**
   * Initialize save modes - check if popup should open in save mode
   * @returns {Promise<boolean>} True if popup opened in save mode
   */
  async initialize() {
    try {
      debugLog('🔐 [SaveModes] Initializing save modes...')

      // Check if we should open in save mode
      const storage = await chrome.storage.local.get(['popup_save_mode', 'popup_existing_item'])

      debugLog('🔐 [SaveModes] Storage check:', storage)

      if (storage.popup_save_mode) {
        this.currentMode = storage.popup_save_mode
        this.existingItem = storage.popup_existing_item

        debugLog('🔐 [SaveModes] Opening popup in save mode:', this.currentMode)

        // Get pending credential from session via service worker
        const response = await chrome.runtime.sendMessage({
          action: 'getPendingCredential'
        })

        if (response.success && response.data) {
          this.pendingCredential = response.data
          debugLog('🔐 [SaveModes] Pending credential retrieved:', this.pendingCredential)
        } else {
          console.error('🔐 [SaveModes] Failed to get pending credential:', response.error)
        }

        // Clear the save mode from storage (one-time use)
        await chrome.storage.local.remove(['popup_save_mode', 'popup_existing_item'])

        // Show appropriate screen
        this.showSaveScreen()

        return true // Indicate we're in save mode
      }

      return false // Not in save mode
    } catch (error) {
      console.error('🔐 [SaveModes] Error initializing save modes:', error)
      return false
    }
  }

  /**
   * Check if currently in save mode
   * @returns {boolean} True if in save mode
   */
  isInSaveMode() {
    return this.currentMode !== null
  }

  /**
   * Show the appropriate save screen based on current mode
   */
  showSaveScreen() {
    switch (this.currentMode) {
      case 'new':
        this.showQuickSaveScreen()
        break
      case 'update':
        this.showUpdateExistingScreen()
        break
      case 'advanced':
        this.showAdvancedSaveScreen()
        break
      default:
        console.error('Unknown save mode:', this.currentMode)
    }
  }

  /**
   * Show Quick Save screen
   */
  async showQuickSaveScreen() {
    debugLog('🔐 [SaveModes] Showing Quick Save screen')

    if (!this.pendingCredential) {
      console.error('🔐 [SaveModes] No pending credential found')
      showToast(i18n.t('saveModes.messages.noCredentials'), 'error')
      return
    }

    debugLog('🔐 [SaveModes] Pending credential:', this.pendingCredential)

    // Get last used folder for this domain
    const lastFolder = await this.getLastUsedFolder(this.pendingCredential.domain)
    debugLog('🔐 [SaveModes] Last used folder:', lastFolder)

    // Load writable folders
    debugLog('🔐 [SaveModes] Loading writable folders...')
    const folders = await this.loadWritableFolders()
    debugLog('🔐 [SaveModes] Loaded folders:', folders)

    if (!folders || folders.length === 0) {
      console.error('🔐 [SaveModes] No writable folders available!')
      showToast(i18n.t('saveModes.messages.noWritableFolders'), 'error')
      return
    }

    // Sort folders in tree order
    const sortedFolders = this.sortFoldersInTreeOrder(folders)
    debugLog('🔐 [SaveModes] Folders sorted in tree order')

    // Show quick save screen
    this.displayQuickSaveForm(this.pendingCredential, lastFolder, sortedFolders)
  }

  /**
   * Show Update Existing screen
   */
  showUpdateExistingScreen() {
    debugLog('Showing Update Existing screen')

    if (!this.pendingCredential || !this.existingItem) {
      console.error('Missing credential or existing item')
      showToast(i18n.t('saveModes.messages.missingData'), 'error')
      return
    }

    // Show update screen
    this.displayUpdateExistingForm(this.pendingCredential, this.existingItem)
  }

  /**
   * Show Advanced Save screen (use existing Add Item screen)
   */
  async showAdvancedSaveScreen() {
    debugLog('🔐 [SaveModes] Showing Advanced Save screen')

    if (!this.pendingCredential) {
      console.error('🔐 [SaveModes] No pending credential found')
      return
    }

    // Hide all custom save screens
    const quickSaveScreen = document.getElementById('quickSaveScreen')
    if (quickSaveScreen) {
      quickSaveScreen.style.display = 'none'
    }

    const updateExistingScreen = document.getElementById('updateExistingScreen')
    if (updateExistingScreen) {
      updateExistingScreen.style.display = 'none'
    }

    // Switch to existing Add Item screen
    showScreen('addItem')

    // Wait for DOM to be ready
    await new Promise(resolve => setTimeout(resolve, 50))

    // Get label from Quick Save form if it exists, otherwise use domain
    let label = this.pendingCredential.domain || ''
    const quickSaveLabelField = document.getElementById('quickSaveLabel')
    if (quickSaveLabelField && quickSaveLabelField.value) {
      label = quickSaveLabelField.value
    }

    // Pre-fill form with pending credential using getElementById
    const itemLabelField = document.getElementById('itemLabel')
    const itemLoginField = document.getElementById('itemLogin')
    const itemPasswordField = document.getElementById('itemPassword')
    const itemUrlField = document.getElementById('itemUrl')

    if (itemLabelField) {
      itemLabelField.value = label
      debugLog('🔐 [SaveModes] Set label:', label)
    }
    if (itemLoginField) {
      itemLoginField.value = this.pendingCredential.username || ''
      debugLog('🔐 [SaveModes] Set login:', this.pendingCredential.username)
    }
    if (itemPasswordField) {
      itemPasswordField.value = this.pendingCredential.password || ''
      debugLog('🔐 [SaveModes] Set password: ********')
    }
    if (itemUrlField) {
      itemUrlField.value = this.pendingCredential.url || ''
      debugLog('🔐 [SaveModes] Set URL:', this.pendingCredential.url)
    }

    // Load folders
    await loadWritableFolders()

    // Get folder from Quick Save form if it exists
    const itemFolderField = document.getElementById('itemFolderId')
    const quickSaveFolderField = document.getElementById('quickSaveFolderId')

    if (itemFolderField) {
      if (quickSaveFolderField && quickSaveFolderField.value) {
        itemFolderField.value = quickSaveFolderField.value
        debugLog('🔐 [SaveModes] Set folder from Quick Save:', quickSaveFolderField.value)
      } else {
        // Set last used folder if available
        const lastFolder = await this.getLastUsedFolder(this.pendingCredential.domain)
        if (lastFolder) {
          itemFolderField.value = lastFolder
          debugLog('🔐 [SaveModes] Set last used folder:', lastFolder)
        }
      }
    }
  }

  /**
   * Display Quick Save form
   */
  displayQuickSaveForm(credential, defaultFolderId, folders) {
    // Create quick save screen if doesn't exist
    let quickSaveScreen = document.getElementById('quickSaveScreen')

    if (!quickSaveScreen) {
      quickSaveScreen = this.createQuickSaveScreen()
      document.body.appendChild(quickSaveScreen)
    }

    // Show quick save screen
    Object.values(screens).forEach(s => s.style.display = 'none')
    quickSaveScreen.style.display = 'block'

    // Fill form
    document.getElementById('quickSaveLabel').value = credential.domain || ''
    document.getElementById('quickSaveLogin').value = credential.username || ''
    document.getElementById('quickSavePassword').value = credential.password || ''

    // Store all folders for search
    this.allFolders = folders

    // Display folders with hierarchy
    this.displayFilteredQuickSaveFolders(folders, defaultFolderId)

    // Update favorite folder button state (enable/disable based on whether favorite is set)
    if (typeof updateFavoriteFolderButtonsState === 'function') {
      updateFavoriteFolderButtonsState()
    }
  }

  /**
   * Display filtered folders in Quick Save form
   */
  displayFilteredQuickSaveFolders(folders, selectedFolderId = null) {
    const folderSelect = document.getElementById('quickSaveFolderId')

    if (!folderSelect) return

    // Clear existing options
    folderSelect.innerHTML = ''

    // Add default option
    const defaultOption = document.createElement('option')
    defaultOption.value = ''
    defaultOption.textContent = i18n.t('saveModes.quickSave.folderSelect')
    folderSelect.appendChild(defaultOption)

    // Add folder options using safe DOM manipulation
    folders.forEach(folder => {
      folderSelect.appendChild(this.createFolderOption(folder, selectedFolderId))
    })
  }

  /**
   * Escape HTML to prevent XSS
   */
  escapeHtml(text) {
    const div = document.createElement('div')
    div.textContent = text
    return div.innerHTML
  }

  /**
   * Create a folder option element for a select dropdown (safe alternative to innerHTML)
   * @param {Object} folder - Folder object with id, label, and level
   * @param {string|null} selectedId - ID of the selected folder
   * @returns {HTMLOptionElement} Option element
   */
  createFolderOption(folder, selectedId = null) {
    const option = document.createElement('option')
    option.value = folder.id

    // Create indentation based on level using non-breaking spaces
    const indent = folder.level > 0 ? '\u00A0\u00A0'.repeat(folder.level * 2) : ''
    const prefix = folder.level > 0 ? '└─ ' : ''
    const label = folder.label || `Folder ${folder.id}`

    option.textContent = indent + prefix + label

    if (folder.id === selectedId) {
      option.selected = true
    }

    return option
  }

  /**
   * Display Update Existing form
   */
  async displayUpdateExistingForm(newCredential, existingItem) {
    // Create update screen if doesn't exist
    let updateScreen = document.getElementById('updateExistingScreen')

    if (!updateScreen) {
      updateScreen = this.createUpdateExistingScreen()
      document.body.appendChild(updateScreen)
    }

    // Hide all standard screens
    Object.values(screens).forEach(s => s.style.display = 'none')

    // Hide items section explicitly (not part of screens object)
    const itemsSection = document.getElementById('itemsSection')
    if (itemsSection) {
      itemsSection.style.display = 'none'
    }

    // Show update screen
    updateScreen.style.display = 'block'

    // Fill form fields
    // Label field
    document.getElementById('updateLabel').value = existingItem.label || ''

    // Login fields - Current (readonly) and New (editable, pre-filled)
    document.getElementById('updateCurrentLogin').value = existingItem.login || ''
    document.getElementById('updateLogin').value = newCredential.username || existingItem.login || ''

    // Password fields - Current (readonly) and New (editable, pre-filled)
    document.getElementById('updateCurrentPassword').value = existingItem.pwd || ''
    document.getElementById('updatePassword').value = newCredential.password || existingItem.pwd || ''

    // Load folders for the folder select
    await this.loadUpdateFolders()

    // Select the current folder
    const folderSelect = document.getElementById('updateFolderId')
    if (existingItem.id_tree) {
      folderSelect.value = existingItem.id_tree
    }

    // Store item ID and existing data for update
    updateScreen.dataset.itemId = existingItem.id
    updateScreen.dataset.existingLabel = existingItem.label || ''
    updateScreen.dataset.existingLogin = existingItem.login || ''
    updateScreen.dataset.existingPassword = existingItem.pwd || ''
    updateScreen.dataset.existingFolder = existingItem.id_tree || ''
  }

  /**
   * Create Quick Save screen HTML
   */
  createQuickSaveScreen() {
    const screen = document.createElement('div')
    screen.id = 'quickSaveScreen'
    screen.className = 'screen'
    screen.style.display = 'none'

    // Create static HTML structure
    screen.innerHTML = `
      <div class="header">
        <h1><i class="fas fa-save"></i> <span id="qs-title"></span></h1>
        <button id="backFromQuickSaveBtn" class="back-btn-right">
          <i class="fas fa-arrow-left"></i>
        </button>
      </div>

      <div class="content">
        <form id="quickSaveForm" class="save-form">
          <div class="form-group">
            <label for="quickSaveLabel"><span id="qs-label-field"></span> <span class="required" id="qs-label-required"></span></label>
            <input type="text" id="quickSaveLabel" required>
            <small id="qs-label-hint"></small>
          </div>

          <div class="form-group">
            <label for="quickSaveLogin"><span id="qs-login-field"></span> <span class="required" id="qs-login-required"></span></label>
            <input type="text" id="quickSaveLogin" readonly class="readonly-field">
          </div>

          <div class="form-group">
            <label for="quickSavePassword"><span id="qs-password-field"></span> <span class="required" id="qs-password-required"></span></label>
            <div class="password-field-wrapper">
              <input type="password" id="quickSavePassword" readonly class="readonly-field">
              <button type="button" id="quickSavePasswordToggle" class="btn-icon">
                <i class="fas fa-eye"></i>
              </button>
            </div>
          </div>

          <div class="form-group">
            <label for="quickSaveFolderId"><span id="qs-folder-field"></span> <span class="required" id="qs-folder-required"></span></label>
            <div class="folder-search-wrapper">
              <input type="text" id="quickSaveFolderSearch" autocomplete="off">
              <button type="button" id="quickSaveUseFavoriteFolderBtn" class="btn-favorite-inline" disabled>
                <i class="fas fa-star"></i>
              </button>
            </div>
            <select id="quickSaveFolderId" required size="8" style="margin-top: 8px;">
              <option value="" id="qs-folder-select-opt"></option>
            </select>
            <small id="qs-folder-hint"></small>
          </div>

          <div class="form-actions">
            <button type="submit" class="btn btn-primary">
              <i class="fas fa-save"></i> <span id="qs-save-button"></span>
            </button>
            <button type="button" id="customizeBtn" class="btn btn-secondary">
              <i class="fas fa-cog"></i> <span id="qs-customize-button"></span>
            </button>
          </div>
        </form>
      </div>
    `

    // Inject i18n values safely using textContent
    screen.querySelector('#qs-title').textContent = i18n.t('saveModes.quickSave.title')
    screen.querySelector('#backFromQuickSaveBtn').title = i18n.t('saveModes.quickSave.backButton')
    screen.querySelector('#qs-label-field').textContent = i18n.t('saveModes.quickSave.labelField')
    screen.querySelector('#qs-label-required').textContent = i18n.t('saveModes.quickSave.labelRequired')
    screen.querySelector('#qs-label-hint').textContent = i18n.t('saveModes.quickSave.labelHint')
    screen.querySelector('#qs-login-field').textContent = i18n.t('saveModes.quickSave.loginField')
    screen.querySelector('#qs-login-required').textContent = i18n.t('saveModes.quickSave.labelRequired')
    screen.querySelector('#qs-password-field').textContent = i18n.t('saveModes.quickSave.passwordField')
    screen.querySelector('#qs-password-required').textContent = i18n.t('saveModes.quickSave.labelRequired')
    screen.querySelector('#quickSavePasswordToggle').title = i18n.t('saveModes.quickSave.showHide')
    screen.querySelector('#qs-folder-field').textContent = i18n.t('saveModes.quickSave.folderField')
    screen.querySelector('#qs-folder-required').textContent = i18n.t('saveModes.quickSave.folderRequired')
    screen.querySelector('#quickSaveFolderSearch').placeholder = i18n.t('saveModes.quickSave.folderSearch')
    screen.querySelector('#quickSaveUseFavoriteFolderBtn').title = i18n.t('saveModes.quickSave.useFavoriteFolder')
    screen.querySelector('#qs-folder-select-opt').textContent = i18n.t('saveModes.quickSave.folderSelect')
    screen.querySelector('#qs-folder-hint').textContent = i18n.t('saveModes.quickSave.folderHint')
    screen.querySelector('#qs-save-button').textContent = i18n.t('saveModes.quickSave.quickSaveButton')
    screen.querySelector('#qs-customize-button').textContent = i18n.t('saveModes.quickSave.customizeButton')

    // Add event listeners
    screen.querySelector('#backFromQuickSaveBtn').addEventListener('click', () => {
      this.cancelSave()
    })

    screen.querySelector('#quickSavePasswordToggle').addEventListener('click', () => {
      const passwordField = document.getElementById('quickSavePassword')
      const icon = screen.querySelector('#quickSavePasswordToggle i')
      if (passwordField.type === 'password') {
        passwordField.type = 'text'
        icon.className = 'fas fa-eye-slash'
      } else {
        passwordField.type = 'password'
        icon.className = 'fas fa-eye'
      }
    })

    screen.querySelector('#customizeBtn').addEventListener('click', () => {
      this.currentMode = 'advanced'
      this.showAdvancedSaveScreen()
    })

    screen.querySelector('#quickSaveForm').addEventListener('submit', (e) => {
      e.preventDefault()
      this.handleQuickSave()
    })

    // Add folder search listener
    screen.querySelector('#quickSaveFolderSearch').addEventListener('input', (e) => {
      this.handleQuickSaveFolderSearch(e)
    })

    // Add favorite folder button listener
    const quickSaveUseFavoriteFolderBtn = screen.querySelector('#quickSaveUseFavoriteFolderBtn')
    if (quickSaveUseFavoriteFolderBtn && typeof handleUseFavoriteFolder === 'function') {
      quickSaveUseFavoriteFolderBtn.addEventListener('click', () => {
        debugLog('[FavoriteFolder] Quick Save favorite folder button clicked!')
        handleUseFavoriteFolder('quickSaveFolderId')
      })
      debugLog('[FavoriteFolder] Quick Save favorite folder button listener attached')
    }

    return screen
  }

  /**
   * Handle folder search in Quick Save form
   */
  handleQuickSaveFolderSearch(event) {
    const searchTerm = event.target.value.toLowerCase().trim()

    if (!searchTerm) {
      // No search term, show all folders
      this.displayFilteredQuickSaveFolders(this.allFolders)
      return
    }

    // Filter folders by label
    const filteredFolders = this.allFolders.filter(folder =>
      folder.label.toLowerCase().includes(searchTerm)
    )

    this.displayFilteredQuickSaveFolders(filteredFolders)

    // Show message if no results
    if (filteredFolders.length === 0) {
      const folderSelect = document.getElementById('quickSaveFolderId')
      folderSelect.innerHTML = ''
      const option = document.createElement('option')
      option.value = ''
      option.textContent = i18n.t('saveModes.quickSave.noFoldersFound')
      folderSelect.appendChild(option)
    }
  }

  /**
   * Load folders for Update Existing form
   */
  async loadUpdateFolders() {
    try {
      // Get folders from Teampass
      const response = await chrome.runtime.sendMessage({
        action: 'getWritableFolders'
      })

      if (response && response.success && response.data) {
        // Sort folders in tree order
        const sortedFolders = this.sortFoldersInTreeOrder(response.data)

        // Store all folders for search
        this.allUpdateFolders = sortedFolders

        // Display folders
        this.displayFilteredUpdateFolders(sortedFolders)
      } else {
        console.error('Failed to load folders:', response?.error)
        const folderSelect = document.getElementById('updateFolderId')
        folderSelect.innerHTML = ''
        const option = document.createElement('option')
        option.value = ''
        option.textContent = i18n.t('saveModes.quickSave.noFoldersFound')
        folderSelect.appendChild(option)
      }
    } catch (error) {
      console.error('Error loading folders:', error)
      const folderSelect = document.getElementById('updateFolderId')
      folderSelect.innerHTML = ''
      const option = document.createElement('option')
      option.value = ''
      option.textContent = i18n.t('saveModes.quickSave.noFoldersFound')
      folderSelect.appendChild(option)
    }
  }

  /**
   * Display filtered folders in Update Existing form
   */
  displayFilteredUpdateFolders(folders, selectedFolderId = null) {
    const folderSelect = document.getElementById('updateFolderId')

    if (!folderSelect) return

    // Clear existing options
    folderSelect.innerHTML = ''

    // Add default option
    const defaultOption = document.createElement('option')
    defaultOption.value = ''
    defaultOption.textContent = i18n.t('saveModes.quickSave.folderSelect')
    folderSelect.appendChild(defaultOption)

    // Add folder options using safe DOM manipulation
    folders.forEach(folder => {
      folderSelect.appendChild(this.createFolderOption(folder, selectedFolderId))
    })
  }

  /**
   * Handle folder search in Update Existing form
   */
  handleUpdateFolderSearch(event) {
    const searchTerm = event.target.value.toLowerCase().trim()

    if (!searchTerm) {
      // No search term, show all folders
      this.displayFilteredUpdateFolders(this.allUpdateFolders || [])
      return
    }

    // Filter folders by label
    const filteredFolders = (this.allUpdateFolders || []).filter(folder =>
      folder.label.toLowerCase().includes(searchTerm)
    )

    this.displayFilteredUpdateFolders(filteredFolders)

    // Show message if no results
    if (filteredFolders.length === 0) {
      const folderSelect = document.getElementById('updateFolderId')
      folderSelect.innerHTML = ''
      const option = document.createElement('option')
      option.value = ''
      option.textContent = i18n.t('saveModes.quickSave.noFoldersFound')
      folderSelect.appendChild(option)
    }
  }

  /**
   * Create Update Existing screen HTML
   */
  createUpdateExistingScreen() {
    const screen = document.createElement('div')
    screen.id = 'updateExistingScreen'
    screen.className = 'screen'
    screen.style.display = 'none'

    // Create static HTML structure
    screen.innerHTML = `
      <div class="header">
        <h1><i class="fas fa-exclamation-triangle"></i> <span id="ue-title"></span></h1>
        <button id="backFromUpdateBtn" class="back-btn-right">
          <i class="fas fa-arrow-left"></i>
        </button>
      </div>

      <div class="content">
        <form id="updateExistingForm" class="save-form">
          <div class="form-group">
            <label for="updateLabel"><span id="ue-label-field"></span> <span class="required">*</span></label>
            <input type="text" id="updateLabel" required>
          </div>

          <div class="form-group">
            <label for="updateLogin" id="ue-login-field"></label>
            <div class="comparison-row">
              <div style="flex: 1;">
                <small id="ue-current-label-1"></small>
                <input type="text" id="updateCurrentLogin" readonly class="readonly-field">
              </div>
              <div style="flex: 1;">
                <small id="ue-new-label-1"></small>
                <input type="text" id="updateLogin">
              </div>
            </div>
          </div>

          <div class="form-group">
            <label for="updatePassword"><span id="ue-password-field"></span> <span class="required">*</span></label>
            <div class="comparison-row">
              <div style="flex: 1;">
                <small id="ue-current-label-2"></small>
                <div class="password-field-wrapper">
                  <input type="password" id="updateCurrentPassword" readonly class="readonly-field">
                  <button type="button" id="toggleCurrentPassword" class="btn-icon">
                    <i class="fas fa-eye"></i>
                  </button>
                </div>
              </div>
              <div style="flex: 1;">
                <small id="ue-new-label-2"></small>
                <div class="password-field-wrapper">
                  <input type="password" id="updatePassword" required>
                  <button type="button" id="updatePasswordToggle" class="btn-icon">
                    <i class="fas fa-eye"></i>
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div class="form-group">
            <label for="updateFolderId"><span id="ue-folder-field"></span> <span class="required">*</span></label>
            <div class="folder-search-wrapper">
              <input type="text" id="updateFolderSearch" autocomplete="off">
              <button type="button" id="updateUseFavoriteFolderBtn" class="btn-favorite-inline" disabled>
                <i class="fas fa-star"></i>
              </button>
            </div>
            <select id="updateFolderId" required size="8" style="margin-top: 8px;">
              <option value="" id="ue-folder-select-opt"></option>
            </select>
          </div>

          <div class="form-actions">
            <button type="submit" class="btn btn-primary">
              <i class="fas fa-sync"></i> <span id="ue-update-button"></span>
            </button>
            <button type="button" id="createNewBtn" class="btn btn-secondary">
              <i class="fas fa-plus"></i> <span id="ue-create-new-button"></span>
            </button>
            <button type="button" id="skipUpdateBtn" class="btn btn-tertiary">
              <i class="fas fa-times"></i> <span id="ue-skip-button"></span>
            </button>
          </div>
        </form>
      </div>
    `

    // Inject i18n values safely using textContent
    screen.querySelector('#ue-title').textContent = i18n.t('saveModes.updateExisting.title')
    screen.querySelector('#backFromUpdateBtn').title = i18n.t('saveModes.updateExisting.backButton')
    screen.querySelector('#ue-label-field').textContent = i18n.t('saveModes.updateExisting.labelField')
    screen.querySelector('#ue-login-field').textContent = i18n.t('saveModes.updateExisting.loginField')
    screen.querySelector('#ue-current-label-1').textContent = i18n.t('saveModes.updateExisting.currentLabel')
    screen.querySelector('#ue-new-label-1').textContent = i18n.t('saveModes.updateExisting.newLabel')
    screen.querySelector('#ue-password-field').textContent = i18n.t('saveModes.updateExisting.passwordField')
    screen.querySelector('#ue-current-label-2').textContent = i18n.t('saveModes.updateExisting.currentLabel')
    screen.querySelector('#ue-new-label-2').textContent = i18n.t('saveModes.updateExisting.newLabel')
    screen.querySelector('#toggleCurrentPassword').title = i18n.t('saveModes.updateExisting.showHideCurrent')
    screen.querySelector('#updatePasswordToggle').title = i18n.t('saveModes.updateExisting.showHidePassword')
    screen.querySelector('#ue-folder-field').textContent = i18n.t('saveModes.updateExisting.folderField')
    screen.querySelector('#updateFolderSearch').placeholder = i18n.t('saveModes.quickSave.folderSearch')
    screen.querySelector('#updateUseFavoriteFolderBtn').title = i18n.t('saveModes.quickSave.useFavoriteFolder')
    screen.querySelector('#ue-folder-select-opt').textContent = i18n.t('saveModes.quickSave.folderSelect')
    screen.querySelector('#ue-update-button').textContent = i18n.t('saveModes.updateExisting.updateButton')
    screen.querySelector('#ue-create-new-button').textContent = i18n.t('saveModes.updateExisting.createNewButton')
    screen.querySelector('#ue-skip-button').textContent = i18n.t('saveModes.updateExisting.skipButton')

    // Add event listeners
    screen.querySelector('#backFromUpdateBtn').addEventListener('click', () => {
      this.cancelSave()
    })

    screen.querySelector('#updateExistingForm').addEventListener('submit', (e) => {
      e.preventDefault()
      this.handleUpdateExisting()
    })

    screen.querySelector('#createNewBtn').addEventListener('click', () => {
      this.currentMode = 'advanced'
      this.showAdvancedSaveScreen()
    })

    screen.querySelector('#skipUpdateBtn').addEventListener('click', () => {
      this.cancelSave()
    })

    // Password toggle buttons
    screen.querySelector('#toggleCurrentPassword').addEventListener('click', () => {
      const passwordField = document.getElementById('updateCurrentPassword')
      const icon = screen.querySelector('#toggleCurrentPassword i')
      if (passwordField.type === 'password') {
        passwordField.type = 'text'
        icon.className = 'fas fa-eye-slash'
      } else {
        passwordField.type = 'password'
        icon.className = 'fas fa-eye'
      }
    })

    screen.querySelector('#updatePasswordToggle').addEventListener('click', () => {
      const passwordField = document.getElementById('updatePassword')
      const icon = screen.querySelector('#updatePasswordToggle i')
      if (passwordField.type === 'password') {
        passwordField.type = 'text'
        icon.className = 'fas fa-eye-slash'
      } else {
        passwordField.type = 'password'
        icon.className = 'fas fa-eye'
      }
    })

    // Folder search listener
    screen.querySelector('#updateFolderSearch').addEventListener('input', (e) => {
      this.handleUpdateFolderSearch(e)
    })

    // Add favorite folder button listener
    const updateUseFavoriteFolderBtn = screen.querySelector('#updateUseFavoriteFolderBtn')
    if (updateUseFavoriteFolderBtn && typeof handleUseFavoriteFolder === 'function') {
      updateUseFavoriteFolderBtn.addEventListener('click', () => {
        debugLog('[FavoriteFolder] Update screen favorite folder button clicked!')
        handleUseFavoriteFolder('updateFolderId')
      })
      debugLog('[FavoriteFolder] Update screen favorite folder button listener attached')
    }

    return screen
  }

  /**
   * Handle Quick Save submission
   */
  async handleQuickSave() {
    try {
      const label = document.getElementById('quickSaveLabel').value
      const folderId = document.getElementById('quickSaveFolderId').value

      if (!label) {
        showToast(i18n.t('saveModes.messages.enterLabel'), 'error')
        return
      }

      if (!folderId) {
        showToast(i18n.t('saveModes.messages.selectFolder'), 'error')
        return
      }

      // Show loading
      showToast(i18n.t('saveModes.messages.savingCredentials'), 'info')

      // Ensure valid authentication before creating item
      debugLog('🔐 [SaveModes] Ensuring valid authentication before save...')
      const tokenValidation = await chrome.runtime.sendMessage({
        action: 'ensureValidToken'
      })

      if (!tokenValidation.success || !tokenValidation.data) {
        // Authentication failed, try to authenticate
        debugLog('🔐 [SaveModes] Token validation failed, user needs to authenticate')
        showToast(i18n.t('saveModes.messages.authenticationRequired') || 'Authentication required. Please login first.', 'error')

        // Redirect to options page for login
        if (typeof chrome.runtime.openOptionsPage === 'function') {
          chrome.runtime.openOptionsPage()
        }
        return
      }

      debugLog('🔐 [SaveModes] Authentication valid, proceeding with save...')

      // Create item data - ALL fields required by Teampass API (even if empty)
      const itemData = {
        label: label,
        login: this.pendingCredential.username,
        password: this.pendingCredential.password,
        url: this.pendingCredential.url,
        email: '', // Required by API even if empty
        description: '', // Required by API even if empty
        tags: '', // Required by API even if empty
        icon: '', // Required by API even if empty
        anyone_can_modify: 0, // Required by API
        folder_id: parseInt(folderId, 10)
      }

      // Create item
      const response = await chrome.runtime.sendMessage({
        action: 'createItem',
        data: { itemData }
      })

      if (response.success) {
        // Save last used folder
        await this.saveLastUsedFolder(this.pendingCredential.domain, folderId)

        // Clear session credential via service worker
        await chrome.runtime.sendMessage({
          action: 'removePendingCredential'
        })

        showToast(i18n.t('saveModes.messages.credentialsSaved'), 'success')

        // Hide Quick Save screen
        const quickSaveScreen = document.getElementById('quickSaveScreen')
        if (quickSaveScreen) {
          quickSaveScreen.style.display = 'none'
        }

        // Return to main screen
        showScreen('main')
        if (typeof loadItemsForCurrentPage === 'function') {
          loadItemsForCurrentPage()
        }
      } else {
        throw new Error(response.error || 'Failed to save credentials')
      }
    } catch (error) {
      console.error('Quick save error:', error)
      showToast(i18n.t('saveModes.messages.saveFailed') + ' ' + error.message, 'error')
    }
  }

  /**
   * Handle Update Existing submission
   */
  async handleUpdateExisting() {
    try {
      const updateScreen = document.getElementById('updateExistingScreen')
      const itemId = updateScreen.dataset.itemId

      if (!itemId) {
        throw new Error(i18n.t('saveModes.messages.noItemId'))
      }

      // Get form values
      const newLabel = document.getElementById('updateLabel').value.trim()
      const newLogin = document.getElementById('updateLogin').value.trim()
      const newPassword = document.getElementById('updatePassword').value
      const newFolderId = document.getElementById('updateFolderId').value

      // Validate required fields
      if (!newLabel) {
        showToast(i18n.t('saveModes.messages.labelRequired'), 'error')
        return
      }

      if (!newPassword) {
        showToast(i18n.t('saveModes.messages.passwordRequired'), 'error')
        return
      }

      if (!newFolderId) {
        showToast(i18n.t('saveModes.messages.folderRequired'), 'error')
        return
      }

      // Show loading
      showToast(i18n.t('saveModes.messages.updatingCredentials'), 'info')

      // Ensure valid authentication before updating item
      debugLog('🔐 [SaveModes] Ensuring valid authentication before update...')
      const tokenValidation = await chrome.runtime.sendMessage({
        action: 'ensureValidToken'
      })

      if (!tokenValidation.success || !tokenValidation.data) {
        // Authentication failed
        debugLog('🔐 [SaveModes] Token validation failed, user needs to authenticate')
        showToast(i18n.t('saveModes.messages.authenticationRequired') || 'Authentication required. Please login first.', 'error')

        // Redirect to options page for login
        if (typeof chrome.runtime.openOptionsPage === 'function') {
          chrome.runtime.openOptionsPage()
        }
        return
      }

      debugLog('🔐 [SaveModes] Authentication valid, proceeding with update...')

      // Get existing values from dataset
      const existingLabel = updateScreen.dataset.existingLabel || ''
      const existingLogin = updateScreen.dataset.existingLogin || ''
      const existingPassword = updateScreen.dataset.existingPassword || ''
      const existingFolder = updateScreen.dataset.existingFolder || ''

      // Build update data with all editable fields
      const itemData = {}

      // Check what changed and include in update
      if (newLabel !== existingLabel) {
        itemData.label = newLabel
      }

      if (newLogin !== existingLogin) {
        itemData.login = newLogin
      }

      if (newPassword !== existingPassword) {
        itemData.password = newPassword
      }

      if (newFolderId !== existingFolder) {
        itemData.folder_id = parseInt(newFolderId, 10)
      }

      // If nothing changed, just close
      if (Object.keys(itemData).length === 0) {
        showToast(i18n.t('saveModes.messages.noChanges'), 'info')
        this.cancelSave()
        return
      }

      // Update item
      const response = await chrome.runtime.sendMessage({
        action: 'updateItem',
        data: {
          itemId: parseInt(itemId, 10),
          itemData
        }
      })

      if (response.success) {
        // Clear session credential via service worker
        await chrome.runtime.sendMessage({
          action: 'removePendingCredential'
        })

        showToast(i18n.t('saveModes.messages.credentialsUpdated'), 'success')

        // Hide Update Existing screen
        if (updateScreen) {
          updateScreen.style.display = 'none'
        }

        // Return to main screen
        showScreen('main')
        if (typeof loadItemsForCurrentPage === 'function') {
          loadItemsForCurrentPage()
        }
      } else {
        throw new Error(response.error || 'Failed to update credentials')
      }
    } catch (error) {
      console.error('Update error:', error)
      showToast(i18n.t('saveModes.messages.updateFailed') + ' ' + error.message, 'error')
    }
  }

  /**
   * Cancel save and clear session data
   */
  async cancelSave() {
    try {
      debugLog('🔐 [SaveModes] Canceling save, clearing session...')

      // Clear session credential via service worker
      await chrome.runtime.sendMessage({
        action: 'removePendingCredential'
      })

      // Hide all custom save screens
      const quickSaveScreen = document.getElementById('quickSaveScreen')
      if (quickSaveScreen) {
        quickSaveScreen.style.display = 'none'
      }

      const updateScreen = document.getElementById('updateExistingScreen')
      if (updateScreen) {
        updateScreen.style.display = 'none'
      }

      // Return to main screen and load items
      showScreen('main')
      if (typeof loadItemsForCurrentPage === 'function') {
        await loadItemsForCurrentPage()
      }
    } catch (error) {
      console.error('🔐 [SaveModes] Cancel error:', error)
    }
  }

  /**
   * Get last used folder for domain
   */
  async getLastUsedFolder(domain) {
    try {
      const storage = await chrome.storage.local.get(['lastUsedFolders'])
      const folders = storage.lastUsedFolders || {}
      return folders[domain] || null
    } catch (error) {
      console.error('Error getting last used folder:', error)
      return null
    }
  }

  /**
   * Save last used folder for domain
   */
  async saveLastUsedFolder(domain, folderId) {
    try {
      const storage = await chrome.storage.local.get(['lastUsedFolders'])
      const folders = storage.lastUsedFolders || {}
      folders[domain] = parseInt(folderId, 10)
      await chrome.storage.local.set({ lastUsedFolders: folders })
    } catch (error) {
      console.error('Error saving last used folder:', error)
    }
  }

  /**
   * Sort folders in tree order (parent followed by children)
   * Copied from popup.js to maintain consistent folder ordering
   */
  sortFoldersInTreeOrder(folders) {
    // Create a map of folders by ID for quick lookup
    const folderMap = new Map()
    folders.forEach(folder => folderMap.set(folder.id, { ...folder }))

    // Find folder with first_position = 1
    const firstPositionFolder = folders.find(f => f.first_position === 1 || f.first_position === '1')

    // Build tree structure - group children by parent_id
    const childrenMap = new Map()
    folders.forEach(folder => {
      const parentId = folder.parent_id || 0
      if (!childrenMap.has(parentId)) {
        childrenMap.set(parentId, [])
      }
      childrenMap.get(parentId).push(folder)
    })

    // Sort children alphabetically within each parent
    childrenMap.forEach(children => {
      children.sort((a, b) => a.label.localeCompare(b.label))
    })

    // Function to get all descendants of a folder with level tracking
    function getAllDescendants(folderId, level, excludeIds = new Set()) {
      const descendants = []
      const children = childrenMap.get(folderId) || []

      children.forEach(child => {
        if (!excludeIds.has(child.id)) {
          child.level = level
          descendants.push(child)
          descendants.push(...getAllDescendants(child.id, level + 1, excludeIds))
        }
      })

      return descendants
    }

    // If there's a first_position folder, collect it and all its descendants
    const firstPositionBranch = []
    const excludeIds = new Set()

    if (firstPositionFolder) {
      firstPositionFolder.level = 0
      firstPositionBranch.push(firstPositionFolder)
      excludeIds.add(firstPositionFolder.id)

      // Get all descendants of the first_position folder
      const descendants = getAllDescendants(firstPositionFolder.id, 1)
      firstPositionBranch.push(...descendants)

      // Mark all descendants to exclude from main tree
      descendants.forEach(desc => excludeIds.add(desc.id))
    }

    // Traverse tree in depth-first order (parent, then children, then grandchildren...)
    // but exclude the first_position branch
    const result = []

    function traverse(parentId, level) {
      const children = childrenMap.get(parentId) || []
      children.forEach(folder => {
        if (!excludeIds.has(folder.id)) {
          folder.level = level
          result.push(folder)
          traverse(folder.id, level + 1) // Recursively add children
        }
      })
    }

    // Start with root folders (parent_id = 0 or null)
    traverse(0, 0)

    // Also handle folders with null parent_id
    if (childrenMap.has(null)) {
      childrenMap.get(null).forEach(folder => {
        if (!excludeIds.has(folder.id)) {
          folder.level = 0
          result.push(folder)
          traverse(folder.id, 1)
        }
      })
    }

    // Return first_position branch first, then the rest
    return [...firstPositionBranch, ...result]
  }

  /**
   * Load writable folders
   */
  async loadWritableFolders() {
    try {
      debugLog('🔐 [SaveModes] Sending getWritableFolders message...')
      const response = await chrome.runtime.sendMessage({
        action: 'getWritableFolders'
      })

      debugLog('🔐 [SaveModes] getWritableFolders response:', response)

      if (response.success) {
        const folders = response.data || []
        debugLog('🔐 [SaveModes] Folders loaded successfully:', folders.length, 'folders')
        return folders
      } else {
        throw new Error(response.error || 'Failed to load folders')
      }
    } catch (error) {
      console.error('🔐 [SaveModes] Error loading folders:', error)
      return []
    }
  }
}

// Create global instance
const saveModesHandler = new SaveModesHandler()

// Export for use in popup.js
if (typeof window !== 'undefined') {
  window.saveModesHandler = saveModesHandler
}
