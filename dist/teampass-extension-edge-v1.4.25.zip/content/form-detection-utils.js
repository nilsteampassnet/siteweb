/**
 * Extension Name: Teampass Manager Extension
 * Copyright (c) 2026, LogCarré. All Rights Reserved.
 *
 * This code is proprietary software. It is distributed on a non-public,
 * limited-use basis under the terms of a Commercial License.
 *
 * Unauthorized copying, modification, redistribution, or reverse engineering
 * of this code, or any part thereof, is strictly prohibited.
 */

/**
 * Teampass Form Detection Utilities
 *
 * Shared utilities for detecting login forms and fields
 * Used by both content-script.js and credential-detector.js
 */

/**
 * Check if an element is visible
 * Also checks parent containers (important for tabs/modals)
 *
 * @param {HTMLElement} element - Element to check
 * @returns {boolean} True if visible
 */
function isVisible(element) {
  if (!element) return false

  // Check element itself
  const style = window.getComputedStyle(element)

  if (style.display === 'none' ||
      style.visibility === 'hidden' ||
      style.opacity === '0' ||
      element.offsetWidth === 0 ||
      element.offsetHeight === 0) {
    return false
  }

  // Check parent containers up to 10 levels
  // This is crucial for tabs/panels that may hide entire sections
  let parent = element.parentElement
  for (let i = 0; i < 10 && parent && parent !== document.body; i++) {
    const parentStyle = window.getComputedStyle(parent)

    // Check if parent is hidden
    if (parentStyle.display === 'none' ||
        parentStyle.visibility === 'hidden') {
      return false
    }

    // Special handling for tab panels:
    // If parent is a tab panel WITHOUT is-active/show/active class, it's hidden
    if (parent.classList.contains('tabs__panel') ||
        parent.classList.contains('tab-panel') ||
        parent.classList.contains('tab-pane') ||
        parent.getAttribute('role') === 'tabpanel') {

      // Tab panel must have one of these active classes to be visible
      const isActiveTab = parent.classList.contains('is-active') ||
                          parent.classList.contains('active') ||
                          parent.classList.contains('show')

      if (!isActiveTab && parentStyle.display === 'none') {
        return false
      }
    }

    parent = parent.parentElement
  }

  return true
}

/**
 * Check if a field is a newsletter/subscribe field
 *
 * @param {HTMLInputElement} field - Field to check
 * @returns {boolean} True if field is newsletter/subscribe
 */
function isNewsletterField(field) {
  if (!field) return false

  // Check field attributes for newsletter/subscribe indicators
  const name = (field.name || '').toLowerCase()
  const id = (field.id || '').toLowerCase()
  const placeholder = (field.placeholder || '').toLowerCase()
  const ariaLabel = (field.getAttribute('aria-label') || '').toLowerCase()
  const ariaLabelledBy = (field.getAttribute('aria-labelledby') || '').toLowerCase()
  const dataAttrs = Array.from(field.attributes)
    .filter(attr => attr.name.startsWith('data-'))
    .map(attr => attr.value.toLowerCase())
    .join(' ')

  const allText = `${name} ${id} ${placeholder} ${ariaLabel} ${ariaLabelledBy} ${dataAttrs}`

  // Check for newsletter/subscribe keywords
  const newsletterPatterns = /newsletter|subscribe|subscription|signup|sign-up|join/i

  return newsletterPatterns.test(allText)
}

/**
 * Check if a field is in a registration/signup form context
 * This helps exclude signup forms when looking for login forms
 *
 * @param {HTMLInputElement} field - Field to check
 * @returns {boolean} True if field is in a registration context
 */
function isInRegistrationContext(field) {
  if (!field) return false

  /**
   * Helper function to check if text indicates registration context
   * Returns false if text contains both login AND signup indicators (likely a toggle/switch)
   */
  function isRegistrationText(text) {
    if (!text) return false

    const hasLogin = /\blogin\b|\bsign-?in\b|\bconnexion\b/i.test(text)
    const hasRegister = /\bregister\b|\bsignup\b|\bsign-?up\b|\binscription\b|\bcreate.*account\b|\bnew.*account\b/i.test(text)

    // If it has BOTH login and register keywords, it's likely a toggle/switch, not a pure registration form
    if (hasLogin && hasRegister) {
      debugLog('Field has BOTH login and register keywords (toggle/switch), not excluding:', text)
      return false
    }

    // Only register keywords = registration context
    return hasRegister
  }

  // Check field attributes
  const name = (field.name || '').toLowerCase()
  const id = (field.id || '').toLowerCase()
  const className = (field.className || '').toLowerCase()

  // Strong indicators in field attributes (but exclude if also has login keywords)
  if (isRegistrationText(`${name} ${id} ${className}`)) {
    debugLog('Field is in registration context (field attributes):', {
      name: field.name,
      id: field.id,
      className: field.className
    })
    return true
  }

  // Check parent form/container attributes
  const form = field.closest('form')
  if (form) {
    const formAction = (form.action || '').toLowerCase()
    const formClass = (form.className || '').toLowerCase()
    const formId = (form.id || '').toLowerCase()
    const formName = (form.name || '').toLowerCase()

    if (isRegistrationText(`${formAction} ${formClass} ${formId} ${formName}`)) {
      debugLog('Field is in registration context (form):', {
        action: formAction,
        class: formClass,
        id: formId
      })
      return true
    }
  }

  // Check parent containers (for formless contexts)
  // IMPORTANT: Check data-tab-id first as it's the most reliable indicator
  let parent = field.parentElement
  for (let i = 0; i < 5 && parent; i++) {
    const dataTab = (parent.getAttribute('data-tab-id') || '').toLowerCase()
    const dataPanel = (parent.getAttribute('data-panel') || '').toLowerCase()

    // Priority check: data-tab-id is the most reliable indicator for tab-based UIs
    if (dataTab === 'register' || dataPanel === 'register') {
      debugLog('Field is in registration context (data-tab):', {
        dataTab: dataTab,
        dataPanel: dataPanel
      })
      return true
    }

    // If data-tab-id explicitly says "login", it's NOT a registration form
    if (dataTab === 'login' || dataPanel === 'login') {
      debugLog('Field is in LOGIN context (data-tab), ignoring parent containers:', {
        dataTab: dataTab,
        dataPanel: dataPanel
      })
      return false // Explicitly NOT a registration form
    }

    parent = parent.parentElement
  }

  // Secondary check: Look for registration keywords in container classes/ids
  // But only if no explicit tab indicator was found
  parent = field.parentElement
  for (let i = 0; i < 3 && parent; i++) { // Reduced to 3 levels to avoid false positives
    const parentClass = (parent.className || '').toLowerCase()
    const parentId = (parent.id || '').toLowerCase()

    // Only check if this parent doesn't have BOTH login and register (avoid generic containers)
    if (isRegistrationText(`${parentClass} ${parentId}`)) {
      debugLog('Field is in registration context (container class/id):', {
        class: parentClass,
        id: parentId
      })
      return true
    }

    parent = parent.parentElement
  }

  return false
}

/**
 * Calculate a score for a username field candidate
 * Higher score = better match for a login username field
 *
 * @param {HTMLInputElement} field - Field to score
 * @param {HTMLInputElement|null} passwordField - Password field for proximity scoring
 * @returns {number} Score (0 = invalid, higher = better)
 */
function calculateUsernameFieldScore(field, passwordField = null) {
  if (!field) return 0

  // Exclude newsletter fields completely
  if (isNewsletterField(field)) return 0

  // Exclude registration/signup forms (we want LOGIN forms only)
  if (isInRegistrationContext(field)) {
    debugLog('Username candidate excluded (registration context):', {
      name: field.name,
      id: field.id
    })
    return 0
  }

  // Must be visible
  if (!isVisible(field)) return 0

  // Must be acceptable input type (text, email, tel)
  const acceptableTypes = ['text', 'email', 'tel', '']
  if (!acceptableTypes.includes(field.type)) return 0

  let score = 0

  // Collect all field attributes for pattern matching
  const name = (field.name || '').toLowerCase()
  const id = (field.id || '').toLowerCase()
  const placeholder = (field.placeholder || '').toLowerCase()
  const className = (field.className || '').toLowerCase()
  const autocomplete = (field.autocomplete || '').toLowerCase()
  const attributes = `${name} ${id} ${placeholder} ${className}`

  // SCORING RULES (in order of importance):

  // 1. Autocomplete attribute (HIGHEST priority) +100
  if (autocomplete === 'username' || autocomplete === 'email') {
    score += 100
  }

  // 2. Strong keyword matches in attributes +50
  if (/\b(user|username|login|email|mail|identifiant)\b/i.test(attributes)) {
    score += 50
  }

  // 3. Field type bonus
  if (field.type === 'email') {
    score += 30 // Email fields are very likely username fields
  } else if (field.type === 'tel') {
    score += 10 // Tel fields can be used for phone-based login
  }

  // 4. DOM proximity to password field +20
  if (passwordField) {
    try {
      const position = field.compareDocumentPosition(passwordField)
      // Check if field is BEFORE password field in DOM (DOCUMENT_POSITION_FOLLOWING = 4)
      if (position & Node.DOCUMENT_POSITION_FOLLOWING) {
        score += 20
      }
    } catch (e) {
      // compareDocumentPosition can throw in some edge cases
      debugLog('Could not compare field positions:', e)
    }
  }

  // 5. Exact name/id matches +15
  if (name === 'username' || id === 'username' ||
      name === 'login' || id === 'login' ||
      name === 'email' || id === 'email') {
    score += 15
  }

  // 6. Weaker pattern matches +5
  if (/user|login|email/i.test(attributes) && score === 0) {
    score += 5
  }

  return score
}

/**
 * Find username field within a specific container or in the entire document
 * Uses intelligent scoring system to select the best candidate
 *
 * @param {HTMLElement|null} container - Container to search in (form, div, etc.), or null to search entire document
 * @returns {HTMLInputElement|null} Username field or null
 */
function findUsernameFieldInContext(container = null) {
  const searchContext = container || document

  // First, find the password field for proximity scoring
  const passwordField = findPasswordFieldInContext(container)

  // Collect all potential username field candidates (text, email, tel)
  const candidates = Array.from(
    searchContext.querySelectorAll('input[type="text"], input[type="email"], input[type="tel"], input:not([type])')
  )

  if (candidates.length === 0) {
    debugLog('No username field candidates found')
    return null
  }

  // Score all candidates
  let bestScore = -1
  let bestField = null

  for (const field of candidates) {
    const score = calculateUsernameFieldScore(field, passwordField)

    debugLog(`Username candidate score: ${score}`, {
      name: field.name,
      id: field.id,
      type: field.type,
      autocomplete: field.autocomplete
    })

    if (score > bestScore) {
      bestScore = score
      bestField = field
    }
  }

  if (bestField && bestScore > 0) {
    debugLog(`✅ Best username field found (score: ${bestScore}):`, {
      name: bestField.name,
      id: bestField.id,
      type: bestField.type,
      autocomplete: bestField.autocomplete
    })
    return bestField
  }

  debugLog('No valid username field found (all candidates scored 0)')
  return null
}

/**
 * Find password field within a specific container or in the entire document
 * Excludes registration/signup form password fields
 *
 * @param {HTMLElement|null} container - Container to search in (form, div, etc.), or null to search entire document
 * @returns {HTMLInputElement|null} Password field or null
 */
function findPasswordFieldInContext(container = null) {
  const searchContext = container || document

  // Priority 1: Fields with autocomplete="current-password" (LOGIN forms)
  const priorityFields = searchContext.querySelectorAll('input[type="password"][autocomplete="current-password"]')
  for (const field of priorityFields) {
    if (isVisible(field) && !isInRegistrationContext(field)) {
      debugLog('Found password field (priority): autocomplete="current-password"')
      return field
    }
  }

  // Priority 2: Any password field with autocomplete (but not "new-password")
  const autocompleteFields = searchContext.querySelectorAll('input[type="password"][autocomplete]')
  for (const field of autocompleteFields) {
    if (field.autocomplete !== 'new-password' && isVisible(field) && !isInRegistrationContext(field)) {
      debugLog('Found password field (autocomplete):', field.autocomplete)
      return field
    }
  }

  // Priority 3: Password fields with common name/id patterns (login-related)
  const commonSelectors = [
    'input[type="password"][name*="login" i]',
    'input[type="password"][name*="password" i]',
    'input[type="password"][name*="pass" i]',
    'input[type="password"][id*="login" i]',
    'input[type="password"][id*="password" i]',
    'input[type="password"][id*="pass" i]'
  ]

  for (const selector of commonSelectors) {
    const fields = searchContext.querySelectorAll(selector)
    for (const field of fields) {
      if (isVisible(field) && !isInRegistrationContext(field)) {
        debugLog('Found password field (common pattern):', selector)
        return field
      }
    }
  }

  // Priority 4: Any visible password field (excluding "new-password" autocomplete AND registration context)
  const allPasswordFields = searchContext.querySelectorAll('input[type="password"]')
  for (const field of allPasswordFields) {
    if (field.autocomplete !== 'new-password' && isVisible(field) && !isInRegistrationContext(field)) {
      debugLog('Found password field (standard)')
      return field
    }
  }

  // Priority 5: Last resort - any visible password field (still exclude registration)
  for (const field of allPasswordFields) {
    if (isVisible(field) && !isInRegistrationContext(field)) {
      debugLog('Found password field (last resort, non-registration)')
      return field
    }
  }

  return null
}

/**
 * Check if a form/container has both username and password fields
 * Works with both traditional <form> elements and formless login pages
 *
 * @param {HTMLElement|null} container - Container to check (form, div, etc.), or null to check entire document
 * @returns {boolean} True if login form detected
 */
function hasLoginFormInContext(container = null) {
  const usernameField = findUsernameFieldInContext(container)
  const passwordField = findPasswordFieldInContext(container)

  const hasForm = !!(usernameField && passwordField)

  if (hasForm) {
    debugLog('✅ Login form detected in context:', container?.tagName || 'document')
  } else {
    debugLog('❌ No login form in context:', container?.tagName || 'document')
  }

  return hasForm
}

/**
 * Capture credentials from a form or from the entire page
 *
 * @param {HTMLElement|null} container - Container to search in, or null for entire document
 * @returns {object|null} Captured credentials {username, password, url, domain, timestamp}
 */
function captureCredentialsFromContext(container = null) {
  const usernameField = findUsernameFieldInContext(container)
  const passwordField = findPasswordFieldInContext(container)

  if (!usernameField || !passwordField) {
    debugLog('❌ Cannot capture credentials - missing fields')
    return null
  }

  const username = usernameField.value.trim()
  const password = passwordField.value // Don't trim password

  if (!username || !password) {
    debugLog('❌ Cannot capture credentials - empty values')
    return null
  }

  debugLog('✅ Credentials captured:', { username, hasPassword: !!password })

  return {
    username,
    password,
    url: window.location.href,
    domain: window.location.hostname,
    timestamp: Date.now()
  }
}
