/**
 * Extension Name: Teampass Manager Extension
 * Copyright (c) 2026, LogCarré. All Rights Reserved.
 *
 * This code is proprietary software. It is distributed on a non-public, 
 * limited-use basis under the terms of a Commercial License.
 *
 * Unauthorized copying, modification, redistribution, or reverse engineering 
 * of this code, or any part thereof, is strictly prohibited.
 */

/**
 * Teampass Browser Extension - Content Script
 *
 * This script runs in the context of web pages and handles:
 * - Auto-filling login forms
 * - Detecting login form fields
 * - Communicating with the extension popup
 */

debugLog('Teampass content script loaded')

// Global state for autofill markers
const autofillState = {
  currentDomain: null,
  availableItems: [],
  selectedItemId: null,
  markers: [],
  activeDropdown: null,
  listenersAdded: false,
  observer: null,
  isInitializing: false,
  lastReinitAttempt: 0,          // Timestamp of last reinitialization attempt
  consecutiveFailures: 0,         // Count of consecutive failed attempts
  maxConsecutiveFailures: 3      // Stop after this many failed attempts
}

/**
 * Find the closest parent container between two elements
 *
 * @param {HTMLElement} element - Element to search from
 * @param {number} maxLevels - Maximum number of parent levels to search
 * @returns {HTMLElement} Parent element
 */
function getCommonContainer(element, maxLevels = 5) {
  let parent = element
  for (let i = 0; i < maxLevels && parent.parentElement; i++) {
    parent = parent.parentElement
  }
  return parent
}

/**
 * Find username/email input field on the page
 * New approach: Find password field first, then look for username nearby
 *
 * @returns {HTMLInputElement|null} Username field or null
 */
function findUsernameField() {
  // Strategy 1: Find username field near a password field (most reliable)
  const passwordField = findPasswordField()
  if (passwordField) {
    // Look for username field in the same form
    const form = passwordField.closest('form')
    if (form) {
      const usernameInForm = findUsernameInContainer(form)
      if (usernameInForm) {
        debugLog('Found username field (near password in form)')
        return usernameInForm
      }
    }

    // Look for username field in same parent container
    const container = getCommonContainer(passwordField, 3)
    const usernameInContainer = findUsernameInContainer(container)
    if (usernameInContainer) {
      debugLog('Found username field (near password in container)')
      return usernameInContainer
    }
  }

  // Strategy 2: Try selectors in order of priority
  // Priority 1: Fields with autocomplete="username" or autocomplete="email"
  const prioritySelectors = [
    'input[autocomplete="username"]',
    'input[autocomplete="email"]',
    'input[type="email"][autocomplete*="email"]',
    'input[type="text"][autocomplete*="username"]'
  ]

  // Try priority selectors first
  for (const selector of prioritySelectors) {
    const fields = document.querySelectorAll(selector)
    for (const field of fields) {
      if (isVisible(field)) {
        debugLog('Found username field (priority):', selector)
        return field
      }
    }
  }

  // Strategy 3: Common name/id patterns
  const commonSelectors = [
    'input[type="email"]',
    'input[name="username"]',
    'input[name="email"]',
    'input[name="login"]',
    'input[id="username"]',
    'input[id="email"]',
    'input[id="login"]',
    'input[type="text"][name*="user" i]',
    'input[type="text"][name*="login" i]',
    'input[type="text"][name*="email" i]',
    'input[type="text"][id*="user" i]',
    'input[type="text"][id*="login" i]',
    'input[type="text"][id*="email" i]'
  ]

  // Try common selectors
  for (const selector of commonSelectors) {
    const fields = document.querySelectorAll(selector)
    for (const field of fields) {
      if (isVisible(field)) {
        debugLog('Found username field (common):', selector)
        return field
      }
    }
  }

  // Strategy 4: Fallback - find first visible text/email input in a form
  const forms = document.querySelectorAll('form')
  for (const form of forms) {
    if (!isVisible(form)) continue

    const textInputs = form.querySelectorAll('input[type="text"], input[type="email"]')
    for (const input of textInputs) {
      if (isVisible(input)) {
        debugLog('Found username field (fallback in form)')
        return input
      }
    }
  }

  return null
}

/**
 * Check if a field is a newsletter/subscribe field
 *
 * @param {HTMLInputElement} field - Field to check
 * @returns {boolean} True if field is newsletter/subscribe
 */
function isNewsletterField(field) {
  if (!field) return false

  // Check field attributes for newsletter/subscribe indicators
  const name = (field.name || '').toLowerCase()
  const id = (field.id || '').toLowerCase()
  const placeholder = (field.placeholder || '').toLowerCase()
  const ariaLabel = (field.getAttribute('aria-label') || '').toLowerCase()
  const ariaLabelledBy = (field.getAttribute('aria-labelledby') || '').toLowerCase()
  const dataAttrs = Array.from(field.attributes)
    .filter(attr => attr.name.startsWith('data-'))
    .map(attr => attr.value.toLowerCase())
    .join(' ')

  const allText = `${name} ${id} ${placeholder} ${ariaLabel} ${ariaLabelledBy} ${dataAttrs}`

  // Check for newsletter/subscribe keywords
  const newsletterPatterns = /newsletter|subscribe|subscription|signup|sign-up|join/i

  return newsletterPatterns.test(allText)
}

/**
 * Find username field within a container
 *
 * @param {HTMLElement} container - Container to search in
 * @returns {HTMLInputElement|null} Username field or null
 */
function findUsernameInContainer(container) {
  if (!container) return null

  // Priority 1: Semantic autocomplete (but NOT newsletter fields)
  const prioritySelectors = [
    'input[autocomplete="username"]',
    'input[autocomplete="email"]'
  ]

  for (const selector of prioritySelectors) {
    const field = container.querySelector(selector)
    if (field && isVisible(field) && !isNewsletterField(field)) {
      return field
    }
  }

  // Priority 2: Common login patterns (specific names/ids)
  const commonSelectors = [
    'input[name="username"]',
    'input[name="login"]',
    'input[id="username"]',
    'input[id="login"]',
    'input[name*="username" i]',
    'input[name*="loginuser" i]',
    'input[name*="user_name" i]',
    'input[id*="username" i]',
    'input[id*="loginuser" i]'
  ]

  for (const selector of commonSelectors) {
    const field = container.querySelector(selector)
    if (field && isVisible(field) && (field.type === 'text' || field.type === 'email') && !isNewsletterField(field)) {
      return field
    }
  }

  // Priority 3: Email fields (but NOT newsletter fields)
  const emailSelectors = [
    'input[name="email"]',
    'input[id="email"]',
    'input[type="email"]'
  ]

  for (const selector of emailSelectors) {
    const field = container.querySelector(selector)
    if (field && isVisible(field) && !isNewsletterField(field)) {
      return field
    }
  }

  // Priority 4: Generic user/login patterns
  const genericSelectors = [
    'input[name*="user" i]',
    'input[name*="login" i]',
    'input[id*="user" i]',
    'input[id*="login" i]'
  ]

  for (const selector of genericSelectors) {
    const field = container.querySelector(selector)
    if (field && isVisible(field) && (field.type === 'text' || field.type === 'email') && !isNewsletterField(field)) {
      return field
    }
  }

  // Priority 5: First text input (but NOT newsletter)
  const allInputs = Array.from(container.querySelectorAll('input[type="text"], input[type="email"]'))
  for (const input of allInputs) {
    if (isVisible(input) && !isNewsletterField(input)) {
      return input
    }
  }

  return null
}

/**
 * Find password input field on the page
 * Prioritizes fields with autocomplete="current-password" and those in viewport
 *
 * @returns {HTMLInputElement|null} Password field or null
 */
function findPasswordField() {
  // Priority 1: Fields with autocomplete="current-password"
  const priorityFields = document.querySelectorAll('input[type="password"][autocomplete="current-password"]')
  for (const field of priorityFields) {
    if (isVisible(field)) {
      debugLog('Found password field (priority): autocomplete="current-password"')
      return field
    }
  }

  // Priority 2: Any password field with autocomplete (but not "new-password")
  const autocompleteFields = document.querySelectorAll('input[type="password"][autocomplete]')
  for (const field of autocompleteFields) {
    if (field.autocomplete !== 'new-password' && isVisible(field)) {
      debugLog('Found password field (autocomplete):', field.autocomplete)
      return field
    }
  }

  // Priority 3: Password fields with common name/id patterns (login-related)
  const commonSelectors = [
    'input[type="password"][name*="login" i]',
    'input[type="password"][name*="password" i]',
    'input[type="password"][name*="pass" i]',
    'input[type="password"][id*="login" i]',
    'input[type="password"][id*="password" i]',
    'input[type="password"][id*="pass" i]'
  ]

  for (const selector of commonSelectors) {
    const field = document.querySelector(selector)
    if (field && isVisible(field)) {
      debugLog('Found password field (common pattern):', selector)
      return field
    }
  }

  // Priority 4: Any visible password field (excluding "new-password" autocomplete)
  const allPasswordFields = document.querySelectorAll('input[type="password"]')
  for (const field of allPasswordFields) {
    if (field.autocomplete !== 'new-password' && isVisible(field)) {
      debugLog('Found password field (standard)')
      return field
    }
  }

  // Priority 5: Last resort - any password field at all
  for (const field of allPasswordFields) {
    if (isVisible(field)) {
      debugLog('Found password field (last resort)')
      return field
    }
  }

  return null
}

/**
 * Check if an element is visible on the page
 *
 * @param {HTMLElement} element - Element to check
 * @returns {boolean} True if visible
 */
function isVisible(element) {
  if (!element) return false

  const style = window.getComputedStyle(element)

  return (
    style.display !== 'none' &&
    style.visibility !== 'hidden' &&
    style.opacity !== '0' &&
    element.offsetWidth > 0 &&
    element.offsetHeight > 0
  )
}

/**
 * Check if an element is in or near the viewport
 * This helps avoid selecting hidden fields that are far off-screen
 *
 * @param {HTMLElement} element - Element to check
 * @returns {boolean} True if in viewport or reasonably close
 */
function isInViewportOrNear(element) {
  if (!element) return false

  const rect = element.getBoundingClientRect()
  const windowHeight = window.innerHeight || document.documentElement.clientHeight
  const windowWidth = window.innerWidth || document.documentElement.clientWidth

  // Allow elements that are up to 2x viewport height away (for long pages)
  const verticalMargin = windowHeight * 2
  const horizontalMargin = windowWidth

  return (
    rect.top < windowHeight + verticalMargin &&
    rect.bottom > -verticalMargin &&
    rect.left < windowWidth + horizontalMargin &&
    rect.right > -horizontalMargin
  )
}

/**
 * Check if a field is likely an OTP/TOTP field
 * Analyzes all field attributes and context
 *
 * @param {HTMLInputElement} field - Field to check
 * @returns {boolean} True if field appears to be OTP/TOTP
 */
function isOtpField(field) {
  if (!field) return false

  // Collect all field attributes
  const name = (field.name || '').toLowerCase()
  const id = (field.id || '').toLowerCase()
  const placeholder = (field.placeholder || '').toLowerCase()
  const ariaLabel = (field.getAttribute('aria-label') || '').toLowerCase()
  const ariaLabelledBy = (field.getAttribute('aria-labelledby') || '').toLowerCase()
  const title = (field.title || '').toLowerCase()
  const className = (field.className || '').toLowerCase()

  // Collect all data-* attributes - REPLACE dashes/underscores with spaces for better matching
  const dataAttrs = Array.from(field.attributes)
    .filter(attr => attr.name.startsWith('data-'))
    .map(attr => `${attr.name} ${attr.value}`.toLowerCase().replace(/[-_]/g, ' '))
    .join(' ')

  // Combine all text - also replace dashes/underscores with spaces
  const allText = `${name} ${id} ${placeholder} ${ariaLabel} ${ariaLabelledBy} ${title} ${className} ${dataAttrs}`
    .replace(/[-_]/g, ' ')

  // Check for OTP/TOTP patterns (very comprehensive)
  // Removed \b word boundaries to match within hyphenated/underscored text
  const otpPatterns = /(otp|totp|2fa|mfa|tfa|two.?factor|two.?step|verification.?code|authenticat(or|ion).?code|security.?code|confirm(ation)?.?code|one.?time|access.?code)/i

  if (otpPatterns.test(allText)) {
    debugLog('OTP field detected via attributes:', allText.substring(0, 100))
    return true
  }

  // Check context (labels, headers nearby)
  // Look for nearby labels or headers with OTP keywords
  const labelElement = field.labels?.[0] || document.querySelector(`label[for="${field.id}"]`)
  if (labelElement) {
    const labelText = labelElement.textContent.toLowerCase()
    if (otpPatterns.test(labelText)) {
      debugLog('OTP field detected via label:', labelText)
      return true
    }
  }

  // Check nearby headers AND siblings (important for namecheap structure)
  const nearbyHeaders = []

  // Check parent container for headers
  let parent = field.parentElement
  for (let i = 0; i < 5 && parent; i++) {
    // Check headers within this parent (including siblings of the field)
    const headers = parent.querySelectorAll('h1, h2, h3, h4, h5, h6, header, [class*="header"], [class*="title"], [class*="panel"]')
    headers.forEach(h => {
      const headerText = h.textContent.toLowerCase().trim()
      if (headerText) {
        nearbyHeaders.push(headerText)
      }
    })
    parent = parent.parentElement
  }

  const contextText = nearbyHeaders.join(' ')
  if (otpPatterns.test(contextText)) {
    debugLog('OTP field detected via context:', contextText.substring(0, 100))
    return true
  }

  return false
}

/**
 * Find OTP/TOTP input field on the page
 * Detects common OTP field patterns
 *
 * @returns {HTMLInputElement|null} OTP field or null
 */
function findOtpField() {
  // Strategy 1: Check all visible input fields with isOtpField()
  const allInputs = document.querySelectorAll('input')

  for (const field of allInputs) {
    if (isVisible(field) && isOtpField(field)) {
      debugLog('Found OTP field (comprehensive detection):', field.type, field.name || field.id || field.placeholder)
      return field
    }
  }

  // Strategy 2 (fallback): Specific selectors with autocomplete
  const prioritySelectors = [
    'input[autocomplete="one-time-code"]',
    'input[autocomplete*="one-time-code"]'
  ]

  for (const selector of prioritySelectors) {
    const field = document.querySelector(selector)
    if (field && isVisible(field)) {
      debugLog('Found OTP field (autocomplete):', selector)
      return field
    }
  }

  // Strategy 3 (fallback): Common OTP name/id patterns
  const commonSelectors = [
    'input[name="otp"]',
    'input[name="totp"]',
    'input[name="code"]',
    'input[name="token"]',
    'input[id="otp"]',
    'input[id="totp"]',
    'input[id="code"]',
    'input[id="token"]'
  ]

  for (const selector of commonSelectors) {
    const field = document.querySelector(selector)
    if (field && isVisible(field)) {
      debugLog('Found OTP field (common name/id):', selector)
      return field
    }
  }

  return null
}

/**
 * Fill login form with provided credentials
 *
 * @param {string} username - Username/email to fill
 * @param {string} password - Password to fill
 * @returns {boolean} True if form was filled successfully
 */
function fillLoginForm(username, password) {
  const usernameField = findUsernameField()
  const passwordField = findPasswordField()
  
  let filled = false
  
  if (usernameField && username) {
    // Set value
    usernameField.value = username

    // Trigger events to ensure the page detects the change
    usernameField.dispatchEvent(new Event('input', { bubbles: true }))
    usernameField.dispatchEvent(new Event('change', { bubbles: true }))

    // Focus and blur to trigger validation
    usernameField.focus()
    usernameField.blur()

    filled = true
    debugLog('Username field filled')
  } else if (!usernameField) {
    debugLog('Username field not found (password-only form)')
  }
  
  if (passwordField && password) {
    // Set value
    passwordField.value = password
    
    // Trigger events
    passwordField.dispatchEvent(new Event('input', { bubbles: true }))
    passwordField.dispatchEvent(new Event('change', { bubbles: true }))
    
    // Focus and blur
    passwordField.focus()
    passwordField.blur()

    filled = true
    debugLog('Password field filled')
  } else {
    console.warn('Password field not found')
  }
  
  return filled
}

/**
 * Detect login forms on the page
 *
 * @returns {boolean} True if login form detected
 */
function hasLoginForm() {
  const usernameField = findUsernameField()
  const passwordField = findPasswordField()

  return !!(usernameField && passwordField)
}

/**
 * Get current values from login form fields on the page
 * Returns the values only if they are non-empty
 *
 * @returns {object} Object with username and password values (or null if empty)
 */
function getLoginFormValues() {
  const usernameField = findUsernameField()
  const passwordField = findPasswordField()

  const result = {
    username: null,
    password: null
  }

  // Only return username if field exists and has a non-empty value
  if (usernameField && usernameField.value && usernameField.value.trim() !== '') {
    result.username = usernameField.value.trim()
  }

  // Only return password if field exists and has a non-empty value
  if (passwordField && passwordField.value && passwordField.value.trim() !== '') {
    result.password = passwordField.value.trim()
  }

  return result
}

/**
 * Get current page domain (protocol + hostname)
 *
 * @returns {string} Current domain URL
 */
function getCurrentDomain() {
  try {
    const url = new URL(window.location.href)
    return `${url.protocol}//${url.hostname}`
  } catch (error) {
    console.error('Error getting current domain:', error)
    return null
  }
}

/**
 * Create SVG icon for autofill marker
 *
 * @param {string} type - Type of marker ('login' or 'totp')
 * @returns {SVGElement} SVG icon element
 */
function createMarkerIcon(type) {
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg')
  svg.setAttribute('viewBox', '0 0 24 24')
  svg.setAttribute('fill', 'white')

  if (type === 'totp') {
    // Clock icon for TOTP
    svg.innerHTML = '<path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm.5-13H11v6l5.2 3.2.8-1.3-4.5-2.7V7z"/>'
  } else {
    // User/person icon for login (distinguishes from password generator key icon)
    svg.innerHTML = '<path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>'
  }

  return svg
}

/**
 * Create autofill marker element
 *
 * @param {HTMLInputElement} field - Input field to attach marker to
 * @param {string} type - Type of marker ('login' or 'totp')
 * @returns {HTMLElement} Marker element
 */
function createMarker(field, type) {
  const marker = document.createElement('div')
  marker.className = `teampass-autofill-marker${type === 'totp' ? ' totp' : ''}`
  marker.setAttribute('data-teampass-marker', type)
  marker.setAttribute('title', type === 'totp' ? i18n.t('content.autofill.autoFillTotp') : i18n.t('content.autofill.autoFillLogin'))

  const icon = createMarkerIcon(type)
  marker.appendChild(icon)

  // Position marker next to field
  positionMarker(marker, field)

  // Add click handler
  marker.addEventListener('click', (e) => {
    e.preventDefault()
    e.stopPropagation()
    showDropdown(marker, field, type)
  })

  return marker
}

/**
 * Position marker next to input field (on the right side)
 *
 * @param {HTMLElement} marker - Marker element
 * @param {HTMLInputElement} field - Input field
 */
function positionMarker(marker, field) {
  const rect = field.getBoundingClientRect()
  const scrollTop = window.pageYOffset || document.documentElement.scrollTop
  const scrollLeft = window.pageXOffset || document.documentElement.scrollLeft

  marker.style.position = 'absolute'
  marker.style.top = `${rect.top + scrollTop + (rect.height - 24) / 2}px`
  // Position inside the field, aligned to the right (marker width = 24px, margin = 5px)
  marker.style.left = `${rect.right + scrollLeft - 29}px`
  marker.style.zIndex = '999999'
}

/**
 * Update marker positions when page scrolls or resizes
 */
function updateMarkerPositions() {
  autofillState.markers.forEach(({ marker, field }) => {
    if (isVisible(field)) {
      positionMarker(marker, field)
      marker.style.display = 'flex'
    } else {
      marker.style.display = 'none'
    }
  })
}

/**
 * Create dropdown menu for item selection
 *
 * @param {HTMLElement} marker - Marker element
 * @param {string} type - Type of marker ('login' or 'totp')
 * @returns {HTMLElement} Dropdown element
 */
function createDropdown(marker, type) {
  const dropdown = document.createElement('div')
  dropdown.className = 'teampass-autofill-dropdown'

  // Position dropdown below marker
  const rect = marker.getBoundingClientRect()
  const scrollTop = window.pageYOffset || document.documentElement.scrollTop
  const scrollLeft = window.pageXOffset || document.documentElement.scrollLeft

  dropdown.style.position = 'absolute'
  dropdown.style.top = `${rect.bottom + scrollTop + 5}px`
  dropdown.style.left = `${rect.left + scrollLeft - 220}px`
  dropdown.style.zIndex = '1000000'

  // Add header
  const header = document.createElement('div')
  header.className = 'teampass-autofill-dropdown-header'

  // Add icon
  const icon = createMarkerIcon(type)
  header.appendChild(icon)

  // Add text
  const headerText = document.createElement('span')
  headerText.textContent = type === 'totp' ? i18n.t('content.autofill.selectTotpSource') : i18n.t('content.autofill.selectLoginToFill')
  header.appendChild(headerText)

  dropdown.appendChild(header)

  return dropdown
}

/**
 * Generate a visual match score badge for autofill dropdown
 * Returns a discrete badge indicating the quality of the URL match
 *
 * @param {number} score - Match score (0-100)
 * @returns {HTMLElement|null} Badge element or null if no score
 */
function getMatchScoreBadge(score) {
  if (typeof score !== 'number' || score <= 0) {
    return null // No badge if no score
  }

  let badgeClass = ''
  let badgeSymbol = ''
  let badgeTitle = ''

  if (score >= 95) {
    badgeClass = 'match-perfect'
    badgeSymbol = '●'
    badgeTitle = i18n.t('content.autofill.perfectMatch', { score: Math.round(score) })
  } else if (score >= 70) {
    badgeClass = 'match-good'
    badgeSymbol = '●'
    badgeTitle = i18n.t('content.autofill.goodMatch', { score: Math.round(score) })
  } else if (score >= 50) {
    badgeClass = 'match-medium'
    badgeSymbol = '●'
    badgeTitle = i18n.t('content.autofill.mediumMatch', { score: Math.round(score) })
  } else {
    badgeClass = 'match-weak'
    badgeSymbol = '○'
    badgeTitle = i18n.t('content.autofill.weakMatch', { score: Math.round(score) })
  }

  const sup = document.createElement('sup')
  sup.className = `teampass-match-badge ${badgeClass}`
  sup.title = badgeTitle
  sup.textContent = badgeSymbol
  return sup
}

/**
 * Show dropdown with available items
 *
 * @param {HTMLElement} marker - Marker element
 * @param {HTMLInputElement} field - Input field
 * @param {string} type - Type of marker ('login' or 'totp')
 */
async function showDropdown(marker, field, type) {
  // Close any existing dropdown
  if (autofillState.activeDropdown) {
    autofillState.activeDropdown.remove()
    autofillState.activeDropdown = null
  }

  const dropdown = createDropdown(marker, type)
  document.body.appendChild(dropdown)
  autofillState.activeDropdown = dropdown

  // Show loading state
  const loading = document.createElement('div')
  loading.className = 'teampass-autofill-dropdown-loading'

  const spinner = document.createElement('div')
  spinner.className = 'teampass-autofill-spinner'
  loading.appendChild(spinner)

  const loadingText = document.createTextNode(i18n.t('content.autofill.loadingItems'))
  loading.appendChild(loadingText)

  dropdown.appendChild(loading)

  // Show dropdown with animation
  setTimeout(() => dropdown.classList.add('show'), 10)

  try {
    // Get current URL and domain
    const currentUrl = window.location.href
    const domain = getCurrentDomain()
    if (!domain) {
      throw new Error(i18n.t('content.autofill.couldNotDetermineDomain'))
    }

    // Get items for current URL from service worker (using full URL for better scoring)
    const response = await chrome.runtime.sendMessage({
      action: 'getItemsForAutofill',
      data: { url: currentUrl }
    })

    if (!response.success) {
      throw new Error(response.error || i18n.t('content.autofill.failedToGetItems'))
    }

    const items = response.data || []
    autofillState.availableItems = items
    autofillState.currentDomain = domain

    // Remove loading state
    loading.remove()

    // Get selected item for this domain (if any)
    // Note: we use domain (not full URL) for selection memory
    const selectedResponse = await chrome.runtime.sendMessage({
      action: 'getSelectedItem',
      data: { domain }
    })
    const selectedItemId = selectedResponse.success ? selectedResponse.data : null

    if (items.length === 0) {
      const empty = document.createElement('div')
      empty.className = 'teampass-autofill-dropdown-empty'
      empty.textContent = i18n.t('content.autofill.noItemsFound')
      dropdown.appendChild(empty)
    } else {
      // Filter items based on type
      let filteredItems = items
      if (type === 'totp') {
        // Only show items with OTP configured
        filteredItems = items.filter(item => item.has_otp || item.otp_secret)
      }

      if (filteredItems.length === 0 && type === 'totp') {
        const empty = document.createElement('div')
        empty.className = 'teampass-autofill-dropdown-empty'
        empty.textContent = i18n.t('content.autofill.noTotpItems')
        dropdown.appendChild(empty)
      } else {
        // Display items
        filteredItems.forEach(item => {
          const itemEl = document.createElement('div')
          itemEl.className = 'teampass-autofill-dropdown-item'

          // Mark as selected if this was the previously selected item
          if (selectedItemId && item.id === selectedItemId) {
            itemEl.classList.add('selected')
          }

          // Create label span
          const labelSpan = document.createElement('span')
          labelSpan.className = 'teampass-autofill-item-label'
          labelSpan.textContent = item.label

          // Add match score badge if available
          const badge = getMatchScoreBadge(item._matchScore)
          if (badge) {
            labelSpan.appendChild(badge)
          }

          itemEl.appendChild(labelSpan)

          // Create login span
          const loginSpan = document.createElement('span')
          loginSpan.className = 'teampass-autofill-item-login'
          loginSpan.textContent = item.login || i18n.t('content.autofill.noLogin')
          itemEl.appendChild(loginSpan)

          // Create folder span if folder_label exists
          if (item.folder_label) {
            const folderSpan = document.createElement('span')
            folderSpan.className = 'teampass-autofill-item-folder'
            folderSpan.textContent = `📁 ${item.folder_label}`
            itemEl.appendChild(folderSpan)
          }

          itemEl.addEventListener('click', async (e) => {
            e.preventDefault()
            e.stopPropagation()
            await handleItemSelection(item, field, type, domain)
            dropdown.remove()
            autofillState.activeDropdown = null
          })

          dropdown.appendChild(itemEl)
        })
      }
    }
  } catch (error) {
    console.error('Error showing dropdown:', error)
    loading.remove()

    const errorEl = document.createElement('div')
    errorEl.className = 'teampass-autofill-dropdown-error'
    errorEl.textContent = `${i18n.t('content.autofill.error')} ${error.message}`
    dropdown.appendChild(errorEl)
  }

  // Close dropdown when clicking outside
  const closeHandler = (e) => {
    if (!dropdown.contains(e.target) && !marker.contains(e.target)) {
      dropdown.remove()
      autofillState.activeDropdown = null
      document.removeEventListener('click', closeHandler)
    }
  }
  setTimeout(() => document.addEventListener('click', closeHandler), 100)
}

/**
 * Handle item selection from dropdown
 *
 * @param {object} item - Selected item
 * @param {HTMLInputElement} field - Input field to fill
 * @param {string} type - Type of fill ('login' or 'totp')
 * @param {string} domain - Current domain
 */
async function handleItemSelection(item, field, type, domain) {
  debugLog('Item selected:', item.id, type)

  try {
    if (type === 'totp') {
      // Fill OTP field
      await fillOtpField(item, field)
    } else {
      // Fill login form
      await fillLoginFormFromItem(item, field)
    }

    // Save selected item for this domain
    await chrome.runtime.sendMessage({
      action: 'saveSelectedItem',
      data: { domain, itemId: item.id }
    })

    autofillState.selectedItemId = item.id
  } catch (error) {
    console.error('Error handling item selection:', error)
  }
}

/**
 * Fill login form with item data
 *
 * @param {object} item - Item with credentials
 * @param {HTMLInputElement} usernameField - Username field (optional)
 */
async function fillLoginFormFromItem(item, usernameField) {
  try {
    // Get item details including password
    const response = await chrome.runtime.sendMessage({
      action: 'getItemDetailsForAutofill',
      data: { itemId: item.id }
    })

    if (!response.success) {
      throw new Error(response.error || i18n.t('content.autofill.failedToGetItemDetails'))
    }

    const itemDetails = response.data

    // Fill form using existing fillLoginForm function
    const filled = fillLoginForm(itemDetails.login, itemDetails.pwd)

    if (filled) {
      debugLog('Login form filled successfully')
    }
  } catch (error) {
    console.error('Error filling login form:', error)
  }
}

/**
 * Fill OTP field with TOTP code
 *
 * @param {object} item - Item with OTP
 * @param {HTMLInputElement} otpField - OTP field
 */
async function fillOtpField(item, otpField) {
  try {
    // Get OTP code from service worker
    const response = await chrome.runtime.sendMessage({
      action: 'getOtpForAutofill',
      data: { itemId: item.id }
    })

    if (!response.success) {
      throw new Error(response.error || i18n.t('content.autofill.failedToGetOtpCode'))
    }

    const otpCode = response.data

    if (otpField && otpCode) {
      otpField.value = otpCode

      // Trigger events
      otpField.dispatchEvent(new Event('input', { bubbles: true }))
      otpField.dispatchEvent(new Event('change', { bubbles: true }))
      otpField.focus()
      otpField.blur()

      debugLog('OTP field filled successfully')
    }
  } catch (error) {
    console.error('Error filling OTP field:', error)
  }
}

/**
 * Escape HTML to prevent XSS
 *
 * @param {string} str - String to escape
 * @returns {string} Escaped string
 */
function escapeHtml(str) {
  if (!str) return ''
  const div = document.createElement('div')
  div.textContent = str
  return div.innerHTML
}

/**
 * Check if two fields are in the same login form context
 * This prevents false positives like newsletter fields
 *
 * @param {HTMLInputElement} usernameField - Username field
 * @param {HTMLInputElement} passwordField - Password field
 * @returns {boolean} True if fields are in same login context
 */
function areFieldsInLoginContext(usernameField, passwordField) {
  if (!usernameField || !passwordField) return false

  // Check if both in same form
  const usernameForm = usernameField.closest('form')
  const passwordForm = passwordField.closest('form')

  if (usernameForm && passwordForm && usernameForm === passwordForm) {
    debugLog('Fields are in same <form> element')
    return true
  }

  // Check if they share a common container (within 5 levels)
  const usernameContainer = getCommonContainer(usernameField, 5)
  const passwordContainer = getCommonContainer(passwordField, 5)

  // Check if password's container contains username or vice versa
  if (usernameContainer.contains(passwordField) || passwordContainer.contains(usernameField)) {
    debugLog('Fields share common container')
    return true
  }

  // Check DOM distance (should be close to each other)
  const allInputs = Array.from(document.querySelectorAll('input'))
  const usernameIndex = allInputs.indexOf(usernameField)
  const passwordIndex = allInputs.indexOf(passwordField)

  if (usernameIndex !== -1 && passwordIndex !== -1) {
    const distance = Math.abs(usernameIndex - passwordIndex)
    // Fields should be within 5 inputs of each other
    if (distance <= 5) {
      debugLog(`Fields are close in DOM (distance: ${distance})`)
      return true
    }
  }

  debugLog('Fields are NOT in same login context')
  return false
}

/**
 * Validate and find a legitimate login form
 * Returns both username and password fields if valid, null otherwise
 *
 * @returns {{username: HTMLInputElement, password: HTMLInputElement}|null}
 */
function findValidLoginForm() {
  // RULE 1: Must have a password field (mandatory)
  const passwordField = findPasswordField()
  if (!passwordField) {
    debugLog('No password field found - not a login form')
    return null
  }

  // RULE 2: Try to find a username field (optional for password-only forms)
  const usernameField = findUsernameField()

  if (usernameField) {
    // RULE 3: If username exists, both fields must be in the same login context
    if (!areFieldsInLoginContext(usernameField, passwordField)) {
      debugLog('Username and password are not in same context - likely false positive')
      return null
    }

    // RULE 4: Exclude fields in footer/newsletter contexts
    // Find the common container of both fields first
    const form = usernameField.closest('form') || passwordField.closest('form')
    const commonContainer = form || getCommonContainer(usernameField, 3)

    // Check if the CONTAINER (not individual fields) is in a bad context
    // Use more specific selectors to avoid false positives
    const badContext = commonContainer.closest('footer') ||
                        commonContainer.closest('[class^="newsletter-"]') ||
                        commonContainer.closest('[class^="subscribe-"]') ||
                        commonContainer.closest('[id^="newsletter-"]') ||
                        commonContainer.closest('[id^="subscribe-"]') ||
                        commonContainer.closest('[class$="-newsletter"]') ||
                        commonContainer.closest('[class$="-subscribe"]')

    if (badContext) {
      debugLog('Form container is in newsletter/footer context - skipping')
      return null
    }

    // Additional check: if the container itself IS a newsletter/subscribe element
    const containerClasses = commonContainer.className || ''
    const containerId = commonContainer.id || ''

    // More precise matching: class/id must be exactly or start/end with these terms
    const isNewsletter = /^newsletter$|^newsletter-|-newsletter$|^subscribe$|^subscribe-|-subscribe$/i.test(containerClasses + ' ' + containerId)

    if (isNewsletter) {
      debugLog('Form container is a newsletter/subscribe element - skipping')
      return null
    }

    debugLog('Valid login form found (username + password)')
    return { username: usernameField, password: passwordField }
  } else {
    // Password-only form (common on admin/system pages)
    debugLog('No username field found - checking for password-only form')

    // RULE 4 for password-only: Exclude fields in footer/newsletter contexts
    const form = passwordField.closest('form')
    const commonContainer = form || passwordField.parentElement

    const badContext = commonContainer.closest('footer') ||
                        commonContainer.closest('[class^="newsletter-"]') ||
                        commonContainer.closest('[class^="subscribe-"]') ||
                        commonContainer.closest('[id^="newsletter-"]') ||
                        commonContainer.closest('[id^="subscribe-"]') ||
                        commonContainer.closest('[class$="-newsletter"]') ||
                        commonContainer.closest('[class$="-subscribe"]')

    if (badContext) {
      debugLog('Password field is in newsletter/footer context - skipping')
      return null
    }

    const containerClasses = commonContainer.className || ''
    const containerId = commonContainer.id || ''
    const isNewsletter = /^newsletter$|^newsletter-|-newsletter$|^subscribe$|^subscribe-|-subscribe$/i.test(containerClasses + ' ' + containerId)

    if (isNewsletter) {
      debugLog('Password field container is a newsletter/subscribe element - skipping')
      return null
    }

    debugLog('Valid password-only form found!')
    return { username: null, password: passwordField }
  }
}

/**
 * Initialize autofill markers on the page
 */
async function initializeAutofillMarkers() {
  debugLog('Initializing autofill markers')

  // Prevent re-entrance during initialization
  if (autofillState.isInitializing) {
    debugLog('Already initializing, skipping...')
    return
  }

  autofillState.isInitializing = true

  try {
    // Ensure document.body exists
    if (!document.body) {
      debugLog('document.body not ready, waiting...')
      autofillState.isInitializing = false
      setTimeout(initializeAutofillMarkers, 100)
      return
    }

    // Get current URL and domain
    const currentUrl = window.location.href
    const domain = getCurrentDomain()
    if (!domain) {
      debugLog('Could not determine current domain, skipping markers')
      autofillState.isInitializing = false
      return
    }

    // Check if there are items for this URL (using full URL for better scoring)
    const response = await chrome.runtime.sendMessage({
      action: 'getItemsForAutofill',
      data: { url: currentUrl }
    })

    if (!response.success || !response.data || response.data.length === 0) {
      debugLog('No items found for this domain, skipping markers')
      autofillState.isInitializing = false
      return
    }

    debugLog(`Found ${response.data.length} items for this domain`)

    // Remove any existing markers first
    autofillState.markers.forEach(({ marker }) => {
      if (marker && marker.parentNode) {
        marker.parentNode.removeChild(marker)
      }
    })
    autofillState.markers = []

    // CRITICAL: Validate that we have a real login form (password field required, username optional)
    const loginForm = findValidLoginForm()

    if (loginForm) {
      // Add marker on username field if present, otherwise on password field
      const targetField = loginForm.username || loginForm.password
      const marker = createMarker(targetField, 'login')
      document.body.appendChild(marker)
      autofillState.markers.push({ marker, field: targetField, type: 'login' })

      // Reset failure counter on success
      autofillState.consecutiveFailures = 0

      if (loginForm.username) {
        debugLog('Login marker added to DOM (username + password form)')
      } else {
        debugLog('Login marker added to DOM (password-only form)')
      }

      // Force a reflow to ensure the marker is rendered
      marker.offsetHeight
    } else {
      debugLog('No valid login form found')
      // Increment failure counter when no form is found
      autofillState.consecutiveFailures++
    }

    // Find OTP field and add marker (if any items have OTP)
    const hasOtpItems = response.data.some(item => item.has_otp || item.otp_secret)
    if (hasOtpItems) {
      debugLog('Items with OTP found, searching for OTP field...')
      const otpField = findOtpField()
      if (otpField) {
        const marker = createMarker(otpField, 'totp')
        document.body.appendChild(marker)
        autofillState.markers.push({ marker, field: otpField, type: 'totp' })
        debugLog('TOTP marker added to DOM')

        // Force a reflow to ensure the marker is rendered
        marker.offsetHeight
      } else {
        debugLog('No OTP field found on page')
      }
    } else {
      debugLog('No items with OTP configured')
    }

    // Setup event listeners and observer only once
    if (!autofillState.listenersAdded) {
      window.addEventListener('scroll', updateMarkerPositions, { passive: true })
      window.addEventListener('resize', updateMarkerPositions, { passive: true })
      autofillState.listenersAdded = true
      debugLog('Scroll/resize listeners added')
    }

    // Setup MutationObserver only once
    if (!autofillState.observer) {
      autofillState.observer = new MutationObserver(() => {
        // Re-initialize if form fields appear and no markers exist
        // But only if not currently initializing
        if (autofillState.markers.length === 0 && !autofillState.isInitializing) {
          // Stop trying after max consecutive failures to prevent infinite loops
          if (autofillState.consecutiveFailures >= autofillState.maxConsecutiveFailures) {
            debugLog(`Stopped re-initializing after ${autofillState.consecutiveFailures} consecutive failures`)
            return
          }

          // Debounce: only reinitialize if enough time has passed since last attempt (2 seconds)
          const now = Date.now()
          const timeSinceLastAttempt = now - autofillState.lastReinitAttempt
          if (timeSinceLastAttempt < 2000) {
            return // Too soon, skip this attempt
          }

          autofillState.lastReinitAttempt = now
          debugLog('DOM changed and no markers, re-initializing...')
          setTimeout(initializeAutofillMarkers, 500)
        }
      })

      autofillState.observer.observe(document.body, {
        childList: true,
        subtree: true
      })
      debugLog('MutationObserver setup')
    }

  } catch (error) {
    console.error('Error initializing autofill markers:', error)
  } finally {
    autofillState.isInitializing = false
  }
}

// Initialize markers when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    setTimeout(initializeAutofillMarkers, 1000)
  })
} else {
  setTimeout(initializeAutofillMarkers, 1000)
}

// Listen for messages from the popup/service worker
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  debugLog('Content script received message:', request.action)

  switch (request.action) {
    case 'fillForm':
      try {
        const { username, password } = request.data

        if (!username || !password) {
          sendResponse({ success: false, error: i18n.t('content.autofill.missingUsernameOrPassword') })
          return true
        }

        const filled = fillLoginForm(username, password)

        if (filled) {
          sendResponse({ success: true, message: i18n.t('content.autofill.formFilledSuccessfully') })
        } else {
          sendResponse({ success: false, error: i18n.t('content.autofill.couldNotFindLoginForm') })
        }
      } catch (error) {
        console.error('Fill form error:', error)
        sendResponse({ success: false, error: error.message })
      }
      return true // Keep channel open

    case 'detectLoginForm':
      try {
        const hasForm = hasLoginForm()
        sendResponse({ success: true, data: { hasLoginForm: hasForm } })
      } catch (error) {
        console.error('Detect form error:', error)
        sendResponse({ success: false, error: error.message })
      }
      return true // Keep channel open

    case 'getLoginFormValues':
      try {
        const values = getLoginFormValues()
        sendResponse({ success: true, data: values })
      } catch (error) {
        console.error('Get form values error:', error)
        sendResponse({ success: false, error: error.message })
      }
      return true // Keep channel open

    default:
      sendResponse({ success: false, error: i18n.t('content.autofill.unknownAction') })
      return true
  }
})

// Notify popup when page loads (optional - for future features)
if (hasLoginForm()) {
  debugLog('Login form detected on this page')
}