/**
 * Extension Name: Teampass Manager Extension
 * Copyright (c) 2026, LogCarré. All Rights Reserved.
 *
 * This code is proprietary software. It is distributed on a non-public,
 * limited-use basis under the terms of a Commercial License.
 *
 * Unauthorized copying, modification, redistribution, or reverse engineering
 * of this code, or any part thereof, is strictly prohibited.
 */

/**
 * Save Modes Handler
 *
 * Manages the different credential save modes:
 * - Quick Save: Fast save with minimal fields
 * - Update Existing: Update an existing credential
 * - Advanced Save: Full form with all fields
 */

import { debugLog } from '../lib/modules/debug-logger.js'
import i18n from '../i18n/i18n.js'

/**
 * Helper function to create a DOM element with attributes and children
 * Safe alternative to innerHTML for extension stores
 * @param {string} tag - Element tag name
 * @param {object} attrs - Element attributes
 * @param {Array} children - Child elements or text nodes
 * @returns {HTMLElement} Created element
 */
function createElement(tag, attrs = {}, children = []) {
  const element = document.createElement(tag)

  // Set attributes
  Object.entries(attrs).forEach(([key, value]) => {
    if (key === 'className') {
      element.className = value
    } else if (key === 'textContent') {
      element.textContent = value
    } else if (key.startsWith('data-')) {
      element.setAttribute(key, value)
    } else {
      element[key] = value
    }
  })

  // Append children
  children.forEach(child => {
    if (typeof child === 'string') {
      element.appendChild(document.createTextNode(child))
    } else if (child) {
      element.appendChild(child)
    }
  })

  return element
}

class SaveModesHandler {
  constructor() {
    this.currentMode = null
    this.pendingCredential = null
    this.existingItem = null
    this.allFolders = [] // Store all folders for search functionality
  }

  /**
   * Initialize save modes - check if popup should open in save mode
   * @returns {Promise<boolean>} True if popup opened in save mode
   */
  async initialize() {
    try {
      debugLog('🔐 [SaveModes] Initializing save modes...')

      // Check if we should open in save mode via service worker
      const saveModeResponse = await chrome.runtime.sendMessage({
        action: 'getPopupSaveMode'
      })

      debugLog('🔐 [SaveModes] Save mode check:', saveModeResponse)

      if (saveModeResponse.success && saveModeResponse.data && saveModeResponse.data.mode) {
        this.currentMode = saveModeResponse.data.mode
        this.existingItem = saveModeResponse.data.existingItem

        debugLog('🔐 [SaveModes] Opening popup in save mode:', this.currentMode)

        // Get pending credential from session via service worker
        const response = await chrome.runtime.sendMessage({
          action: 'getPendingCredential'
        })

        if (response.success && response.data) {
          this.pendingCredential = response.data
          debugLog('🔐 [SaveModes] Pending credential retrieved:', this.pendingCredential)
        } else {
          console.error('🔐 [SaveModes] Failed to get pending credential:', response.error)
        }

        // NOTE: Save mode is NOT cleared here - it will be cleared when user saves/skips
        // This allows the badge protection in updateBadgeForTab to work correctly

        // Show appropriate screen
        this.showSaveScreen()

        return true // Indicate we're in save mode
      }

      return false // Not in save mode
    } catch (error) {
      console.error('🔐 [SaveModes] Error initializing save modes:', error)
      return false
    }
  }

  /**
   * Check if currently in save mode
   * @returns {boolean} True if in save mode
   */
  isInSaveMode() {
    return this.currentMode !== null
  }

  /**
   * Show the appropriate save screen based on current mode
   */
  showSaveScreen() {
    switch (this.currentMode) {
      case 'new':
        this.showQuickSaveScreen()
        break
      case 'update':
        this.showUpdateExistingScreen()
        break
      case 'advanced':
        this.showAdvancedSaveScreen()
        break
      default:
        console.error('Unknown save mode:', this.currentMode)
    }
  }

  /**
   * Show Quick Save screen
   */
  async showQuickSaveScreen() {
    debugLog('🔐 [SaveModes] Showing Quick Save screen')

    if (!this.pendingCredential) {
      console.error('🔐 [SaveModes] No pending credential found')
      window.showToast(i18n.t('saveModes.messages.noCredentials'), 'error')
      return
    }

    debugLog('🔐 [SaveModes] Pending credential:', this.pendingCredential)

    // Get last used folder for this domain
    const lastFolder = await this.getLastUsedFolder(this.pendingCredential.domain)
    debugLog('🔐 [SaveModes] Last used folder:', lastFolder)

    // Load writable folders
    debugLog('🔐 [SaveModes] Loading writable folders...')
    const folders = await this.loadWritableFolders()
    debugLog('🔐 [SaveModes] Loaded folders:', folders)

    if (!folders || folders.length === 0) {
      console.error('🔐 [SaveModes] No writable folders available!')
      window.showToast(i18n.t('saveModes.messages.noWritableFolders'), 'error')
      return
    }

    // Sort folders in tree order
    const sortedFolders = this.sortFoldersInTreeOrder(folders)
    debugLog('🔐 [SaveModes] Folders sorted in tree order')

    // Show quick save screen
    this.displayQuickSaveForm(this.pendingCredential, lastFolder, sortedFolders)
  }

  /**
   * Show Update Existing screen
   */
  showUpdateExistingScreen() {
    debugLog('Showing Update Existing screen')

    if (!this.pendingCredential || !this.existingItem) {
      console.error('Missing credential or existing item')
      window.showToast(i18n.t('saveModes.messages.missingData'), 'error')
      return
    }

    // Show update screen
    this.displayUpdateExistingForm(this.pendingCredential, this.existingItem)
  }

  /**
   * Show Advanced Save screen (use existing Add Item screen)
   */
  async showAdvancedSaveScreen() {
    debugLog('🔐 [SaveModes] Showing Advanced Save screen')

    if (!this.pendingCredential) {
      console.error('🔐 [SaveModes] No pending credential found')
      return
    }

    // Hide all custom save screens
    const quickSaveScreen = document.getElementById('quickSaveScreen')
    if (quickSaveScreen) {
      quickSaveScreen.style.display = 'none'
    }

    const updateExistingScreen = document.getElementById('updateExistingScreen')
    if (updateExistingScreen) {
      updateExistingScreen.style.display = 'none'
    }

    // Switch to existing Add Item screen
    window.showScreen('addItem')

    // Wait for DOM to be ready
    await new Promise(resolve => setTimeout(resolve, 50))

    // Get label from Quick Save form if it exists, otherwise use domain
    let label = this.pendingCredential.domain || ''
    const quickSaveLabelField = document.getElementById('quickSaveLabel')
    if (quickSaveLabelField && quickSaveLabelField.value) {
      label = quickSaveLabelField.value
    }

    // Pre-fill form with pending credential using getElementById
    const itemLabelField = document.getElementById('itemLabel')
    const itemLoginField = document.getElementById('itemLogin')
    const itemPasswordField = document.getElementById('itemPassword')
    const itemUrlField = document.getElementById('itemUrl')

    if (itemLabelField) {
      itemLabelField.value = label
      debugLog('🔐 [SaveModes] Set label:', label)
    }
    if (itemLoginField) {
      itemLoginField.value = this.pendingCredential.username || ''
      debugLog('🔐 [SaveModes] Set login:', this.pendingCredential.username)
    }
    if (itemPasswordField) {
      itemPasswordField.value = this.pendingCredential.password || ''
      debugLog('🔐 [SaveModes] Set password: ********')
    }
    if (itemUrlField) {
      itemUrlField.value = this.pendingCredential.url || ''
      debugLog('🔐 [SaveModes] Set URL:', this.pendingCredential.url)
    }

    // Load folders
    await loadWritableFolders()

    // Get folder from Quick Save form if it exists
    const itemFolderField = document.getElementById('itemFolderId')
    const quickSaveFolderField = document.getElementById('quickSaveFolderId')

    if (itemFolderField) {
      if (quickSaveFolderField && quickSaveFolderField.value) {
        itemFolderField.value = quickSaveFolderField.value
        debugLog('🔐 [SaveModes] Set folder from Quick Save:', quickSaveFolderField.value)
      } else {
        // Set last used folder if available
        const lastFolder = await this.getLastUsedFolder(this.pendingCredential.domain)
        if (lastFolder) {
          itemFolderField.value = lastFolder
          debugLog('🔐 [SaveModes] Set last used folder:', lastFolder)
        }
      }
    }
  }

  /**
   * Display Quick Save form
   */
  displayQuickSaveForm(credential, defaultFolderId, folders) {
    // Create quick save screen if doesn't exist
    let quickSaveScreen = document.getElementById('quickSaveScreen')

    if (!quickSaveScreen) {
      quickSaveScreen = this.createQuickSaveScreen()
      document.body.appendChild(quickSaveScreen)
    }

    // Show quick save screen
    Object.values(window.screens).forEach(s => s.style.display = 'none')
    quickSaveScreen.style.display = 'block'

    // Fill form
    document.getElementById('quickSaveLabel').value = credential.domain || ''
    document.getElementById('quickSaveLogin').value = credential.username || ''
    document.getElementById('quickSavePassword').value = credential.password || ''

    // Store all folders for search
    this.allFolders = folders

    // Display folders with hierarchy
    this.displayFilteredQuickSaveFolders(folders, defaultFolderId)

    // Update favorite folder button state (enable/disable based on whether favorite is set)
    if (typeof window.updateFavoriteFolderButtonsState === 'function') {
      window.updateFavoriteFolderButtonsState()
    }
  }

  /**
   * Display filtered folders in Quick Save form
   */
  displayFilteredQuickSaveFolders(folders, selectedFolderId = null) {
    const folderSelect = document.getElementById('quickSaveFolderId')

    if (!folderSelect) return

    // Clear existing options
    folderSelect.innerHTML = ''

    // Add default option
    const defaultOption = document.createElement('option')
    defaultOption.value = ''
    defaultOption.textContent = i18n.t('saveModes.quickSave.folderSelect')
    folderSelect.appendChild(defaultOption)

    // Add folder options using safe DOM manipulation
    folders.forEach(folder => {
      folderSelect.appendChild(this.createFolderOption(folder, selectedFolderId))
    })
  }

  /**
   * Escape HTML to prevent XSS
   */
  escapeHtml(text) {
    const div = document.createElement('div')
    div.textContent = text
    return div.innerHTML
  }

  /**
   * Create a folder option element for a select dropdown (safe alternative to innerHTML)
   * @param {Object} folder - Folder object with id, label, and level
   * @param {string|null} selectedId - ID of the selected folder
   * @returns {HTMLOptionElement} Option element
   */
  createFolderOption(folder, selectedId = null) {
    const option = document.createElement('option')
    option.value = folder.id

    // Create indentation based on level using non-breaking spaces
    const indent = folder.level > 0 ? '\u00A0\u00A0'.repeat(folder.level * 2) : ''
    const prefix = folder.level > 0 ? '└─ ' : ''
    const label = folder.label || `Folder ${folder.id}`

    option.textContent = indent + prefix + label

    if (folder.id === selectedId) {
      option.selected = true
    }

    return option
  }

  /**
   * Display Update Existing form
   */
  async displayUpdateExistingForm(newCredential, existingItem) {
    // Create update screen if doesn't exist
    let updateScreen = document.getElementById('updateExistingScreen')

    if (!updateScreen) {
      updateScreen = this.createUpdateExistingScreen()
      document.body.appendChild(updateScreen)
    }

    // Hide all standard screens
    Object.values(window.screens).forEach(s => s.style.display = 'none')

    // Hide items section explicitly (not part of screens object)
    const itemsSection = document.getElementById('itemsSection')
    if (itemsSection) {
      itemsSection.style.display = 'none'
    }

    // Show update screen
    updateScreen.style.display = 'block'

    // Fill form fields
    // Label field
    document.getElementById('updateLabel').value = existingItem.label || ''

    // Login fields - Current (readonly) and New (editable, pre-filled)
    document.getElementById('updateCurrentLogin').value = existingItem.login || ''
    document.getElementById('updateLogin').value = newCredential.username || existingItem.login || ''

    // Password fields - Current (readonly) and New (editable, pre-filled)
    document.getElementById('updateCurrentPassword').value = existingItem.pwd || ''
    document.getElementById('updatePassword').value = newCredential.password || existingItem.pwd || ''

    // Load folders for the folder select
    await this.loadUpdateFolders()

    // Select the current folder
    const folderSelect = document.getElementById('updateFolderId')
    if (existingItem.id_tree) {
      folderSelect.value = existingItem.id_tree
    }

    // Update favorite folder button state (enable/disable based on whether favorite is set)
    if (typeof window.updateFavoriteFolderButtonsState === 'function') {
      await window.updateFavoriteFolderButtonsState()
    }

    // Store item ID and existing data for update
    updateScreen.dataset.itemId = existingItem.id
    updateScreen.dataset.existingLabel = existingItem.label || ''
    updateScreen.dataset.existingLogin = existingItem.login || ''
    updateScreen.dataset.existingPassword = existingItem.pwd || ''
    updateScreen.dataset.existingFolder = existingItem.id_tree || ''
  }

  /**
   * Create Quick Save screen HTML
   */
  createQuickSaveScreen() {
    const screen = document.createElement('div')
    screen.id = 'quickSaveScreen'
    screen.className = 'screen'
    screen.style.display = 'none'

    // Create header
    const header = createElement('div', { className: 'header' }, [
      createElement('h1', {}, [
        createElement('i', { className: 'fas fa-save' }),
        document.createTextNode(' '),
        createElement('span', { id: 'qs-title' })
      ]),
      createElement('button', { id: 'backFromQuickSaveBtn', className: 'back-btn-right' }, [
        createElement('i', { className: 'fas fa-arrow-left' })
      ])
    ])

    // Create form
    const form = createElement('form', { id: 'quickSaveForm', className: 'save-form' }, [
      // Label field
      createElement('div', { className: 'form-group' }, [
        createElement('label', { htmlFor: 'quickSaveLabel' }, [
          createElement('span', { id: 'qs-label-field' }),
          document.createTextNode(' '),
          createElement('span', { className: 'required', id: 'qs-label-required' })
        ]),
        createElement('input', { type: 'text', id: 'quickSaveLabel', required: true }),
        createElement('small', { id: 'qs-label-hint' })
      ]),
      // Login field
      createElement('div', { className: 'form-group' }, [
        createElement('label', { htmlFor: 'quickSaveLogin' }, [
          createElement('span', { id: 'qs-login-field' }),
          document.createTextNode(' '),
          createElement('span', { className: 'required', id: 'qs-login-required' })
        ]),
        createElement('input', { type: 'text', id: 'quickSaveLogin', readOnly: true, className: 'readonly-field' })
      ]),
      // Password field
      createElement('div', { className: 'form-group' }, [
        createElement('label', { htmlFor: 'quickSavePassword' }, [
          createElement('span', { id: 'qs-password-field' }),
          document.createTextNode(' '),
          createElement('span', { className: 'required', id: 'qs-password-required' })
        ]),
        createElement('div', { className: 'password-field-wrapper' }, [
          createElement('input', { type: 'password', id: 'quickSavePassword', readOnly: true, className: 'readonly-field' }),
          createElement('button', { type: 'button', id: 'quickSavePasswordToggle', className: 'btn-icon' }, [
            createElement('i', { className: 'fas fa-eye' })
          ])
        ])
      ]),
      // Folder field
      createElement('div', { className: 'form-group' }, [
        createElement('label', { htmlFor: 'quickSaveFolderId' }, [
          createElement('span', { id: 'qs-folder-field' }),
          document.createTextNode(' '),
          createElement('span', { className: 'required', id: 'qs-folder-required' })
        ]),
        createElement('div', { className: 'folder-search-wrapper' }, [
          createElement('input', { type: 'text', id: 'quickSaveFolderSearch', autocomplete: 'off' }),
          createElement('button', { type: 'button', id: 'quickSaveUseFavoriteFolderBtn', className: 'btn-favorite-inline', disabled: true }, [
            createElement('i', { className: 'fas fa-star' })
          ]),
          createElement('button', { type: 'button', id: 'refreshQuickSaveFoldersBtn', className: 'btn-refresh-inline' }, [
            createElement('i', { className: 'fas fa-sync-alt' })
          ])
        ]),
        (() => {
          const select = createElement('select', { id: 'quickSaveFolderId', required: true, size: 8 })
          select.style.marginTop = '8px'
          select.appendChild(createElement('option', { value: '', id: 'qs-folder-select-opt' }))
          return select
        })(),
        createElement('small', { id: 'qs-folder-hint' })
      ]),
      // Actions
      createElement('div', { className: 'form-actions' }, [
        createElement('button', { type: 'submit', className: 'btn btn-primary' }, [
          createElement('i', { className: 'fas fa-save' }),
          document.createTextNode(' '),
          createElement('span', { id: 'qs-save-button' })
        ]),
        createElement('button', { type: 'button', id: 'customizeBtn', className: 'btn btn-secondary' }, [
          createElement('i', { className: 'fas fa-cog' }),
          document.createTextNode(' '),
          createElement('span', { id: 'qs-customize-button' })
        ])
      ])
    ])

    const content = createElement('div', { className: 'content' }, [form])
    screen.appendChild(header)
    screen.appendChild(content)

    // Inject i18n values safely using textContent
    screen.querySelector('#qs-title').textContent = i18n.t('saveModes.quickSave.title')
    screen.querySelector('#backFromQuickSaveBtn').title = i18n.t('saveModes.quickSave.backButton')
    screen.querySelector('#qs-label-field').textContent = i18n.t('saveModes.quickSave.labelField')
    screen.querySelector('#qs-label-required').textContent = i18n.t('saveModes.quickSave.labelRequired')
    screen.querySelector('#qs-label-hint').textContent = i18n.t('saveModes.quickSave.labelHint')
    screen.querySelector('#qs-login-field').textContent = i18n.t('saveModes.quickSave.loginField')
    screen.querySelector('#qs-login-required').textContent = i18n.t('saveModes.quickSave.labelRequired')
    screen.querySelector('#qs-password-field').textContent = i18n.t('saveModes.quickSave.passwordField')
    screen.querySelector('#qs-password-required').textContent = i18n.t('saveModes.quickSave.labelRequired')
    screen.querySelector('#quickSavePasswordToggle').title = i18n.t('saveModes.quickSave.showHide')
    screen.querySelector('#qs-folder-field').textContent = i18n.t('saveModes.quickSave.folderField')
    screen.querySelector('#qs-folder-required').textContent = i18n.t('saveModes.quickSave.folderRequired')
    screen.querySelector('#quickSaveFolderSearch').placeholder = i18n.t('saveModes.quickSave.folderSearch')
    screen.querySelector('#quickSaveUseFavoriteFolderBtn').title = i18n.t('saveModes.quickSave.useFavoriteFolder')
    screen.querySelector('#qs-folder-select-opt').textContent = i18n.t('saveModes.quickSave.folderSelect')
    screen.querySelector('#qs-folder-hint').textContent = i18n.t('saveModes.quickSave.folderHint')
    screen.querySelector('#qs-save-button').textContent = i18n.t('saveModes.quickSave.quickSaveButton')
    screen.querySelector('#qs-customize-button').textContent = i18n.t('saveModes.quickSave.customizeButton')

    // Add event listeners
    screen.querySelector('#backFromQuickSaveBtn').addEventListener('click', () => {
      this.cancelSave()
    })

    screen.querySelector('#quickSavePasswordToggle').addEventListener('click', () => {
      const passwordField = document.getElementById('quickSavePassword')
      const icon = screen.querySelector('#quickSavePasswordToggle i')
      if (passwordField.type === 'password') {
        passwordField.type = 'text'
        icon.className = 'fas fa-eye-slash'
      } else {
        passwordField.type = 'password'
        icon.className = 'fas fa-eye'
      }
    })

    screen.querySelector('#customizeBtn').addEventListener('click', () => {
      this.currentMode = 'advanced'
      this.showAdvancedSaveScreen()
    })

    screen.querySelector('#quickSaveForm').addEventListener('submit', (e) => {
      e.preventDefault()
      this.handleQuickSave()
    })

    // Add folder search listener
    screen.querySelector('#quickSaveFolderSearch').addEventListener('input', (e) => {
      this.handleQuickSaveFolderSearch(e)
    })

    // Add favorite folder button listener
    const quickSaveUseFavoriteFolderBtn = screen.querySelector('#quickSaveUseFavoriteFolderBtn')
    if (quickSaveUseFavoriteFolderBtn && typeof window.handleUseFavoriteFolder === 'function') {
      quickSaveUseFavoriteFolderBtn.addEventListener('click', () => {
        debugLog('[FavoriteFolder] Quick Save favorite folder button clicked!')
        window.handleUseFavoriteFolder('quickSaveFolderId')
      })
      debugLog('[FavoriteFolder] Quick Save favorite folder button listener attached')
    }

    // Add refresh folders button listener
    const refreshQuickSaveFoldersBtn = screen.querySelector('#refreshQuickSaveFoldersBtn')
    if (refreshQuickSaveFoldersBtn && typeof window.handleRefreshFolders === 'function') {
      refreshQuickSaveFoldersBtn.addEventListener('click', () => {
        debugLog('[RefreshFolders] Quick Save refresh folders button clicked!')
        handleRefreshFolders('quickSave')
      })
      debugLog('[RefreshFolders] Quick Save refresh folders button listener attached')
    }

    return screen
  }

  /**
   * Handle folder search in Quick Save form
   */
  handleQuickSaveFolderSearch(event) {
    const searchTerm = event.target.value.toLowerCase().trim()

    if (!searchTerm) {
      // No search term, show all folders
      this.displayFilteredQuickSaveFolders(this.allFolders)
      return
    }

    // Filter folders by label
    const filteredFolders = this.allFolders.filter(folder =>
      folder.label.toLowerCase().includes(searchTerm)
    )

    this.displayFilteredQuickSaveFolders(filteredFolders)

    // Show message if no results
    if (filteredFolders.length === 0) {
      const folderSelect = document.getElementById('quickSaveFolderId')
      folderSelect.innerHTML = ''
      const option = document.createElement('option')
      option.value = ''
      option.textContent = i18n.t('saveModes.quickSave.noFoldersFound')
      folderSelect.appendChild(option)
    }
  }

  /**
   * Load folders for Update Existing form
   */
  async loadUpdateFolders() {
    try {
      // Get folders from Teampass
      const response = await chrome.runtime.sendMessage({
        action: 'getWritableFolders'
      })

      if (response && response.success && response.data) {
        // Sort folders in tree order
        const sortedFolders = this.sortFoldersInTreeOrder(response.data)

        // Store all folders for search
        this.allUpdateFolders = sortedFolders

        // Display folders
        this.displayFilteredUpdateFolders(sortedFolders)
      } else {
        console.error('Failed to load folders:', response?.error)
        const folderSelect = document.getElementById('updateFolderId')
        folderSelect.innerHTML = ''
        const option = document.createElement('option')
        option.value = ''
        option.textContent = i18n.t('saveModes.quickSave.noFoldersFound')
        folderSelect.appendChild(option)
      }
    } catch (error) {
      console.error('Error loading folders:', error)
      const folderSelect = document.getElementById('updateFolderId')
      folderSelect.innerHTML = ''
      const option = document.createElement('option')
      option.value = ''
      option.textContent = i18n.t('saveModes.quickSave.noFoldersFound')
      folderSelect.appendChild(option)
    }
  }

  /**
   * Display filtered folders in Update Existing form
   */
  displayFilteredUpdateFolders(folders, selectedFolderId = null) {
    const folderSelect = document.getElementById('updateFolderId')

    if (!folderSelect) return

    // Clear existing options
    folderSelect.innerHTML = ''

    // Add default option
    const defaultOption = document.createElement('option')
    defaultOption.value = ''
    defaultOption.textContent = i18n.t('saveModes.quickSave.folderSelect')
    folderSelect.appendChild(defaultOption)

    // Add folder options using safe DOM manipulation
    folders.forEach(folder => {
      folderSelect.appendChild(this.createFolderOption(folder, selectedFolderId))
    })
  }

  /**
   * Handle folder search in Update Existing form
   */
  handleUpdateFolderSearch(event) {
    const searchTerm = event.target.value.toLowerCase().trim()

    if (!searchTerm) {
      // No search term, show all folders
      this.displayFilteredUpdateFolders(this.allUpdateFolders || [])
      return
    }

    // Filter folders by label
    const filteredFolders = (this.allUpdateFolders || []).filter(folder =>
      folder.label.toLowerCase().includes(searchTerm)
    )

    this.displayFilteredUpdateFolders(filteredFolders)

    // Show message if no results
    if (filteredFolders.length === 0) {
      const folderSelect = document.getElementById('updateFolderId')
      folderSelect.innerHTML = ''
      const option = document.createElement('option')
      option.value = ''
      option.textContent = i18n.t('saveModes.quickSave.noFoldersFound')
      folderSelect.appendChild(option)
    }
  }

  /**
   * Create Update Existing screen HTML
   */
  createUpdateExistingScreen() {
    const screen = document.createElement('div')
    screen.id = 'updateExistingScreen'
    screen.className = 'screen'
    screen.style.display = 'none'

    // Create header
    const header = createElement('div', { className: 'header' }, [
      createElement('h1', {}, [
        createElement('i', { className: 'fas fa-exclamation-triangle' }),
        document.createTextNode(' '),
        createElement('span', { id: 'ue-title' })
      ]),
      createElement('button', { id: 'backFromUpdateBtn', className: 'back-btn-right' }, [
        createElement('i', { className: 'fas fa-arrow-left' })
      ])
    ])

    // Create form
    const form = createElement('form', { id: 'updateExistingForm', className: 'save-form' }, [
      // Label field
      createElement('div', { className: 'form-group' }, [
        createElement('label', { htmlFor: 'updateLabel' }, [
          createElement('span', { id: 'ue-label-field' }),
          document.createTextNode(' '),
          createElement('span', { className: 'required', textContent: '*' })
        ]),
        createElement('input', { type: 'text', id: 'updateLabel', required: true })
      ]),
      // Login field
      createElement('div', { className: 'form-group' }, [
        createElement('label', { htmlFor: 'updateLogin', id: 'ue-login-field' }),
        createElement('div', { className: 'comparison-row' }, [
          (() => {
            const div = createElement('div', {})
            div.style.flex = '1'
            div.appendChild(createElement('small', { id: 'ue-current-label-1' }))
            div.appendChild(createElement('input', { type: 'text', id: 'updateCurrentLogin', readOnly: true, className: 'readonly-field' }))
            return div
          })(),
          (() => {
            const div = createElement('div', {})
            div.style.flex = '1'
            div.appendChild(createElement('small', { id: 'ue-new-label-1' }))
            div.appendChild(createElement('input', { type: 'text', id: 'updateLogin' }))
            return div
          })()
        ])
      ]),
      // Password field
      createElement('div', { className: 'form-group' }, [
        createElement('label', { htmlFor: 'updatePassword' }, [
          createElement('span', { id: 'ue-password-field' }),
          document.createTextNode(' '),
          createElement('span', { className: 'required', textContent: '*' })
        ]),
        createElement('div', { className: 'comparison-row' }, [
          (() => {
            const div = createElement('div', {})
            div.style.flex = '1'
            div.appendChild(createElement('small', { id: 'ue-current-label-2' }))
            div.appendChild(createElement('div', { className: 'password-field-wrapper' }, [
              createElement('input', { type: 'password', id: 'updateCurrentPassword', readOnly: true, className: 'readonly-field' }),
              createElement('button', { type: 'button', id: 'toggleCurrentPassword', className: 'btn-icon' }, [
                createElement('i', { className: 'fas fa-eye' })
              ])
            ]))
            return div
          })(),
          (() => {
            const div = createElement('div', {})
            div.style.flex = '1'
            div.appendChild(createElement('small', { id: 'ue-new-label-2' }))
            div.appendChild(createElement('div', { className: 'password-field-wrapper' }, [
              createElement('input', { type: 'password', id: 'updatePassword', required: true }),
              createElement('button', { type: 'button', id: 'updatePasswordToggle', className: 'btn-icon' }, [
                createElement('i', { className: 'fas fa-eye' })
              ])
            ]))
            return div
          })()
        ])
      ]),
      // Folder field
      createElement('div', { className: 'form-group' }, [
        createElement('label', { htmlFor: 'updateFolderId' }, [
          createElement('span', { id: 'ue-folder-field' }),
          document.createTextNode(' '),
          createElement('span', { className: 'required', textContent: '*' })
        ]),
        createElement('div', { className: 'folder-search-wrapper' }, [
          createElement('input', { type: 'text', id: 'updateFolderSearch', autocomplete: 'off' }),
          createElement('button', { type: 'button', id: 'updateUseFavoriteFolderBtn', className: 'btn-favorite-inline', disabled: true }, [
            createElement('i', { className: 'fas fa-star' })
          ]),
          createElement('button', { type: 'button', id: 'refreshUpdateFoldersBtn', className: 'btn-refresh-inline' }, [
            createElement('i', { className: 'fas fa-sync-alt' })
          ])
        ]),
        (() => {
          const select = createElement('select', { id: 'updateFolderId', required: true, size: 8 })
          select.style.marginTop = '8px'
          select.appendChild(createElement('option', { value: '', id: 'ue-folder-select-opt' }))
          return select
        })()
      ]),
      // Actions
      createElement('div', { className: 'form-actions' }, [
        createElement('button', { type: 'submit', className: 'btn btn-primary' }, [
          createElement('i', { className: 'fas fa-sync' }),
          document.createTextNode(' '),
          createElement('span', { id: 'ue-update-button' })
        ]),
        createElement('button', { type: 'button', id: 'createNewBtn', className: 'btn btn-secondary' }, [
          createElement('i', { className: 'fas fa-plus' }),
          document.createTextNode(' '),
          createElement('span', { id: 'ue-create-new-button' })
        ]),
        createElement('button', { type: 'button', id: 'skipUpdateBtn', className: 'btn btn-tertiary' }, [
          createElement('i', { className: 'fas fa-times' }),
          document.createTextNode(' '),
          createElement('span', { id: 'ue-skip-button' })
        ])
      ])
    ])

    const content = createElement('div', { className: 'content' }, [form])
    screen.appendChild(header)
    screen.appendChild(content)

    // Inject i18n values safely using textContent
    screen.querySelector('#ue-title').textContent = i18n.t('saveModes.updateExisting.title')
    screen.querySelector('#backFromUpdateBtn').title = i18n.t('saveModes.updateExisting.backButton')
    screen.querySelector('#ue-label-field').textContent = i18n.t('saveModes.updateExisting.labelField')
    screen.querySelector('#ue-login-field').textContent = i18n.t('saveModes.updateExisting.loginField')
    screen.querySelector('#ue-current-label-1').textContent = i18n.t('saveModes.updateExisting.currentLabel')
    screen.querySelector('#ue-new-label-1').textContent = i18n.t('saveModes.updateExisting.newLabel')
    screen.querySelector('#ue-password-field').textContent = i18n.t('saveModes.updateExisting.passwordField')
    screen.querySelector('#ue-current-label-2').textContent = i18n.t('saveModes.updateExisting.currentLabel')
    screen.querySelector('#ue-new-label-2').textContent = i18n.t('saveModes.updateExisting.newLabel')
    screen.querySelector('#toggleCurrentPassword').title = i18n.t('saveModes.updateExisting.showHideCurrent')
    screen.querySelector('#updatePasswordToggle').title = i18n.t('saveModes.updateExisting.showHidePassword')
    screen.querySelector('#ue-folder-field').textContent = i18n.t('saveModes.updateExisting.folderField')
    screen.querySelector('#updateFolderSearch').placeholder = i18n.t('saveModes.quickSave.folderSearch')
    screen.querySelector('#updateUseFavoriteFolderBtn').title = i18n.t('saveModes.quickSave.useFavoriteFolder')
    screen.querySelector('#ue-folder-select-opt').textContent = i18n.t('saveModes.quickSave.folderSelect')
    screen.querySelector('#ue-update-button').textContent = i18n.t('saveModes.updateExisting.updateButton')
    screen.querySelector('#ue-create-new-button').textContent = i18n.t('saveModes.updateExisting.createNewButton')
    screen.querySelector('#ue-skip-button').textContent = i18n.t('saveModes.updateExisting.skipButton')

    // Add event listeners
    screen.querySelector('#backFromUpdateBtn').addEventListener('click', () => {
      this.cancelSave()
    })

    screen.querySelector('#updateExistingForm').addEventListener('submit', (e) => {
      e.preventDefault()
      this.handleUpdateExisting()
    })

    screen.querySelector('#createNewBtn').addEventListener('click', () => {
      this.currentMode = 'advanced'
      this.showAdvancedSaveScreen()
    })

    screen.querySelector('#skipUpdateBtn').addEventListener('click', () => {
      this.cancelSave()
    })

    // Password toggle buttons
    screen.querySelector('#toggleCurrentPassword').addEventListener('click', () => {
      const passwordField = document.getElementById('updateCurrentPassword')
      const icon = screen.querySelector('#toggleCurrentPassword i')
      if (passwordField.type === 'password') {
        passwordField.type = 'text'
        icon.className = 'fas fa-eye-slash'
      } else {
        passwordField.type = 'password'
        icon.className = 'fas fa-eye'
      }
    })

    screen.querySelector('#updatePasswordToggle').addEventListener('click', () => {
      const passwordField = document.getElementById('updatePassword')
      const icon = screen.querySelector('#updatePasswordToggle i')
      if (passwordField.type === 'password') {
        passwordField.type = 'text'
        icon.className = 'fas fa-eye-slash'
      } else {
        passwordField.type = 'password'
        icon.className = 'fas fa-eye'
      }
    })

    // Folder search listener
    screen.querySelector('#updateFolderSearch').addEventListener('input', (e) => {
      this.handleUpdateFolderSearch(e)
    })

    // Add favorite folder button listener
    const updateUseFavoriteFolderBtn = screen.querySelector('#updateUseFavoriteFolderBtn')
    if (updateUseFavoriteFolderBtn && typeof window.handleUseFavoriteFolder === 'function') {
      updateUseFavoriteFolderBtn.addEventListener('click', () => {
        debugLog('[FavoriteFolder] Update screen favorite folder button clicked!')
        window.handleUseFavoriteFolder('updateFolderId')
      })
      debugLog('[FavoriteFolder] Update screen favorite folder button listener attached')
    }

    // Add refresh folders button listener
    const refreshUpdateFoldersBtn = screen.querySelector('#refreshUpdateFoldersBtn')
    if (refreshUpdateFoldersBtn && typeof window.handleRefreshFolders === 'function') {
      refreshUpdateFoldersBtn.addEventListener('click', () => {
        debugLog('[RefreshFolders] Update screen refresh folders button clicked!')
        handleRefreshFolders('update')
      })
      debugLog('[RefreshFolders] Update screen refresh folders button listener attached')
    }

    return screen
  }

  /**
   * Handle Quick Save submission
   */
  async handleQuickSave() {
    try {
      const label = document.getElementById('quickSaveLabel').value
      const folderId = document.getElementById('quickSaveFolderId').value

      if (!label) {
        window.showToast(i18n.t('saveModes.messages.enterLabel'), 'error')
        return
      }

      if (!folderId) {
        window.showToast(i18n.t('saveModes.messages.selectFolder'), 'error')
        return
      }

      // Show loading
      window.showToast(i18n.t('saveModes.messages.savingCredentials'), 'info')

      // Ensure valid authentication before creating item
      debugLog('🔐 [SaveModes] Ensuring valid authentication before save...')
      const tokenValidation = await chrome.runtime.sendMessage({
        action: 'ensureValidToken'
      })

      if (!tokenValidation.success || !tokenValidation.data) {
        // Authentication failed, try to authenticate
        debugLog('🔐 [SaveModes] Token validation failed, user needs to authenticate')
        window.showToast(i18n.t('saveModes.messages.authenticationRequired') || 'Authentication required. Please login first.', 'error')

        // Redirect to options page for login
        if (typeof chrome.runtime.openOptionsPage === 'function') {
          chrome.runtime.openOptionsPage()
        }
        return
      }

      debugLog('🔐 [SaveModes] Authentication valid, proceeding with save...')

      // Create item data - ALL fields required by Teampass API (even if empty)
      const itemData = {
        label: label,
        login: this.pendingCredential.username,
        password: this.pendingCredential.password,
        url: this.pendingCredential.url,
        email: '', // Required by API even if empty
        description: '', // Required by API even if empty
        tags: '', // Required by API even if empty
        icon: '', // Required by API even if empty
        anyone_can_modify: 0, // Required by API
        folder_id: parseInt(folderId, 10)
      }

      // Create item
      const response = await chrome.runtime.sendMessage({
        action: 'createItem',
        data: { itemData }
      })

      if (response.success) {
        // Save last used folder
        await this.saveLastUsedFolder(this.pendingCredential.domain, folderId)

        // Clear session credential via service worker
        await chrome.runtime.sendMessage({
          action: 'removePendingCredential'
        })

        window.showToast(i18n.t('saveModes.messages.credentialsSaved'), 'success')

        // Hide Quick Save screen
        const quickSaveScreen = document.getElementById('quickSaveScreen')
        if (quickSaveScreen) {
          quickSaveScreen.style.display = 'none'
        }

        // Return to main screen
        window.showScreen('main')
        debugLog('🔐 [SaveModes] window.loadItemsForCurrentPage type:', typeof window.loadItemsForCurrentPage)
        if (typeof window.loadItemsForCurrentPage === 'function') {
          window.loadItemsForCurrentPage().catch(err => console.error("Error loading items:", err))
        }
      } else {
        throw new Error(response.error || 'Failed to save credentials')
      }
    } catch (error) {
      console.error('Quick save error:', error)
      window.showToast(i18n.t('saveModes.messages.saveFailed') + ' ' + error.message, 'error')
    }
  }

  /**
   * Handle Update Existing submission
   */
  async handleUpdateExisting() {
    try {
      const updateScreen = document.getElementById('updateExistingScreen')
      const itemId = updateScreen.dataset.itemId

      if (!itemId) {
        throw new Error(i18n.t('saveModes.messages.noItemId'))
      }

      // Get form values
      const newLabel = document.getElementById('updateLabel').value.trim()
      const newLogin = document.getElementById('updateLogin').value.trim()
      const newPassword = document.getElementById('updatePassword').value
      const newFolderId = document.getElementById('updateFolderId').value

      // Validate required fields
      if (!newLabel) {
        window.showToast(i18n.t('saveModes.messages.labelRequired'), 'error')
        return
      }

      if (!newPassword) {
        window.showToast(i18n.t('saveModes.messages.passwordRequired'), 'error')
        return
      }

      if (!newFolderId) {
        window.showToast(i18n.t('saveModes.messages.folderRequired'), 'error')
        return
      }

      // Show loading
      window.showToast(i18n.t('saveModes.messages.updatingCredentials'), 'info')

      // Ensure valid authentication before updating item
      debugLog('🔐 [SaveModes] Ensuring valid authentication before update...')
      const tokenValidation = await chrome.runtime.sendMessage({
        action: 'ensureValidToken'
      })

      if (!tokenValidation.success || !tokenValidation.data) {
        // Authentication failed
        debugLog('🔐 [SaveModes] Token validation failed, user needs to authenticate')
        window.showToast(i18n.t('saveModes.messages.authenticationRequired') || 'Authentication required. Please login first.', 'error')

        // Redirect to options page for login
        if (typeof chrome.runtime.openOptionsPage === 'function') {
          chrome.runtime.openOptionsPage()
        }
        return
      }

      debugLog('🔐 [SaveModes] Authentication valid, proceeding with update...')

      // Get existing values from dataset
      const existingLabel = updateScreen.dataset.existingLabel || ''
      const existingLogin = updateScreen.dataset.existingLogin || ''
      const existingPassword = updateScreen.dataset.existingPassword || ''
      const existingFolder = updateScreen.dataset.existingFolder || ''

      // Build update data with all editable fields
      const itemData = {}

      // Check what changed and include in update
      if (newLabel !== existingLabel) {
        itemData.label = newLabel
      }

      if (newLogin !== existingLogin) {
        itemData.login = newLogin
      }

      if (newPassword !== existingPassword) {
        itemData.password = newPassword
      }

      if (newFolderId !== existingFolder) {
        itemData.folder_id = parseInt(newFolderId, 10)
      }

      // If nothing changed, just close
      if (Object.keys(itemData).length === 0) {
        window.showToast(i18n.t('saveModes.messages.noChanges'), 'info')
        this.cancelSave()
        return
      }

      // Update item
      const response = await chrome.runtime.sendMessage({
        action: 'updateItem',
        data: {
          itemId: parseInt(itemId, 10),
          itemData
        }
      })

      if (response.success) {
        // Clear session credential via service worker
        await chrome.runtime.sendMessage({
          action: 'removePendingCredential'
        })

        window.showToast(i18n.t('saveModes.messages.credentialsUpdated'), 'success')

        // Hide Update Existing screen
        if (updateScreen) {
          updateScreen.style.display = 'none'
        }

        // Return to main screen
        window.showScreen('main')
        if (typeof window.loadItemsForCurrentPage === 'function') {
          window.loadItemsForCurrentPage().catch(err => console.error("Error loading items:", err))
        }
      } else {
        throw new Error(response.error || 'Failed to update credentials')
      }
    } catch (error) {
      console.error('Update error:', error)
      window.showToast(i18n.t('saveModes.messages.updateFailed') + ' ' + error.message, 'error')
    }
  }

  /**
   * Cancel save and clear session data
   */
  async cancelSave() {
    try {
      debugLog('🔐 [SaveModes] Canceling save, clearing session...')

      // Clear session credential via service worker
      await chrome.runtime.sendMessage({
        action: 'removePendingCredential'
      })

      // Hide all custom save screens
      const quickSaveScreen = document.getElementById('quickSaveScreen')
      if (quickSaveScreen) {
        quickSaveScreen.style.display = 'none'
      }

      const updateScreen = document.getElementById('updateExistingScreen')
      if (updateScreen) {
        updateScreen.style.display = 'none'
      }

      // Return to main screen and load items
      window.showScreen('main')
      if (typeof window.loadItemsForCurrentPage === 'function') {
        await window.loadItemsForCurrentPage().catch(err => console.error("Error loading items:", err))
      }
    } catch (error) {
      console.error('🔐 [SaveModes] Cancel error:', error)
    }
  }

  /**
   * Get last used folder for domain (via service worker)
   */
  async getLastUsedFolder(domain) {
    try {
      const response = await chrome.runtime.sendMessage({
        action: 'getLastUsedFolder',
        data: { domain }
      })
      return response.success ? response.data : null
    } catch (error) {
      console.error('Error getting last used folder:', error)
      return null
    }
  }

  /**
   * Save last used folder for domain (via service worker)
   */
  async saveLastUsedFolder(domain, folderId) {
    try {
      await chrome.runtime.sendMessage({
        action: 'saveLastUsedFolder',
        data: { domain, folderId: parseInt(folderId, 10) }
      })
    } catch (error) {
      console.error('Error saving last used folder:', error)
    }
  }

  /**
   * Sort folders in tree order (parent followed by children)
   * Copied from popup.js to maintain consistent folder ordering
   */
  sortFoldersInTreeOrder(folders) {
    // Create a map of folders by ID for quick lookup
    const folderMap = new Map()
    folders.forEach(folder => folderMap.set(folder.id, { ...folder }))

    // Find folder with first_position = 1
    const firstPositionFolder = folders.find(f => f.first_position === 1 || f.first_position === '1')

    // Build tree structure - group children by parent_id
    const childrenMap = new Map()
    folders.forEach(folder => {
      const parentId = folder.parent_id || 0
      if (!childrenMap.has(parentId)) {
        childrenMap.set(parentId, [])
      }
      childrenMap.get(parentId).push(folder)
    })

    // Sort children alphabetically within each parent
    childrenMap.forEach(children => {
      children.sort((a, b) => a.label.localeCompare(b.label))
    })

    // Function to get all descendants of a folder with level tracking
    function getAllDescendants(folderId, level, excludeIds = new Set()) {
      const descendants = []
      const children = childrenMap.get(folderId) || []

      children.forEach(child => {
        if (!excludeIds.has(child.id)) {
          child.level = level
          descendants.push(child)
          descendants.push(...getAllDescendants(child.id, level + 1, excludeIds))
        }
      })

      return descendants
    }

    // If there's a first_position folder, collect it and all its descendants
    const firstPositionBranch = []
    const excludeIds = new Set()

    if (firstPositionFolder) {
      firstPositionFolder.level = 0
      firstPositionBranch.push(firstPositionFolder)
      excludeIds.add(firstPositionFolder.id)

      // Get all descendants of the first_position folder
      const descendants = getAllDescendants(firstPositionFolder.id, 1)
      firstPositionBranch.push(...descendants)

      // Mark all descendants to exclude from main tree
      descendants.forEach(desc => excludeIds.add(desc.id))
    }

    // Traverse tree in depth-first order (parent, then children, then grandchildren...)
    // but exclude the first_position branch
    const result = []

    function traverse(parentId, level) {
      const children = childrenMap.get(parentId) || []
      children.forEach(folder => {
        if (!excludeIds.has(folder.id)) {
          folder.level = level
          result.push(folder)
          traverse(folder.id, level + 1) // Recursively add children
        }
      })
    }

    // Start with root folders (parent_id = 0 or null)
    traverse(0, 0)

    // Also handle folders with null parent_id
    if (childrenMap.has(null)) {
      childrenMap.get(null).forEach(folder => {
        if (!excludeIds.has(folder.id)) {
          folder.level = 0
          result.push(folder)
          traverse(folder.id, 1)
        }
      })
    }

    // Return first_position branch first, then the rest
    return [...firstPositionBranch, ...result]
  }

  /**
   * Load writable folders
   */
  async loadWritableFolders() {
    try {
      debugLog('🔐 [SaveModes] Sending getWritableFolders message...')
      const response = await chrome.runtime.sendMessage({
        action: 'getWritableFolders'
      })

      debugLog('🔐 [SaveModes] getWritableFolders response:', response)

      if (response.success) {
        const folders = response.data || []
        debugLog('🔐 [SaveModes] Folders loaded successfully:', folders.length, 'folders')
        return folders
      } else {
        throw new Error(response.error || 'Failed to load folders')
      }
    } catch (error) {
      console.error('🔐 [SaveModes] Error loading folders:', error)
      return []
    }
  }
}

// Create singleton instance
const saveModesHandler = new SaveModesHandler()

// Export for ES6 modules
export { SaveModesHandler, saveModesHandler }
export default saveModesHandler
