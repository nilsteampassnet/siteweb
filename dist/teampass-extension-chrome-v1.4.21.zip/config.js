/**
 * Extension Name: Teampass Password Manager
 * Copyright (c) 2026, LogCarré. All Rights Reserved.
 *
 * This code is proprietary software. It is distributed on a non-public,
 * limited-use basis under the terms of a Commercial License.
 *
 * Unauthorized copying, modification, redistribution, or reverse engineering
 * of this code, or any part thereof, is strictly prohibited.
 */

/**
 * Teampass Extension - Global Configuration
 *
 * Centralized configuration file for easy customization
 * Edit values here instead of searching through multiple files
 */

const CONFIG = {
  /**
   * Release information
   */
  RELEASE: '1.4.21',
  YEAR: '2026',
  
  /**
   * Project URLs
   */
  GITHUB_URL: 'https://github.com/nilsteampassnet/TeamPass',
  GITHUB_ISSUES_URL: 'https://github.com/nilsteampassnet/TeamPass/issues',
  
  /**
   * Timing configurations (in milliseconds)
   */
  REAUTH_WAIT_DELAY: 500,          // Delay after re-authentication
  LOGIN_SUCCESS_DELAY: 500,         // Delay after successful login
  TOAST_DURATION: 3000,             // Toast notification duration
  MODAL_ANIMATION_DURATION: 300,    // Modal fade animation duration
  TOKEN_EXPIRY_MINUTES: 60,         // JWT token expiry time (minutes)
  TOKEN_WARNING_MINUTES: 5,         // Warn when token expires in X minutes
  MESSAGE_TIMEOUT: 10000,           // Timeout for service worker messages (ms)
  
  /**
   * OTP/TOTP settings
   */
  OTP_DEFAULT_EXPIRY: 30,           // Default OTP expiry in seconds
  OTP_WARNING_THRESHOLD: 5,         // Show warning when < 5 seconds

  /**
   * Credential saving settings
   */
  CREDENTIAL_SAVE: {
    ENABLE_AUTO_DETECT: true,           // Enable automatic credential detection
    TOAST_DISPLAY_DURATION: 10000,      // Toast display duration (10s)
    TOAST_AUTO_HIDE: true,              // Auto-hide toast after duration
    URL_CHANGE_TIMEOUT: 30000,          // Timeout to detect URL change (30s - allows OTP/2FA)
    MIN_PASSWORD_LENGTH: 1,             // Minimum password length to save
    SAVE_LAST_FOLDER: true,             // Remember last used folder per domain
    REQUIRE_HTTPS: false,               // Only suggest save on HTTPS sites (set to true for production)
    TOAST_POSITION: 'top-right',        // Toast position: 'top-right' | 'top-left' | 'bottom-right' | 'bottom-left'
  },

  /**
   * UI settings
   */
  ITEMS_ANIMATION_DELAY: 50,        // Delay between item animations (ms)
  MAX_POPUP_HEIGHT: 500             // Max height for scrollable content
}

// Make CONFIG available globally
if (typeof window !== 'undefined') {
  window.CONFIG = CONFIG
}

// Export for modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = CONFIG
}