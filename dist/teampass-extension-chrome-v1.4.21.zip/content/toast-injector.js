/**
 * Extension Name: Teampass Manager Extension
 * Copyright (c) 2026, LogCarré. All Rights Reserved.
 *
 * This code is proprietary software. It is distributed on a non-public,
 * limited-use basis under the terms of a Commercial License.
 *
 * Unauthorized copying, modification, redistribution, or reverse engineering
 * of this code, or any part thereof, is strictly prohibited.
 */

/**
 * Teampass Toast Injector
 *
 * Handles the display and interaction of credential save toast notifications
 * injected into web pages
 */

class TeampassToast {
  constructor() {
    this.toastElement = null
    this.hideTimer = null
    this.progressInterval = null
    this.onSaveCallback = null
    this.onSkipCallback = null
  }

  /**
   * Show credential save toast
   *
   * @param {object} options - Toast options
   * @param {string} options.mode - 'new' or 'update'
   * @param {string} options.domain - Domain name (e.g., 'github.com')
   * @param {boolean} options.hasChanged - For update mode: has password changed
   * @param {function} options.onSave - Callback when Save is clicked
   * @param {function} options.onSkip - Callback when Skip is clicked
   */
  show(options) {
    const {
      mode = 'new',
      domain = window.location.hostname,
      hasChanged = false,
      onSave,
      onSkip
    } = options

    // Store callbacks
    this.onSaveCallback = onSave
    this.onSkipCallback = onSkip

    // Remove existing toast if any
    this.hide(true)

    // Create toast element
    this.toastElement = this.createToastElement(mode, domain, hasChanged)

    // Inject CSS if not already injected
    this.injectStyles()

    // Add to page
    document.body.appendChild(this.toastElement)

    // Setup event listeners
    this.setupEventListeners()

    // Setup auto-hide if configured
    if (CONFIG.CREDENTIAL_SAVE.TOAST_AUTO_HIDE) {
      this.startAutoHide()
    }

    debugLog('Teampass toast shown:', mode, domain)
  }

  /**
   * Create toast DOM element
   *
   * @param {string} mode - 'new' or 'update'
   * @param {string} domain - Domain name
   * @param {boolean} hasChanged - Has password changed (for update mode)
   * @returns {HTMLElement} Toast element
   */
  createToastElement(mode, domain, hasChanged) {
    const toast = document.createElement('div')
    toast.id = 'teampass-save-toast'
    toast.className = `toast-${CONFIG.CREDENTIAL_SAVE.TOAST_POSITION}`

    const isUpdateMode = mode === 'update'
    const icon = isUpdateMode ? '⚠️' : '✓'
    const iconClass = isUpdateMode ? 'warning' : ''
    const title = isUpdateMode
      ? i18n.t('content.toast.existingEntryFound')
      : i18n.t('content.toast.loginDetected')
    const subtitle = isUpdateMode
      ? (hasChanged ? i18n.t('content.toast.passwordHasChanged') : i18n.t('content.toast.updateCredentials'))
      : i18n.t('content.toast.saveCredentialsFor', { domain })

    const logoUrl = chrome.runtime.getURL('icons/icon16.png')

    // Build toast structure using safe DOM manipulation
    const wrapper = document.createElement('div')
    wrapper.className = 'teampass-toast-wrapper'

    // Header
    const header = document.createElement('div')
    header.className = 'teampass-toast-header'

    const headerContent = document.createElement('div')
    headerContent.className = 'teampass-toast-header-content'

    const logo = document.createElement('img')
    logo.src = logoUrl
    logo.alt = 'Teampass'
    logo.className = 'teampass-toast-logo'

    const headerSpan = document.createElement('span')
    headerSpan.textContent = i18n.t('content.toast.teampassExtension')

    headerContent.appendChild(logo)
    headerContent.appendChild(headerSpan)

    const closeBtn = document.createElement('button')
    closeBtn.className = 'teampass-toast-close'
    closeBtn.setAttribute('aria-label', 'Close')
    closeBtn.title = i18n.t('content.toast.close')
    closeBtn.textContent = '×'

    header.appendChild(headerContent)
    header.appendChild(closeBtn)

    // Content
    const content = document.createElement('div')
    content.className = `teampass-toast-content ${isUpdateMode ? 'update-mode' : ''}`

    const iconSpan = document.createElement('span')
    iconSpan.className = `teampass-toast-icon ${iconClass}`
    iconSpan.textContent = icon

    const message = document.createElement('div')
    message.className = 'teampass-toast-message'

    const titleDiv = document.createElement('div')
    titleDiv.className = 'teampass-toast-title'
    titleDiv.textContent = title

    const subtitleDiv = document.createElement('div')
    subtitleDiv.className = 'teampass-toast-subtitle'
    subtitleDiv.textContent = subtitle

    message.appendChild(titleDiv)
    message.appendChild(subtitleDiv)

    const buttons = document.createElement('div')
    buttons.className = 'teampass-toast-buttons'

    const saveBtn = document.createElement('button')
    saveBtn.className = 'teampass-toast-btn teampass-toast-btn-save'
    saveBtn.textContent = isUpdateMode ? i18n.t('content.toast.review') : i18n.t('content.toast.save')

    const skipBtn = document.createElement('button')
    skipBtn.className = 'teampass-toast-btn teampass-toast-btn-skip'
    skipBtn.textContent = i18n.t('content.toast.skip')

    buttons.appendChild(saveBtn)
    buttons.appendChild(skipBtn)

    content.appendChild(iconSpan)
    content.appendChild(message)
    content.appendChild(buttons)

    wrapper.appendChild(header)
    wrapper.appendChild(content)

    // Progress bar (if auto-hide enabled)
    if (CONFIG.CREDENTIAL_SAVE.TOAST_AUTO_HIDE) {
      const progress = document.createElement('div')
      progress.className = 'teampass-toast-progress'
      wrapper.appendChild(progress)
    }

    toast.appendChild(wrapper)

    return toast
  }

  /**
   * Inject CSS styles into page
   */
  injectStyles() {
    // Check if styles already injected
    if (document.getElementById('teampass-toast-styles')) {
      return
    }

    // Fetch CSS from extension
    const link = document.createElement('link')
    link.id = 'teampass-toast-styles'
    link.rel = 'stylesheet'
    link.href = chrome.runtime.getURL('content/toast.css')
    document.head.appendChild(link)

    debugLog('Teampass toast styles injected')
  }

  /**
   * Setup event listeners for toast buttons
   */
  setupEventListeners() {
    if (!this.toastElement) return

    // Save button
    const saveBtn = this.toastElement.querySelector('.teampass-toast-btn-save')
    if (saveBtn) {
      saveBtn.addEventListener('click', () => this.handleSave())
    }

    // Skip button
    const skipBtn = this.toastElement.querySelector('.teampass-toast-btn-skip')
    if (skipBtn) {
      skipBtn.addEventListener('click', () => this.handleSkip())
    }

    // Close button
    const closeBtn = this.toastElement.querySelector('.teampass-toast-close')
    if (closeBtn) {
      closeBtn.addEventListener('click', () => this.handleSkip())
    }
  }

  /**
   * Handle Save button click
   */
  handleSave() {
    debugLog('Teampass toast: Save clicked')

    // Stop auto-hide
    this.stopAutoHide()

    // Call callback
    if (this.onSaveCallback) {
      this.onSaveCallback()
    }

    // Hide toast
    this.hide()
  }

  /**
   * Handle Skip button click
   */
  handleSkip() {
    debugLog('Teampass toast: Skip clicked')

    // Stop auto-hide
    this.stopAutoHide()

    // Call callback
    if (this.onSkipCallback) {
      this.onSkipCallback()
    }

    // Hide toast
    this.hide()
  }

  /**
   * Start auto-hide timer
   */
  startAutoHide() {
    const duration = CONFIG.CREDENTIAL_SAVE.TOAST_DISPLAY_DURATION

    // Progress bar animation
    const progressBar = this.toastElement?.querySelector('.teampass-toast-progress')
    if (progressBar) {
      progressBar.style.width = '100%'

      // Animate progress bar
      let progress = 100
      const steps = duration / 100 // Update every 100ms
      const decrement = 100 / steps

      this.progressInterval = setInterval(() => {
        progress -= decrement
        if (progress <= 0) {
          clearInterval(this.progressInterval)
        }
        progressBar.style.width = `${Math.max(0, progress)}%`
      }, 100)
    }

    // Auto-hide after duration
    this.hideTimer = setTimeout(() => {
      debugLog('Teampass toast: Auto-hiding')
      this.handleSkip() // Treat auto-hide as skip
    }, duration)
  }

  /**
   * Stop auto-hide timer
   */
  stopAutoHide() {
    if (this.hideTimer) {
      clearTimeout(this.hideTimer)
      this.hideTimer = null
    }

    if (this.progressInterval) {
      clearInterval(this.progressInterval)
      this.progressInterval = null
    }
  }

  /**
   * Hide toast
   *
   * @param {boolean} immediate - Hide immediately without animation
   */
  hide(immediate = false) {
    if (!this.toastElement) return

    // Stop auto-hide
    this.stopAutoHide()

    if (immediate) {
      // Remove immediately
      this.toastElement.remove()
      this.toastElement = null
    } else {
      // Animate out
      this.toastElement.classList.add('toast-hiding')

      setTimeout(() => {
        if (this.toastElement) {
          this.toastElement.remove()
          this.toastElement = null
        }
      }, 300) // Match animation duration
    }

    debugLog('Teampass toast hidden')
  }

  /**
   * Check if toast is currently visible
   *
   * @returns {boolean} True if toast is visible
   */
  isVisible() {
    return this.toastElement !== null && document.body.contains(this.toastElement)
  }
}

// Create singleton instance
const teampassToast = new TeampassToast()

// Export for use in content script
if (typeof window !== 'undefined') {
  window.teampassToast = teampassToast
}
