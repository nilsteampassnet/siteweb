# Teampass Browser Extension - Chrome

## Version 1.4.23

### Installation Instructions

#### Google Chrome


1. Open Chrome
2. Navigate to `chrome://extensions/`
3. Enable "Developer mode" (toggle in top-right corner)
4. Click "Load unpacked"
5. Select this directory
6. The extension is now installed


### Configuration

1. Right-click the extension icon → Options
2. Fill in your Teampass server details:
   - Server URL: https://your-teampass-server.com
   - Licence Email: your-email@company.com
   - Instance FQDN: your-server.com
   - Username: your_username
   - Password: your_password
   - API Key: your_api_key

3. Click "Save Configuration"
4. Click "Test Licence" to verify your licence
5. Click "Force Re-authenticate" to test connection

### Font Awesome

Font Awesome icons are **already included** in this package.

**Location**: `assets/fontawesome/`
- `fontawesome.min.css`
- `webfonts/fa-solid-900.woff2`
- `webfonts/fa-regular-400.woff2`

If icons are not displaying properly, verify that the `assets/fontawesome/` directory exists and contains the files above.

### Support

For issues or questions:
- Email: support@teampass.net
- Documentation: https://teampass.readthedocs.io/

### Licence

This extension requires a valid Teampass licence.
Licence verification is performed automatically.

© 2024 Teampass - Collaborative Password Manager
