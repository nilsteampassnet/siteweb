/**
 * Extension Name: Teampass Manager Extension
 * Copyright (c) 2026, LogCarré. All Rights Reserved.
 *
 * This code is proprietary software. It is distributed on a non-public, 
 * limited-use basis under the terms of a Commercial License.
 *
 * Unauthorized copying, modification, redistribution, or reverse engineering 
 * of this code, or any part thereof, is strictly prohibited.
 */

/**
 * Teampass Extension - Background Service Worker
 */

// Import ES6 modules (Firefox requires this instead of importScripts)
import { TeampassAPI } from '../lib/modules/api-client.js'
import { CryptoHelper } from '../lib/modules/crypto-helper.js'
import { LicenceChecker } from '../lib/modules/licence-checker.js'
import { TeampassJWTData, decodeTeampassJWT, getCurrentJWTData } from '../lib/modules/jwt-decoder.js'

// Debug logging state
let debugLoggingEnabled = false

/**
 * Initialize debug logging preference
 */
async function initDebugLogging() {
  try {
    const storage = await chrome.storage.local.get(['debug_logging_enabled'])
    debugLoggingEnabled = storage.debug_logging_enabled === true
  } catch (error) {
    // Silently fail, keep logging disabled
  }
}

/**
 * Conditional debug logging
 * Only logs if debug logging is enabled in settings
 */
function debugLog(...args) {
  if (debugLoggingEnabled) {
    console.log(...args)
  }
}

// Listen for debug logging preference changes
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'local' && changes.debug_logging_enabled) {
    const wasEnabled = debugLoggingEnabled
    debugLoggingEnabled = changes.debug_logging_enabled.newValue === true

    // Only log the state change if debug logging is/was enabled
    if (debugLoggingEnabled || wasEnabled) {
      console.log('Debug logging', debugLoggingEnabled ? 'enabled' : 'disabled')
    }
  }
})

let apiClient = null
let authState = {
  isAuthenticated: false,
  userId: null,
  username: null,
  allowedFolders: [],
  permissions: {}
}

// JWT data from decoded token
let jwtData = null

// Phase 3: Auto-refresh and credentials management
let autoRefreshTimer = null
let licenceCheckTimer = null
const cryptoHelper = new CryptoHelper()
const licenceChecker = new LicenceChecker()

// Auto-reauth protection
let isReauthenticating = false
let lastReauthAttempt = 0
const REAUTH_COOLDOWN = 5000 // 5 seconds cooldown between reauth attempts

/**
 * Decode JWT token and extract payload
 * @param {string} token - JWT token
 * @returns {Object|null} Decoded payload or null if invalid
 */
function decodeJWT(token) {
  try {
    // JWT format: header.payload.signature
    const parts = token.split('.')
    if (parts.length !== 3) {
      console.error('Invalid JWT format')
      return null
    }

    // Decode base64url payload (second part)
    const payload = parts[1]
    // Replace base64url chars with base64 chars
    const base64 = payload.replace(/-/g, '+').replace(/_/g, '/')
    // Pad with '=' if needed
    const padded = base64.padEnd(base64.length + (4 - base64.length % 4) % 4, '=')

    // Decode and parse JSON
    const decoded = atob(padded)
    return JSON.parse(decoded)
  } catch (error) {
    console.error('Error decoding JWT:', error)
    return null
  }
}

/**
 * Calculate token expiry time from JWT
 * @param {string} token - JWT token
 * @returns {Object} Object with expiryTime and duration in minutes
 */
function calculateTokenExpiry(token) {
  const payload = decodeJWT(token)

  if (payload && payload.api_token_duration) {
    // api_token_duration is in minutes, convert to milliseconds
    const durationMinutes = payload.api_token_duration
    const durationMs = durationMinutes * 60 * 1000
    const expiryTime = Date.now() + durationMs

    debugLog('Token duration from JWT:', durationMinutes, 'minutes')
    debugLog('Token will expire at:', new Date(expiryTime).toISOString())

    return { expiryTime, durationMinutes }
  }

  // Fallback to 1 hour if api_token_duration is not present
  console.warn('api_token_duration not found in JWT, using default 1 hour')
  return { expiryTime: Date.now() + (60 * 60 * 1000), durationMinutes: 60 }
}

/**
 * Update global JWT data from token
 * Decodes the JWT and stores all data in the global jwtData variable
 * @param {string} token - JWT token
 */
function updateJWTData(token) {
  try {
    jwtData = decodeTeampassJWT(token)
    if (jwtData) {
      debugLog('JWT data updated:', jwtData.toObject())
    } else {
      console.error('Failed to decode JWT data')
    }
  } catch (error) {
    console.error('Error updating JWT data:', error)
    jwtData = null
  }
}

/**
 * Calculate adaptive refresh threshold based on token duration
 * Strategy: Refresh when 25% of token lifetime remains (minimum 5 minutes)
 *
 * Examples:
 * - 60 min token → refresh at 15 min remaining
 * - 30 min token → refresh at 7.5 min remaining
 * - 120 min token → refresh at 30 min remaining
 * - 10 min token → refresh at 5 min remaining (minimum)
 *
 * @param {number} tokenDurationMinutes - Token duration in minutes
 * @returns {number} Refresh threshold in milliseconds
 */
function getAdaptiveRefreshThreshold(tokenDurationMinutes) {
  const MIN_THRESHOLD_MINUTES = 5
  const REFRESH_PERCENTAGE = 0.25 // Refresh at 25% remaining

  const calculatedThreshold = tokenDurationMinutes * REFRESH_PERCENTAGE
  const thresholdMinutes = Math.max(calculatedThreshold, MIN_THRESHOLD_MINUTES)
  const thresholdMs = thresholdMinutes * 60 * 1000

  debugLog('Adaptive refresh threshold:', thresholdMinutes, 'minutes', `(${Math.round(REFRESH_PERCENTAGE * 100)}% of ${tokenDurationMinutes} min token)`)

  return thresholdMs
}

chrome.runtime.onInstalled.addListener(async (details) => {
  debugLog('Teampass extension installed/updated:', details.reason)

  // Only initialize storage on first install, not on reload/update
  // This prevents overwriting user settings when reloading the extension
  if (details.reason === 'install') {
    debugLog('First install detected - initializing storage')
    await chrome.storage.local.set({
      teampass_configured: false,
      teampass_url: '',
      teampass_token: null,
      teampass_apikey: null,
      teampass_user: null,
      token_expiry: null,
      api_token_duration: null
    })
  } else {
    debugLog('Extension reloaded/updated - preserving existing storage')
  }
})

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  debugLog('Received message:', request.action)
  
  switch (request.action) {
    case 'testConnection':
      handleTestConnection(request.data)
        .then(result => sendResponse({ success: true, data: result }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true
      
    case 'authenticate':
      handleAuthenticate(request.data)
        .then(result => sendResponse({ success: true, data: result }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true
      
    case 'logout':
      handleLogout()
        .then(() => sendResponse({ success: true }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true
      
    case 'getAuthState':
      sendResponse({ success: true, data: authState })
      return false

    case 'getJWTData':
      // Return JWT data as plain object (or null if not authenticated)
      sendResponse({ success: true, data: jwtData ? jwtData.toObject() : null })
      return false

    case 'checkTokenValidity':
      handleCheckTokenValidity()
        .then(isValid => sendResponse({ success: true, data: isValid }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    case 'ensureValidToken':
      handleEnsureValidToken()
        .then(isValid => sendResponse({ success: true, data: isValid }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true
      
    case 'findItemsByUrl':
      handleFindItemsByUrl(request.data.url)
        .then(items => sendResponse({ success: true, data: items }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    case 'searchItemsByUrl':
      searchItemsByUrl(request.data.url)
        .then(items => sendResponse({ success: true, data: items }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    case 'globalSearch':
      handleGlobalSearch(request.data.searchTerm)
        .then(items => sendResponse({ success: true, data: items }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    case 'getItemPassword':
      handleGetItemPassword(request.data.itemId)
        .then(password => sendResponse({ success: true, data: password }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true
      
    case 'getItemDetails':
      handleGetItemDetails(request.data.itemId)
        .then(item => sendResponse({ success: true, data: item }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true
      
    case 'getOtp':
      handleGetOtp(request.data.itemId)
        .then(otpData => sendResponse({ success: true, data: otpData }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    case 'getWritableFolders':
      handleGetWritableFolders()
        .then(folders => sendResponse({ success: true, data: folders }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    case 'createItem':
      handleCreateItem(request.data.itemData)
        .then(item => sendResponse({ success: true, data: item }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    case 'updateItem':
      handleUpdateItem(request.data.itemId, request.data.itemData)
        .then(result => sendResponse({ success: true, data: result }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    case 'deleteItem':
      handleDeleteItem(request.data.itemId)
        .then(result => sendResponse({ success: true, data: result }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    case 'listFolders':
      handleListFolders()
        .then(folders => sendResponse({ success: true, data: folders }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    case 'updateBadge':
      updateBadgeForActiveTab()
        .then(() => sendResponse({ success: true }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    // New handlers for autofill markers feature
    case 'getItemsForAutofill':
      searchItemsByUrl(request.data.url)
        .then(items => sendResponse({ success: true, data: items }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    case 'getItemDetailsForAutofill':
      handleGetItemDetails(request.data.itemId)
        .then(item => sendResponse({ success: true, data: item }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    case 'getOtpForAutofill':
      handleGetOtp(request.data.itemId)
        .then(otpData => {
          // Return only the OTP code (API returns "otp_code" field)
          sendResponse({ success: true, data: otpData.otp_code })
        })
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    case 'saveSelectedItem':
      handleSaveSelectedItem(request.data.domain, request.data.itemId)
        .then(() => sendResponse({ success: true }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    case 'getSelectedItem':
      handleGetSelectedItem(request.data.domain)
        .then(itemId => sendResponse({ success: true, data: itemId }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    case 'checkCredentialExists':
      handleCheckCredentialExists(request.data.url, request.data.login)
        .then(result => sendResponse({ success: true, data: result }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    case 'openSavePopup':
      handleOpenSavePopup(request.data.mode, request.data.existingItem)
        .then(() => sendResponse({ success: true }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    case 'storeCredentialInSession':
      handleStoreCredentialInSession(request.data.credential)
        .then(() => sendResponse({ success: true }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    case 'getPendingCredential':
      handleGetPendingCredential()
        .then(credential => sendResponse({ success: true, data: credential }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    case 'removePendingCredential':
      handleRemovePendingCredential()
        .then(() => sendResponse({ success: true }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    case 'checkLicence':
      debugLog('[SERVICE-WORKER] Received checkLicence request from popup')
      licenceChecker.checkLicence()
        .then(result => {
          debugLog('[SERVICE-WORKER] Licence check completed:', result)
          sendResponse({ success: true, data: result })
        })
        .catch(error => {
          debugLog('[SERVICE-WORKER] Licence check failed:', error)
          sendResponse({ success: false, error: error.message })
        })
      return true

    default:
      sendResponse({ success: false, error: 'Unknown action' })
      return false
  }
})

async function handleTestConnection(data) {
  const { serverUrl } = data
  
  if (!serverUrl) {
    throw new Error('Server URL is required')
  }
  
  const testClient = new TeampassAPI(serverUrl)
  const isReachable = await testClient.testConnection()
  
  if (!isReachable) {
    throw new Error('Cannot reach Teampass server. Check URL and network.')
  }
  
  return true
}

async function handleAuthenticate(data) {
  const { serverUrl, username, password, apiKey } = data
  
  if (!serverUrl || !username || !password) {
    throw new Error('Server URL, username and password are required')
  }
  
  if (!apiKey) {
    throw new Error('API Key is required')
  }
  
  // Debug log
  debugLog('Authentication attempt:', {
    serverUrl,
    username,
    passwordLength: password.length,
    apiKeyLength: apiKey.length
  })
  
  apiClient = new TeampassAPI(serverUrl, null, apiKey)

  try {
    // Pass values directly without any transformation
    const authResponse = await apiClient.authenticate(username, password, apiKey)

    // Teampass API returns "token" not "jwt_token"
    const token = authResponse.token || authResponse.jwt_token

    if (!token) {
      throw new Error('Authentication failed: No token received')
    }

    // CRITICAL: Update the apiClient with the new token
    // Without this, all subsequent API calls will use null token and fail
    apiClient.setToken(token)

    // Calculate expiry time dynamically from JWT payload
    const { expiryTime, durationMinutes } = calculateTokenExpiry(token)

    // Decode and store all JWT data
    updateJWTData(token)

    // Extract permissions from decoded JWT data (not from authResponse which doesn't contain them)
    const permissions = jwtData ? jwtData.apiPermissions : {
      canCreate: false,
      canRead: false,
      canUpdate: false,
      canDelete: false
    }

    authState = {
      isAuthenticated: true,
      userId: jwtData ? jwtData.userId : (authResponse.user_id || authResponse.id),
      username: jwtData ? jwtData.username : username,
      allowedFolders: jwtData ? jwtData.allowedFolders : parseAllowedFolders(authResponse.allowed_folders || authResponse.folders_list),
      permissions: permissions
    }

    debugLog('Auth state updated with JWT permissions:', permissions)

    await chrome.storage.local.set({
      teampass_configured: true,
      teampass_url: serverUrl,
      teampass_token: token,
      teampass_apikey: apiKey,
      teampass_user: {
        id: authState.userId,
        username: username,
        allowedFolders: authState.allowedFolders
      },
      teampass_permissions: authState.permissions,
      token_expiry: expiryTime,
      api_token_duration: durationMinutes // Store duration for adaptive refresh
    })
    
    debugLog('Authentication successful for user:', username)

    // Update badge for active tab only (not all tabs to avoid overwhelming server)
    updateBadgeForActiveTab()

    return {
      userId: authState.userId,
      username: authState.username,
      permissions: authState.permissions
    }
  } catch (error) {
    console.error('Authentication error:', error)
    throw new Error(`Authentication failed: ${error.message}`)
  }
}

function parseAllowedFolders(allowedFolders) {
  if (!allowedFolders) return []
  if (Array.isArray(allowedFolders)) {
    return allowedFolders.map(id => parseInt(id, 10))
  }
  if (typeof allowedFolders === 'string') {
    return allowedFolders
      .split(',')
      .map(id => parseInt(id.trim(), 10))
      .filter(id => !isNaN(id))
  }
  return []
}

async function handleLogout() {
  authState = {
    isAuthenticated: false,
    userId: null,
    username: null,
    allowedFolders: [],
    permissions: {}
  }

  apiClient = null

  await chrome.storage.local.set({
    teampass_configured: true,
    teampass_token: null,
    teampass_apikey: null,
    teampass_user: null,
    teampass_permissions: null,
    token_expiry: null,
    api_token_duration: null
  })

  // Clear badges for all tabs after logout
  updateBadgeForAllTabs()

  debugLog('User logged out')
}

async function handleCheckTokenValidity() {
  const storage = await chrome.storage.local.get(['token_expiry', 'teampass_token'])

  if (!storage.teampass_token) return false

  if (!storage.token_expiry || Date.now() > storage.token_expiry) {
    await handleLogout()
    return false
  }

  return true
}

/**
 * Ensure token is valid, attempting auto-refresh if expired or expiring soon
 *
 * @returns {Promise<boolean>} True if token is valid or was refreshed successfully
 */
async function handleEnsureValidToken() {
  const storage = await chrome.storage.local.get(['token_expiry', 'teampass_token', 'api_token_duration'])

  if (!storage.teampass_token) {
    debugLog('ensureValidToken: No token, attempting auto-reauth')
    return await handleAutoReauth()
  }

  if (!storage.token_expiry) {
    debugLog('ensureValidToken: No expiry time, attempting auto-reauth')
    return await handleAutoReauth()
  }

  const timeUntilExpiry = storage.token_expiry - Date.now()

  // Use adaptive threshold based on token duration (25% of token lifetime, min 5 minutes)
  const tokenDuration = storage.api_token_duration || 60 // Fallback to 60 minutes
  const refreshThreshold = getAdaptiveRefreshThreshold(tokenDuration)

  // Token expired or expiring soon
  if (timeUntilExpiry < refreshThreshold) {
    debugLog(`ensureValidToken: Token expires in ${Math.round(timeUntilExpiry / 60000)} minutes (threshold: ${Math.round(refreshThreshold / 60000)} min), attempting auto-reauth`)
    return await handleAutoReauth()
  }

  debugLog(`ensureValidToken: Token valid for ${Math.round(timeUntilExpiry / 60000)} minutes`)
  return true
}

async function initializeAuthState() {
  const storage = await chrome.storage.local.get([
    'teampass_url',
    'teampass_token',
    'teampass_apikey',
    'teampass_user',
    'teampass_permissions',
    'token_expiry'
  ])
  
  if (storage.teampass_token && storage.token_expiry) {
    if (Date.now() < storage.token_expiry) {
      apiClient = new TeampassAPI(
        storage.teampass_url,
        storage.teampass_token,
        storage.teampass_apikey
      )

      authState = {
        isAuthenticated: true,
        userId: storage.teampass_user?.id || null,
        username: storage.teampass_user?.username || null,
        allowedFolders: storage.teampass_user?.allowedFolders || [],
        permissions: storage.teampass_permissions || {}
      }

      // Decode and store JWT data from token
      updateJWTData(storage.teampass_token)

      debugLog('Auth state restored from storage')
    } else {
      // Token expired during initialization - attempt auto-reauth
      debugLog('Token expired during initialization, attempting auto-reauth...')
      const refreshed = await handleAutoReauth()

      if (!refreshed) {
        debugLog('Auto-reauth failed during initialization, logging out')
        await handleLogout()
      } else {
        debugLog('Auto-reauth successful during initialization')
      }
    }
  }
}

/**
 * Attempt automatic re-authentication when token expires
 *
 * @returns {Promise<boolean>} True if re-authentication successful
 */
async function handleAutoReauth() {
  // Prevent simultaneous reauth attempts
  if (isReauthenticating) {
    debugLog('Auto re-auth: Already in progress, waiting...')
    // Wait for ongoing reauth to complete (max 10 seconds)
    let waited = 0
    while (isReauthenticating && waited < 10000) {
      await new Promise(resolve => setTimeout(resolve, 500))
      waited += 500
    }
    // Check if token is now valid
    const storage = await chrome.storage.local.get(['token_expiry'])
    if (storage.token_expiry && Date.now() < storage.token_expiry) {
      debugLog('Auto re-auth: Token refreshed by another process')
      return true
    }
    debugLog('Auto re-auth: Wait timeout or still invalid')
    return false
  }

  // Check cooldown period to prevent rapid repeated attempts
  const now = Date.now()
  if (now - lastReauthAttempt < REAUTH_COOLDOWN) {
    debugLog(`Auto re-auth: In cooldown period (${Math.round((REAUTH_COOLDOWN - (now - lastReauthAttempt)) / 1000)}s remaining)`)
    return false
  }

  isReauthenticating = true
  lastReauthAttempt = now

  try {
    debugLog('Auto re-auth: Token expired, attempting automatic re-authentication')

    // Get stored credentials (encrypted) and check licence in parallel to reduce latency
    debugLog('Auto re-auth: Starting parallel checks (licence + credentials)...')

    const [licenceResult, storage] = await Promise.all([
      licenceChecker.checkLicence(),
      chrome.storage.local.get([
        'teampass_url',
        'teampass_credentials_encrypted',
        'teampass_remember_me'
      ])
    ])

    // Check licence result first (security gate)
    if (!licenceResult.valid) {
      // Distinguish between technical errors and actual licence invalidity
      const isTechnicalError =
        licenceResult.message.includes('never been validated') ||
        licenceResult.message.includes('check your connection') ||
        licenceResult.message.includes('not configured')

      if (isTechnicalError) {
        // Technical error - log warning but allow auto-reauth to continue
        console.warn('Auto re-auth: Licence check failed (technical issue), continuing with auto-reauth:', licenceResult.message)
      } else {
        // Actual licence invalidity (expired, invalid, limit exceeded) - block
        console.error('Auto re-auth: BLOCKED - Licence invalid:', licenceResult.message)
        // Logout user due to invalid licence
        await handleLogout()
        // Notify user through popup/badge
        chrome.action.setBadgeText({ text: '!' })
        chrome.action.setBadgeBackgroundColor({ color: '#FF0000' })
        return false
      }
    } else {
      debugLog('Auto re-auth: Licence valid -', licenceResult.message)
    }

    // Check if remember me is enabled and credentials are saved
    if (!storage.teampass_remember_me || !storage.teampass_credentials_encrypted) {
      console.error('Auto re-auth: Remember me not enabled or no saved credentials')
      return false
    }

    if (!storage.teampass_url) {
      console.error('Auto re-auth: Missing server URL')
      return false
    }

    debugLog('Auto re-auth: Encrypted credentials found, decrypting...')

    // Decrypt credentials
    const credentials = await cryptoHelper.decryptCredentials(storage.teampass_credentials_encrypted)

    debugLog('Auto re-auth: Credentials decrypted, re-authenticating...')

    // Re-authenticate with JWT
    const result = await handleAuthenticate({
      serverUrl: storage.teampass_url,
      username: credentials.username,
      password: credentials.password,
      apiKey: credentials.apiKey
    })

    debugLog('Auto re-auth: SUCCESS - Token refreshed')
    return true
  } catch (error) {
    console.error('Auto re-auth: ERROR -', error)
    return false
  } finally {
    isReauthenticating = false
  }
}

/**
 * Wrapper to handle TOKEN_EXPIRED errors with automatic re-authentication
 *
 * @param {Function} apiCallFunction - Async function that makes API call
 * @param {string} operationName - Name of operation for logging
 * @param {number} retryCount - Internal counter to prevent infinite loops (default 0)
 * @returns {Promise<any>} Result of API call
 */
async function withAutoReauth(apiCallFunction, operationName, retryCount = 0) {
  // Prevent infinite retry loops - max 1 retry
  const MAX_RETRIES = 1

  try {
    return await apiCallFunction()
  } catch (error) {
    // Check if it's a network error (server unreachable)
    const isNetworkError = error.message === 'Failed to fetch' ||
                          error.message.includes('fetch') ||
                          error.message.includes('network')

    if (isNetworkError) {
      console.error(`${operationName}: Network error - server unreachable:`, error.message)
      // Don't retry on network errors, just fail gracefully
      return retryCount === 0 ? [] : null // Return empty array on first attempt, null on retry
    }

    // Only retry on TOKEN_EXPIRED and if we haven't exceeded max retries
    if (error.message === 'TOKEN_EXPIRED' && retryCount < MAX_RETRIES) {
      debugLog(`${operationName}: Token expired, attempting auto re-authentication... (attempt ${retryCount + 1}/${MAX_RETRIES})`)
      const reauthed = await handleAutoReauth()

      if (reauthed) {
        debugLog(`${operationName}: Auto re-auth successful, retrying operation...`)
        try {
          // Recursive call with incremented retry count
          return await withAutoReauth(apiCallFunction, operationName, retryCount + 1)
        } catch (retryError) {
          console.error(`${operationName}: Retry after re-auth failed:`, retryError)
          // Check if retry error is also network error
          const isRetryNetworkError = retryError.message === 'Failed to fetch' ||
                                     retryError.message.includes('fetch')
          if (isRetryNetworkError) {
            console.error(`${operationName}: Server unreachable after re-auth`)
            return [] // Return empty array instead of throwing
          }
          throw new Error(`Failed after re-authentication: ${retryError.message}`)
        }
      } else {
        console.error(`${operationName}: Auto re-auth failed`)
        throw new Error('Session expired - please re-authenticate in Options')
      }
    } else if (error.message === 'TOKEN_EXPIRED' && retryCount >= MAX_RETRIES) {
      console.error(`${operationName}: Max retry attempts (${MAX_RETRIES}) reached, giving up`)
      throw new Error('Authentication failed after multiple attempts - please re-authenticate in Options')
    }

    throw error
  }
}

/**
 * Find items by URL (Phase 2)
 *
 * @param {string} url - URL to search for
 * @returns {Promise<Array>} List of matching items
 */
async function handleFindItemsByUrl(url) {
  if (!apiClient) {
    // Throw TOKEN_EXPIRED instead of 'Not authenticated' to trigger auto-reauth
    throw new Error('TOKEN_EXPIRED')
  }

  return await withAutoReauth(
    async () => {
      const items = await apiClient.findByUrl(url)
      return items || []
    },
    'Find items by URL'
  )
}

/**
 * Global search for items by label
 *
 * @param {string} searchTerm - Search term for label
 * @returns {Promise<Array>} List of matching items
 */
async function handleGlobalSearch(searchTerm) {
  if (!apiClient) {
    // Throw TOKEN_EXPIRED instead of 'Not authenticated' to trigger auto-reauth
    throw new Error('TOKEN_EXPIRED')
  }

  return await withAutoReauth(
    async () => {
      const items = await apiClient.globalSearch(searchTerm)
      return items || []
    },
    'Global search'
  )
}

/**
 * Get item password (Phase 2)
 * Retrieves item details and returns only the decrypted password
 * 
 * @param {number} itemId - Item ID
 * @returns {Promise<string>} Decrypted password
 */
async function handleGetItemPassword(itemId) {
  if (!apiClient) {
    // Throw TOKEN_EXPIRED instead of 'Not authenticated' to trigger auto-reauth
    throw new Error('TOKEN_EXPIRED')
  }
  
  return await withAutoReauth(
    async () => {
      const items = await apiClient.getItem(itemId)
      
      // API returns array with single item
      if (Array.isArray(items) && items.length > 0) {
        return items[0].pwd || ''
      }
      
      throw new Error('Item not found')
    },
    'Get item password'
  )
}

/**
 * Get complete item details (Phase 2)
 * 
 * @param {number} itemId - Item ID
 * @returns {Promise<object>} Complete item with decrypted password
 */
async function handleGetItemDetails(itemId) {
  if (!apiClient) {
    // Throw TOKEN_EXPIRED instead of 'Not authenticated' to trigger auto-reauth
    throw new Error('TOKEN_EXPIRED')
  }
  
  return await withAutoReauth(
    async () => {
      const items = await apiClient.getItem(itemId)
      
      // API returns array with single item
      if (Array.isArray(items) && items.length > 0) {
        return items[0]
      }
      
      throw new Error('Item not found')
    },
    'Get item details'
  )
}

/**
 * Get OTP/TOTP code for an item
 *
 * @param {number} itemId - Item ID
 * @returns {Promise<object>} OTP data with code and expiry
 */
async function handleGetOtp(itemId) {
  if (!apiClient) {
    // Throw TOKEN_EXPIRED instead of 'Not authenticated' to trigger auto-reauth
    throw new Error('TOKEN_EXPIRED')
  }


  return await withAutoReauth(
    async () => {
      const otpData = await apiClient.getOtp(itemId)
      return otpData
    },
    'Get OTP'
  )
}

/**
 * Get writable folders
 * Returns folders where the user has write access
 *
 * @returns {Promise<Array>} Array of writable folders
 */
async function handleGetWritableFolders() {
  if (!apiClient) {
    // Throw TOKEN_EXPIRED instead of 'Not authenticated' to trigger auto-reauth
    throw new Error('TOKEN_EXPIRED')
  }

  return await withAutoReauth(
    async () => {
      const folders = await apiClient.getWritableFolders()
      return folders
    },
    'Get writable folders'
  )
}

/**
 * Create new item
 *
 * @param {object} itemData - Item data
 * @returns {Promise<object>} Created item
 */
async function handleCreateItem(itemData) {
  if (!apiClient) {
    // Throw TOKEN_EXPIRED instead of 'Not authenticated' to trigger auto-reauth
    throw new Error('TOKEN_EXPIRED')
  }

  return await withAutoReauth(
    async () => {
      const item = await apiClient.createItem(itemData)
      return item
    },
    'Create item'
  )
}

/**
 * Update an existing item
 *
 * @param {number} itemId - Item ID
 * @param {object} itemData - Updated item data
 * @returns {Promise<object>} Update response
 */
async function handleUpdateItem(itemId, itemData) {
  if (!apiClient) {
    // Throw TOKEN_EXPIRED instead of 'Not authenticated' to trigger auto-reauth
    throw new Error('TOKEN_EXPIRED')
  }

  if (!itemId) {
    throw new Error('Item ID is required')
  }

  if (!itemData || Object.keys(itemData).length === 0) {
    throw new Error('At least one field to update must be provided')
  }

  debugLog('Update item request:', { itemId, itemData })

  return await withAutoReauth(
    async () => {
      const result = await apiClient.updateItem(itemId, itemData)
      debugLog('Update item response:', result)
      return result
    },
    'Update item'
  )
}

/**
 * Delete an item
 *
 * @param {number} itemId - Item ID to delete
 * @returns {Promise<object>} Delete response
 */
async function handleDeleteItem(itemId) {
  if (!apiClient) {
    // Throw TOKEN_EXPIRED instead of 'Not authenticated' to trigger auto-reauth
    throw new Error('TOKEN_EXPIRED')
  }

  if (!itemId) {
    throw new Error('Item ID is required')
  }

  debugLog('Delete item request:', { itemId })

  return await withAutoReauth(
    async () => {
      const result = await apiClient.deleteItem(itemId)
      debugLog('Delete item response:', result)
      return result
    },
    'Delete item'
  )
}

/**
 * List accessible folders
 *
 * @returns {Promise<Array>} List of folders
 */
async function handleListFolders() {
  if (!apiClient) {
    // Throw TOKEN_EXPIRED instead of 'Not authenticated' to trigger auto-reauth
    throw new Error('TOKEN_EXPIRED')
  }

  return await withAutoReauth(
    async () => {
      const folders = await apiClient.listFolders()
      return folders || []
    },
    'List folders'
  )
}

/**
 * Start auto-refresh timer (Phase 3)
 * Checks every 5 minutes if token needs refresh
 *
 * @returns {void}
 */
function startAutoRefreshTimer() {
  // Clear existing timer
  if (autoRefreshTimer) {
    clearInterval(autoRefreshTimer)
  }
  
  // Check immediately
  checkAndRefreshToken()

  // Then check every 3 minutes (more proactive)
  autoRefreshTimer = setInterval(checkAndRefreshToken, 3 * 60 * 1000)
  debugLog('Auto-refresh timer started (checks every 3 minutes)')
}

/**
 * Check if token needs refresh and refresh if necessary
 * 
 * @returns {Promise<void>}
 */
async function checkAndRefreshToken() {
  try {
    const storage = await chrome.storage.local.get([
      'teampass_auto_refresh',
      'teampass_remember_me',
      'teampass_credentials_encrypted',
      'teampass_url',
      'teampass_token',
      'token_expiry',
      'api_token_duration'
    ])

    // Auto-refresh disabled or no credentials saved
    if (!storage.teampass_auto_refresh || !storage.teampass_remember_me || !storage.teampass_credentials_encrypted) {
      return
    }

    // No token or token doesn't expire (shouldn't happen)
    if (!storage.teampass_token || !storage.token_expiry) {
      debugLog('Auto-refresh: No token, attempting login')
      await attemptAutoLogin()
      return
    }

    // Use adaptive threshold based on token duration (25% of token lifetime, min 5 minutes)
    const timeUntilExpiry = storage.token_expiry - Date.now()
    const tokenDuration = storage.api_token_duration || 60 // Fallback to 60 minutes
    const threshold = getAdaptiveRefreshThreshold(tokenDuration)

    if (timeUntilExpiry < threshold) {
      debugLog('Auto-refresh: Token expiring soon, refreshing...')
      debugLog(`Auto-refresh: ${Math.round(timeUntilExpiry / 60000)} min remaining (threshold: ${Math.round(threshold / 60000)} min)`)
      await attemptAutoLogin()
    } else {
      debugLog('Auto-refresh: Token still valid for', Math.round(timeUntilExpiry / 60000), 'minutes')
    }

  } catch (error) {
    console.error('Auto-refresh error:', error)
  }
}

/**
 * Attempt auto-login with saved credentials
 * 
 * @returns {Promise<void>}
 */
async function attemptAutoLogin() {
  try {
    const storage = await chrome.storage.local.get([
      'teampass_url',
      'teampass_credentials_encrypted'
    ])

    if (!storage.teampass_url || !storage.teampass_credentials_encrypted) {
      debugLog('Auto-login: No saved credentials')
      return
    }

    // Decrypt credentials
    const credentials = await cryptoHelper.decryptCredentials(storage.teampass_credentials_encrypted)

    // Authenticate
    debugLog('Auto-login: Attempting authentication...')
    await handleAuthenticate({
      serverUrl: storage.teampass_url,
      username: credentials.username,
      password: credentials.password,
      apiKey: credentials.apiKey
    })

    debugLog('Auto-login: Success!')
    
  } catch (error) {
    console.error('Auto-login error:', error)
  }
}

/**
 * Update badge for a tab based on number of items found
 *
 * @param {number} tabId - Tab ID
 * @param {string} url - Tab URL
 * @returns {Promise<void>}
 */
async function updateBadgeForTab(tabId, url) {
  try {
    // PRIORITY: Check if there's a pending save - don't overwrite save badge
    const storage = await chrome.storage.local.get(['popup_save_mode'])
    if (storage.popup_save_mode) {
      debugLog('Skipping badge update: Pending save has priority')
      return // Keep the save badge (💾) - don't overwrite it
    }

    // Only process http/https URLs
    if (!url || (!url.startsWith('http://') && !url.startsWith('https://'))) {
      chrome.action.setBadgeText({ text: '', tabId })
      return
    }

    // Check if authenticated
    if (!apiClient || !authState.isAuthenticated) {
      chrome.action.setBadgeText({ text: '', tabId })
      return
    }

    // Use centralized search strategy
    const items = await searchItemsByUrl(url)

    // Update badge
    if (items && items.length > 0) {
      chrome.action.setBadgeText({
        text: items.length.toString(),
        tabId
      })
      chrome.action.setBadgeBackgroundColor({
        color: '#4CAF50',
        tabId
      })
    } else {
      chrome.action.setBadgeText({ text: '', tabId })
    }

  } catch (error) {
    console.error('Badge update error:', error)
    chrome.action.setBadgeText({ text: '', tabId })
  }
}

/**
 * Update badge for the currently active tab
 *
 * @returns {Promise<void>}
 */
async function updateBadgeForActiveTab() {
  try {
    const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true })

    if (activeTab && activeTab.id && activeTab.url) {
      await updateBadgeForTab(activeTab.id, activeTab.url)
      debugLog('Badge updated for active tab:', activeTab.url)
    }
  } catch (error) {
    console.error('Failed to update badge for active tab:', error)
  }
}

/**
 * Update badge for all tabs
 * Used primarily after logout to clear all badges
 * Note: For most operations, use updateBadgeForActiveTab() instead to avoid overwhelming the server
 *
 * @returns {Promise<void>}
 */
async function updateBadgeForAllTabs() {
  try {
    const tabs = await chrome.tabs.query({})

    // Process tabs sequentially with a small delay to avoid overwhelming the server
    for (const tab of tabs) {
      if (tab.id && tab.url) {
        await updateBadgeForTab(tab.id, tab.url)
        // Small delay between tab updates to prevent overwhelming server
        await new Promise(resolve => setTimeout(resolve, 100))
      }
    }
  } catch (error) {
    console.error('Failed to update badges for all tabs:', error)
  }
}

/**
 * Save selected item for a domain (for autofill memory)
 *
 * @param {string} domain - Domain URL
 * @param {number} itemId - Item ID
 * @returns {Promise<void>}
 */
async function handleSaveSelectedItem(domain, itemId) {
  try {
    // Get existing selected items
    const storage = await chrome.storage.session.get(['teampass_selected_items'])
    const selectedItems = storage.teampass_selected_items || {}

    // Save item ID for this domain
    selectedItems[domain] = {
      itemId,
      timestamp: Date.now()
    }

    // Save back to storage
    await chrome.storage.session.set({ teampass_selected_items: selectedItems })

    debugLog(`Selected item ${itemId} saved for domain ${domain}`)
  } catch (error) {
    console.error('Error saving selected item:', error)
    throw error
  }
}

/**
 * Get selected item for a domain (for autofill memory)
 *
 * @param {string} domain - Domain URL
 * @returns {Promise<number|null>} Item ID or null
 */
async function handleGetSelectedItem(domain) {
  try {
    // Get selected items from storage
    const storage = await chrome.storage.session.get(['teampass_selected_items'])
    const selectedItems = storage.teampass_selected_items || {}

    // Check if there's a selected item for this domain
    const selected = selectedItems[domain]

    if (selected && selected.itemId) {
      // Check if selection is recent (within 24 hours)
      const age = Date.now() - selected.timestamp
      const maxAge = 24 * 60 * 60 * 1000 // 24 hours

      if (age < maxAge) {
        debugLog(`Found selected item ${selected.itemId} for domain ${domain}`)
        return selected.itemId
      } else {
        debugLog(`Selected item for ${domain} is too old, ignoring`)
      }
    }

    return null
  } catch (error) {
    console.error('Error getting selected item:', error)
    return null
  }
}

/**
 * Check if credential already exists in Teampass
 * Searches by URL and login to find matching entries
 *
 * @param {string} url - URL to search for
 * @param {string} login - Login/username to match
 * @returns {Promise<object>} Result with exists, mode, item, and hasChanged flags
 */
/**
 * Extract base domain from hostname
 * @param {string} hostname - Hostname to extract base domain from
 * @returns {string} Base domain
 */
function getBaseDomain(hostname) {
  if (!hostname) return hostname

  const parts = hostname.split('.')

  // If only 2 parts or less, return as is
  if (parts.length <= 2) {
    return hostname
  }

  // Check for special TLDs
  const lastTwo = parts.slice(-2).join('.')
  const specialTlds = ['co.uk', 'com.au', 'co.nz', 'co.za', 'com.br', 'co.jp']

  if (specialTlds.includes(lastTwo)) {
    return parts.slice(-3).join('.')
  }

  // Standard case: take last 2 parts
  return parts.slice(-2).join('.')
}

/**
 * Normalize URL for comparison
 * Removes query params, fragments, and trailing slashes
 * @param {string} url - URL to normalize
 * @returns {string} Normalized URL
 */
function normalizeUrlForComparison(url) {
  try {
    const urlObj = new URL(url)
    let normalized = `${urlObj.protocol}//${urlObj.hostname}${urlObj.pathname}`

    // Remove trailing slash (except for root)
    if (normalized.endsWith('/') && normalized.length > urlObj.origin.length + 1) {
      normalized = normalized.slice(0, -1)
    }

    return normalized.toLowerCase()
  } catch (error) {
    // If URL parsing fails, just lowercase and remove trailing slash
    const cleaned = url.endsWith('/') ? url.slice(0, -1) : url
    return cleaned.toLowerCase()
  }
}

/**
 * Calculate match score between current page URL and an item's URL
 * Higher score = better match
 *
 * Scoring system:
 * - 100: Exact URL match (normalized)
 * - 90: Same protocol + hostname + path prefix match
 * - 70: Same protocol + hostname
 * - 50: Same hostname (different protocol)
 * - 30: Same subdomain under base domain
 * - 20: Same base domain only
 * - 0: No match
 *
 * @param {string} pageUrl - Current page URL
 * @param {string} itemUrl - Item's stored URL
 * @returns {number} Match score (0-100)
 */
function calculateUrlMatchScore(pageUrl, itemUrl) {
  if (!pageUrl || !itemUrl) return 0

  try {
    const pageNormalized = normalizeUrlForComparison(pageUrl)
    const itemNormalized = normalizeUrlForComparison(itemUrl)

    // Exact match
    if (pageNormalized === itemNormalized) {
      return 100
    }

    const pageUrlObj = new URL(pageUrl)
    const itemUrlObj = new URL(itemUrl)

    const pageHostname = pageUrlObj.hostname.toLowerCase()
    const itemHostname = itemUrlObj.hostname.toLowerCase()
    const pageProtocol = pageUrlObj.protocol
    const itemProtocol = itemUrlObj.protocol
    const pagePath = pageUrlObj.pathname.toLowerCase()
    const itemPath = itemUrlObj.pathname.toLowerCase()

    // Same protocol + hostname
    if (pageProtocol === itemProtocol && pageHostname === itemHostname) {
      // Check path similarity
      if (pagePath === itemPath) {
        return 95 // Same path (query params might differ)
      }

      // Check if one path is prefix of another
      if (pagePath.startsWith(itemPath) || itemPath.startsWith(pagePath)) {
        const pathSimilarity = Math.min(pagePath.length, itemPath.length) / Math.max(pagePath.length, itemPath.length)
        return 70 + (pathSimilarity * 20) // 70-90 based on path similarity
      }

      return 70 // Same protocol + hostname, different paths
    }

    // Same hostname, different protocol
    if (pageHostname === itemHostname) {
      return 50
    }

    // Check if both are subdomains of the same base domain
    const pageBaseDomain = getBaseDomain(pageHostname)
    const itemBaseDomain = getBaseDomain(itemHostname)

    if (pageBaseDomain === itemBaseDomain) {
      // Both share the same base domain
      // Higher score if they share more subdomain parts
      const pageeParts = pageHostname.split('.')
      const itemParts = itemHostname.split('.')

      let matchingParts = 0
      for (let i = 1; i <= Math.min(pageeParts.length, itemParts.length); i++) {
        const pageePart = pageeParts[pageeParts.length - i]
        const itemPart = itemParts[itemParts.length - i]
        if (pageePart === itemPart) {
          matchingParts++
        } else {
          break
        }
      }

      // More matching parts = higher score (20-40)
      return 20 + (matchingParts * 5)
    }

    return 0
  } catch (error) {
    debugLog('Error calculating URL match score:', error)
    return 0
  }
}

/**
 * Centralized URL search strategy with scoring
 * Searches for items using a 4-step strategy, starting from most specific to most flexible
 * All results are scored based on URL match quality and sorted by best match
 *
 * Strategy (reversed for better matching):
 * 1. Full URL (most specific) - complete path
 * 2. Protocol + hostname - e.g., https://satisfaction.vdlconseil.fr
 * 3. Full hostname - e.g., satisfaction.vdlconseil.fr
 * 4. Base domain (most flexible) - e.g., vdlconseil.fr
 *
 * @param {string} url - URL to search for
 * @returns {Promise<Array>} Array of matching items, sorted by match score (best first)
 */
async function searchItemsByUrl(url) {
  try {
    const urlObj = new URL(url)
    const hostname = urlObj.hostname
    const baseDomain = getBaseDomain(hostname)
    const domainUrl = `${urlObj.protocol}//${hostname}`

    // Collect all items from all search strategies
    const allItems = new Map() // Use Map to deduplicate by ID
    let networkError = false

    // Helper function to try a search and collect results
    const trySearch = async (searchUrl, strategyName) => {
      if (networkError) return

      debugLog(`URL Search Strategy - ${strategyName}:`, searchUrl)
      try {
        const items = await handleFindItemsByUrl(searchUrl)
        if (items && items.length > 0) {
          debugLog(`Found ${items.length} items via ${strategyName}`)

          // Add items to collection with their match score
          items.forEach(item => {
            if (!allItems.has(item.id)) {
              // Calculate match score for this item
              const score = calculateUrlMatchScore(url, item.url || '')
              allItems.set(item.id, {
                ...item,
                _matchScore: score
              })
            }
          })
        }
      } catch (error) {
        debugLog(`${strategyName} search failed:`, error)
        if (error.message === 'Failed to fetch' || error.message.includes('fetch')) {
          networkError = true
          debugLog('Network error detected, stopping search')
        }
      }
    }

    // Execute searches in order: most specific to most flexible
    // Strategy 1: Full URL (most specific)
    await trySearch(url, 'Full URL')

    // Strategy 2: Protocol + hostname
    if (!networkError) {
      await trySearch(domainUrl, 'Protocol + Hostname')
    }

    // Strategy 3: Hostname only
    if (!networkError) {
      await trySearch(hostname, 'Hostname')
    }

    // Strategy 4: Base domain (most flexible)
    if (!networkError) {
      await trySearch(baseDomain, 'Base Domain')
    }

    if (networkError) {
      debugLog('Network error encountered during search')
      return []
    }

    // Convert Map to Array and sort by match score (highest first)
    const sortedItems = Array.from(allItems.values())
      .sort((a, b) => (b._matchScore || 0) - (a._matchScore || 0))

    debugLog(`Total unique items found: ${sortedItems.length}`)
    if (sortedItems.length > 0) {
      debugLog('Top 3 matches:', sortedItems.slice(0, 3).map(item => ({
        id: item.id,
        label: item.label,
        url: item.url,
        score: item._matchScore
      })))
    }

    return sortedItems

  } catch (error) {
    console.error('Error in searchItemsByUrl:', error)
    return []
  }
}

async function handleCheckCredentialExists(url, login) {
  if (!apiClient) {
    // Throw TOKEN_EXPIRED instead of 'Not authenticated' to trigger auto-reauth
    throw new Error('TOKEN_EXPIRED')
  }

  debugLog('Checking for existing credential:', { url, login })

  try {
    // Get pending credential from session storage to compare password
    const session = await chrome.storage.session.get(['pendingCredential'])
    const pendingPassword = session.pendingCredential?.password

    // Use centralized search strategy
    const items = await searchItemsByUrl(url)

    if (!items || items.length === 0) {
      debugLog('No existing items found for URL')
      return {
        exists: false,
        mode: 'new',
        item: null,
        hasChanged: false
      }
    }

    // Check if any item matches the login
    const matchingItem = items.find(item => {
      const itemLogin = item.login || ''
      return itemLogin.toLowerCase() === login.toLowerCase()
    })

    if (!matchingItem) {
      debugLog('No matching login found')
      return {
        exists: false,
        mode: 'new',
        item: null,
        hasChanged: false
      }
    }

    debugLog('Matching item found:', matchingItem.id)

    // Get full item details to compare password
    const fullItem = await handleGetItemDetails(matchingItem.id)
    const existingPassword = fullItem.pwd || ''

    // Check if password has changed
    const hasChanged = pendingPassword && existingPassword !== pendingPassword

    debugLog('Password changed:', hasChanged)

    return {
      exists: true,
      mode: 'update',
      item: fullItem,
      hasChanged
    }

  } catch (error) {
    console.error('Error checking existing credential:', error)
    // On error, default to new mode
    return {
      exists: false,
      mode: 'new',
      item: null,
      hasChanged: false
    }
  }
}

/**
 * Open popup in save mode
 * Stores the save mode in storage for popup to read
 *
 * @param {string} mode - Save mode ('new', 'update', or 'advanced')
 * @param {object|null} existingItem - Existing item data if update mode
 * @returns {Promise<void>}
 */
async function handleOpenSavePopup(mode, existingItem) {
  debugLog('Opening popup in save mode:', mode)

  try {
    // Store save mode in local storage for popup to read
    await chrome.storage.local.set({
      popup_save_mode: mode,
      popup_existing_item: existingItem || null
    })

    // ALWAYS show badge to notify user there's a pending save
    // Badge will persist until user opens popup and saves/skips
    try {
      await chrome.action.setBadgeText({ text: '💾' })
      await chrome.action.setBadgeBackgroundColor({ color: '#4CAF50' })
      debugLog('Badge set: Pending credential save')
    } catch (badgeError) {
      debugLog('Failed to set badge:', badgeError.message)
    }

    // Try to open popup (will likely fail due to no user gesture context)
    // But we try anyway in case Chrome allows it in some contexts
    try {
      await chrome.action.openPopup()
      debugLog('Popup opened successfully in', mode, 'mode')
    } catch (popupError) {
      // Expected to fail - user will see badge and click icon
      debugLog('chrome.action.openPopup() failed (expected):', popupError.message)
      debugLog('User will see badge and click extension icon')
    }

  } catch (error) {
    console.error('Failed to prepare save mode:', error.message)
  }
}

/**
 * Store credential in session storage
 * Acts as proxy for content scripts that can't access storage directly
 *
 * @param {object} credential - Credential data to store
 * @returns {Promise<void>}
 */
async function handleStoreCredentialInSession(credential) {
  debugLog('Storing credential in session storage:', { domain: credential.domain, username: credential.username })

  try {
    await chrome.storage.session.set({
      pendingCredential: credential
    })
    debugLog('Credential stored successfully')
  } catch (error) {
    console.error('Error storing credential in session:', error)
    throw error
  }
}

/**
 * Get pending credential from session storage
 * Acts as proxy for content scripts that can't access storage directly
 *
 * @returns {Promise<object|null>} Pending credential or null
 */
async function handleGetPendingCredential() {
  debugLog('Getting pending credential from session storage')

  try {
    const session = await chrome.storage.session.get(['pendingCredential'])
    const credential = session.pendingCredential || null
    debugLog('Pending credential retrieved:', credential ? { domain: credential.domain, username: credential.username } : 'none')
    return credential
  } catch (error) {
    console.error('Error getting pending credential from session:', error)
    throw error
  }
}

/**
 * Remove pending credential from session storage
 * Acts as proxy for content scripts that can't access storage directly
 *
 * @returns {Promise<void>}
 */
async function handleRemovePendingCredential() {
  debugLog('Removing pending credential from session storage')

  try {
    // Remove pending credential and save mode
    await chrome.storage.session.remove('pendingCredential')
    await chrome.storage.local.remove(['popup_save_mode', 'popup_existing_item'])

    // Clear the save badge since credential has been saved or skipped
    try {
      await chrome.action.setBadgeText({ text: '' })
      debugLog('Badge cleared: Credential saved/skipped')
    } catch (badgeError) {
      debugLog('Failed to clear badge:', badgeError.message)
    }

    debugLog('Pending credential and save mode removed successfully')
  } catch (error) {
    console.error('Error removing pending credential from session:', error)
    throw error
  }
}

// Listen for tab updates (page loads, navigation)
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  // Only update when URL changes or page completes loading
  if (changeInfo.status === 'complete' && tab.url) {
    updateBadgeForTab(tabId, tab.url)
  }
})

// Listen for tab activation (switching tabs)
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  try {
    const tab = await chrome.tabs.get(activeInfo.tabId)
    if (tab.url) {
      updateBadgeForTab(activeInfo.tabId, tab.url)
    }
  } catch (error) {
    console.error('Tab activation error:', error)
  }
})

// Initialize debug logging and start services
initDebugLogging().then(() => {
  debugLog('Debug logging initialized')

  // Start auto-refresh timer
  startAutoRefreshTimer()

  // Start periodic licence checking (every hour)
  licenceCheckTimer = licenceChecker.startPeriodicCheck()
  debugLog('Licence periodic check started')

  initializeAuthState().then(() => {
    debugLog('Auth state initialized')
    // Badges will be updated automatically when:
    // - User switches tabs (chrome.tabs.onActivated)
    // - Pages load (chrome.tabs.onUpdated)
    // - User authenticates (handleAuthenticate)
  })

  debugLog('Teampass service worker initialized')
})