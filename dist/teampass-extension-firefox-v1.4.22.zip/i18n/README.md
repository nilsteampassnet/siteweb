# Internationalization (i18n)

This directory contains translation files for the Teampass Browser Extension.

## Structure

```
i18n/
├── README.md       # This file
├── i18n.js         # i18n module providing translation functions
├── en.json         # English translations (default)
└── [future locale files]
```

## Current Status

- **Version**: 1.4.20
- **Supported Languages**: English (en)
- **Default Language**: English (en)

## How to Use

### In JavaScript Files

```javascript
// The i18n instance is globally available as window.i18n

// Simple translation
const buttonText = i18n.t('popup.main.addItemButton'); // "Add new item"

// Translation with parameters
const message = i18n.t('content.toast.saveCredentialsFor', { domain: 'example.com' });
// "Save credentials for example.com"

// Check if initialized
if (i18n.isReady()) {
  const text = i18n.t('common.loading');
}

// Get current locale
const currentLang = i18n.getLocale(); // "en"
```

### In HTML Files

Currently, strings in HTML files are hardcoded. To enable i18n in HTML:

1. Add data-i18n attributes to elements:
   ```html
   <button data-i18n="popup.main.addItemButton">Add new item</button>
   ```

2. Create a helper function to replace text on page load (future enhancement)

## Adding a New Language

To add support for a new language (e.g., French):

### 1. Create Translation File

Create a new file `fr.json` based on `en.json`:

```json
{
  "_metadata": {
    "language": "Français",
    "locale": "fr",
    "version": "1.4.20"
  },
  "common": {
    "loading": "Chargement...",
    "save": "Enregistrer",
    ...
  },
  ...
}
```

### 2. Update manifest.json

Add the locale file to `web_accessible_resources`:

```json
"web_accessible_resources": [
  {
    "resources": [
      ...
      "i18n/en.json",
      "i18n/fr.json"
    ],
    "matches": ["<all_urls>"]
  }
]
```

### 3. Allow User to Select Language

Add language selection in options page:

```javascript
// In options.js or similar
await i18n.init(selectedLocale); // 'en', 'fr', etc.
```

## Translation Key Structure

Translation keys use dot notation to organize strings by context:

### Categories

- **common**: Shared strings (buttons, labels, etc.)
- **popup**: Popup interface strings
- **options**: Options page strings
- **content**: Content script strings
- **saveModes**: Credential save mode strings
- **errors**: Error messages
- **licence**: Licence-related messages
- **api**: API-related messages
- **badges**: Badge status indicators

### Example Keys

```
popup.main.addItemButton         → "Add new item"
options.credentials.usernameLabel → "Username *"
errors.tokenExpired              → "TOKEN_EXPIRED"
content.toast.loginDetected      → "Login detected"
```

## String Interpolation

Use `{placeholder}` syntax for dynamic values:

```json
{
  "content.toast.saveCredentialsFor": "Save credentials for {domain}"
}
```

Usage:
```javascript
i18n.t('content.toast.saveCredentialsFor', { domain: 'github.com' })
// → "Save credentials for github.com"
```

## Best Practices

### 1. Keep Keys Organized
- Group related strings under the same parent key
- Use descriptive key names

### 2. Avoid Hardcoding
- Extract all user-visible strings to translation files
- Even if only supporting one language initially

### 3. Placeholder Names
- Use clear, descriptive placeholder names: `{username}`, `{domain}`, not `{x}`, `{val}`

### 4. Context in Keys
- Include context in key names: `popup.editItem.title` vs just `title`

### 5. Consistency
- Use consistent terminology across all strings
- Maintain the same tone and style

## Testing Translations

1. **Check for Missing Keys**
   ```javascript
   // The i18n module will log warnings for missing keys
   i18n.t('nonexistent.key') // Logs warning and returns 'nonexistent.key'
   ```

2. **Test Interpolation**
   ```javascript
   // Verify placeholders are replaced correctly
   const result = i18n.t('key.with.placeholder', { name: 'Test' })
   console.assert(result.includes('Test'))
   ```

3. **Verify Coverage**
   - Ensure all user-facing strings have translation keys
   - Use browser dev tools to search for hardcoded strings

## Future Enhancements

- [ ] Auto-detect browser language
- [ ] Language switcher in options page
- [ ] Helper function to replace HTML content with translations
- [ ] Pluralization support
- [ ] Date/time localization
- [ ] Number formatting

## Migration Notes (v1.4.20)

This is the initial i18n implementation. **Existing code has NOT been modified** to use i18n yet.

To migrate existing code:

1. Replace hardcoded strings with `i18n.t('key')` calls
2. Update HTML to use data-i18n attributes or JavaScript text replacement
3. Test thoroughly to ensure no strings are broken

**Note**: The current implementation is backward-compatible. The extension will continue to work with hardcoded strings until migration is complete.

## Support

For questions or issues with translations, please refer to:
- [Teampass Documentation](https://teampass.net)
- [Extension Repository](https://github.com/nilsteampassnet/TeamPass)
