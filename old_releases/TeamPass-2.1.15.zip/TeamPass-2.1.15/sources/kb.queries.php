<?php
/**
 * @file          kb.queries.php
 * @author        Nils Laumaillé
 * @version       2.1.13
 * @copyright     (c) 2009-2012 Nils Laumaillé
 * @licensing     GNU AFFERO GPL 3.0
 * @link          http://www.teampass.net
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

session_start();
if (!isset($_SESSION['CPM']) || $_SESSION['CPM'] != 1 || !isset($_SESSION['settings']['enable_kb']) || $_SESSION['settings']['enable_kb'] != 1) {
    die('Hacking attempt...');
}

require_once $_SESSION['settings']['cpassman_dir'].'/includes/language/'.$_SESSION['user_language'].'.php';
include $_SESSION['settings']['cpassman_dir'].'/includes/settings.php';
require_once $_SESSION['settings']['cpassman_dir'].'/includes/include.php';
require_once $_SESSION['settings']['cpassman_dir'].'/sources/SplClassLoader.php';
header("Content-type: text/html; charset=utf-8");
header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache");
include 'main.functions.php';

//Connect to DB
$db = new SplClassLoader('Database\Core', '../includes/libraries');
$db->register();
$db = new Database\Core\DbCore($server, $user, $pass, $database, $pre);
$db->connect();

//Load AES
$aes = new SplClassLoader('Encryption\Crypt', '../includes/libraries');
$aes->register();

function utf8Urldecode($value)
{
    $value = preg_replace('/%([0-9a-f]{2})/ie', 'chr(hexdec($1))', (string) $value);

    return $value;
}

// Construction de la requéte en fonction du type de valeur
if (!empty($_POST['type'])) {
    switch ($_POST['type']) {
        case "kb_in_db":
            // Check KEY
            if ($_POST['key'] != $_SESSION['key']) {
                echo '[ { "error" : "key_not_conform" } ]';
                break;
            }
            //decrypt and retreive data in JSON format
            $data_received = json_decode((Encryption\Crypt\aesctr::decrypt($_POST['data'], $_SESSION['key'], 256)), true);

            //Prepare variables
            $id = htmlspecialchars_decode($data_received['id']);
            $label = htmlspecialchars_decode($data_received['label']);
            $category = htmlspecialchars_decode($data_received['category']);
            $anyone_can_modify = htmlspecialchars_decode($data_received['anyone_can_modify']);
            $kb_associated_to = htmlspecialchars_decode($data_received['kb_associated_to']);
            $description = htmlspecialchars_decode($data_received['description']);

            //check if allowed to modify
            if (isset($id) && !empty($id)) {
                $row = $db->query("SELECT anyone_can_modify, author_id FROM ".$pre."kb WHERE id = ".$id);
                $ret = $db->fetchArray($row);
                if ($ret['anyone_can_modify'] == 1 || $ret['author_id'] == $_SESSION['user_id']) {
                    $manage_kb = true;
                } else {
                    $manage_kb = false;
                }
            } else {
                $manage_kb = true;
            }
            if ($manage_kb == true) {
                //Add category if new
                $data = $db->fetchRow("SELECT COUNT(*) FROM ".$pre."kb_categories WHERE category = '".mysql_real_escape_string($category)."'");
                if ($data[0] == 0) {
                    $cat_id = $db->queryInsert(
                        "kb_categories",
                        array(
                            'category' => mysql_real_escape_string($category)
                       )
                    );
                } else {
                    //get the ID of this existing category
                    $cat_id = $db->fetchRow("SELECT id FROM ".$pre."kb_categories WHERE category = '".mysql_real_escape_string($category)."'");
                    $cat_id = $cat_id[0];
                }

                if (isset($id) && !empty($id)) {
                    //update KB
                    $new_id = $db->queryUpdate(
                        "kb",
                        array(
                            'label' => ($label),
                            'description' => ($description),
                            'author_id' => $_SESSION['user_id'],
                            'category_id' => $cat_id,
                            'anyone_can_modify' => $anyone_can_modify
                       ),
                        "id='".$id."'"
                    );
                } else {
                    //add new KB
                    $new_id = $db->queryInsert(
                        "kb",
                        array(
                            'label' => $label,
                            'description' => ($description),
                            'author_id' => $_SESSION['user_id'],
                            'category_id' => $cat_id,
                            'anyone_can_modify' => $anyone_can_modify
                       )
                    );
                }

                //delete all associated items to this KB
                $db->queryDelete(
                    "kb_items",
                    array(
                        'kb_id' => $new_id
                   )
                );
                //add all items associated to this KB
                foreach (explode(',', $kb_associated_to) as $item_id) {
                    $db->queryInsert(
                        "kb_items",
                        array(
                            'kb_id' => $new_id,
                            'item_id' => $item_id
                       )
                    );
                }

                echo '[ { "status" : "done" } ]';
            } else {
                echo '[ { "status" : "none" } ]';
            }

            break;
        /**
         * Open KB
         */
        case "open_kb":
            // Check KEY
            if ($_POST['key'] != $_SESSION['key']) {
                echo '[ { "error" : "key_not_conform" } ]';
                break;
            }
            $row = $db->query(
                "SELECT k.id as id, k.label as label, k.description as description, k.category_id as category_id, k.author_id as author_id, k.anyone_can_modify as anyone_can_modify,
                u.login as login, c.category as category
                FROM ".$pre."kb as k
                INNER JOIN ".$pre."kb_categories as c ON (c.id = k.category_id)
                INNER JOIN ".$pre."users as u ON (u.id = k.author_id)
                WHERE k.id = '".$_POST['id']."'"
            );
            $ret = $db->fetchArray($row);

            //select associated items
            $rows = $db->fetchAllArray(
                "SELECT item_id
                FROM ".$pre."kb_items
                WHERE kb_id = '".$_POST['id']."'"
            );
            $arrOptions = array();
            foreach ($rows as $reccord) {
                //echo '$("#kb_associated_to option[value='.$reccord['item_id'].']").attr("selected","selected");';
                array_push($arrOptions, $reccord['item_id']);
            }

            $arrOutput = array(
                "label"     => $ret['label'],
                "category"     => $ret['category'],
                "description"     => $ret['description'],
                "anyone_can_modify"     => $ret['anyone_can_modify'],
                "options"     => $arrOptions
            );

            echo json_encode($arrOutput, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP);
            break;
        /**
         * Delete the KB
         */
        case "delete_kb":
            // Check KEY
            if ($_POST['key'] != $_SESSION['key']) {
                echo '[ { "error" : "key_not_conform" } ]';
                break;
            }
            $db->queryDelete(
                "kb",
                array(
                    'id' => $_POST['id']
               )
            );
            break;
    }
}
