<?php
/**
 * PHPMailer language file.
 * Russian Version
 */

$PHPMAILER_LANG = array();

$PHPMAILER_LANG["provide_address"] = 'éééééééééé ééééééé ééééééé éééé Email' .
                                     'éééééééééé.';
$PHPMAILER_LANG["mailer_not_supported"] = ' mailer éé éééééééééééééé.';
$PHPMAILER_LANG["execute"] = 'éééééééééé ééééééééé ééé ééééééé: ';
$PHPMAILER_LANG["instantiate"] = 'ééééééééé éééééé ééé ééééééééééééé Mail ééééééé.';
$PHPMAILER_LANG["authenticate"] = 'SMTP éééééé: éééééé ééééééééééé.';
$PHPMAILER_LANG["from_failed"] = 'éééééééé ééééé ééééééééééé: ';
$PHPMAILER_LANG["recipients_failed"] = 'SMTP éééééé: ééééééééé ' .
                                       'éééééé ééééééééééé ééééééé: ';
$PHPMAILER_LANG["data_not_accepted"] = 'SMTP éééééé: éééééé éé éééé ééééééé.';
$PHPMAILER_LANG["connect_host"] = 'SMTP éééééé: SMTP-Host éééééééééé.';
$PHPMAILER_LANG["file_access"] = 'é ééééééé é éééééééééé ééééé éééé éééééééé: ';
$PHPMAILER_LANG["file_open"] = 'éé éééé ééééééé éééé: ';
$PHPMAILER_LANG["encoding"] = 'ééééééééééé éééééé ééééééééé: ';
