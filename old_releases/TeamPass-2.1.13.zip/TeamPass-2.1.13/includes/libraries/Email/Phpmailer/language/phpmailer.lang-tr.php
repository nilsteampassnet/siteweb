<?php
/**
 * PHPMailer dil dosyasé.
 * Térkée Versiyonu
 * éZYAZILIM - Eléin ézel - Can Yélmaz - Mehmet Benlioélu
 */

$PHPMAILER_LANG = array();

$PHPMAILER_LANG["provide_address"] = 'En az bir tane mail adresi belirtmek zorundasénéz ' .
                                     'alécénén email adresi.';
$PHPMAILER_LANG["mailer_not_supported"] = ' mailler desteklenmemektedir.';
$PHPMAILER_LANG["execute"] = 'éaléétérélaméyor: ';
$PHPMAILER_LANG["instantiate"] = 'érnek mail fonksiyonu yaratélamadé.';
$PHPMAILER_LANG["authenticate"] = 'SMTP Hatasé: Doérulanaméyor.';
$PHPMAILER_LANG["from_failed"] = 'Baéaréséz olan génderici adresi: ';
$PHPMAILER_LANG["recipients_failed"] = 'SMTP Hatasé:  ' .
                                       'alécélara ulaémadé: ';
$PHPMAILER_LANG["data_not_accepted"] = 'SMTP Hatasé: Veri kabul edilmedi.';
$PHPMAILER_LANG["connect_host"] = 'SMTP Hatasé: SMTP hosta baélanélaméyor.';
$PHPMAILER_LANG["file_access"] = 'Dosyaya eriéilemiyor: ';
$PHPMAILER_LANG["file_open"] = 'Dosya Hatasé: Dosya aéélaméyor: ';
$PHPMAILER_LANG["encoding"] = 'Bilinmeyen éifreleme: ';
