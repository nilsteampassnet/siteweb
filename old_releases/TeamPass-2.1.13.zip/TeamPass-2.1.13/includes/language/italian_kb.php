<?php
//ITALIAN
if (!isset($_SESSION['settings']['cpassman_url'])) {
	$TeamPass_url = '';
}else{
	$TeamPass_url = $_SESSION['settings']['cpassman_url'];
}


$txt['category'] = "Categoria";
$txt['kb'] = "Knowledge Base";
$txt['kb_anyone_can_modify'] = "Chiunque può modificare";
$txt['kb_form'] = "Gestisci voci in KB";
$txt['new_kb'] = "Aggiungi una voce in KB";
?>
